"""URL and action safety policy for the local desktop assistant."""
from __future__ import annotations

from typing import Any
from pathlib import Path
import ipaddress
import re
import socket
from urllib.parse import urlparse

PRIVATE_SUFFIXES = (
    ".localhost", ".local", ".internal", ".lan", ".home", ".home.arpa",
    ".test", ".example", ".invalid", ".onion",
)
LOCAL_NAMES = {"localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback"}

SENSITIVE_INTERACTION_DOMAINS = {
    "gmail.com", "google.com", "outlook.com", "live.com", "office.com",
    "office365.com", "yahoo.com", "proton.me", "protonmail.com",
    "whatsapp.com", "web.whatsapp.com", "telegram.org", "web.telegram.org",
    "facebook.com", "messenger.com", "instagram.com", "discord.com",
    "signal.org", "linkedin.com", "x.com", "twitter.com", "reddit.com",
    "chatgpt.com",
}

_RISKY_ENGLISH = re.compile(
    r"\b(send|submit|post|publish|delete|remove|erase|transfer|pay|purchase|buy|"
    r"checkout|place order|book|confirm|save changes|log out|sign out|withdraw|"
    r"cancel subscription|invite|share|forward|reply|send now)\b",
    re.IGNORECASE,
)
_RISKY_ARABIC = (
    "إرسال", "ارسال", "أرسل", "ارسل", "إرسال الآن", "ارسال الآن", "حذف", "مسح",
    "شراء", "ادفع", "دفع", "نشر", "تأكيد", "تاكيد", "تحويل", "حجز",
    "تنفيذ الطلب", "تسجيل الخروج", "مشاركة", "إعادة توجيه", "رد", "رد على",
    "إلغاء الاشتراك", "الغاء الاشتراك", "سحب", "حفظ التغييرات",
)

# A closed list for local side-effect tools. Unknown tools are treated as sensitive.
READ_ONLY_TOOLS = {
    "list_workspace_files",
    "get_browser_status",
}

def host_matches_domain(host: str, domain: str) -> bool:
    host = (host or "").strip().lower().rstrip(".")
    domain = (domain or "").strip().lower().rstrip(".")
    return bool(host and domain and (host == domain or host.endswith("." + domain)))


def is_local_or_private_host(host: str) -> bool:
    """Return True for local names, private/reserved IPs, and local-only DNS suffixes."""
    value = (host or "").strip().strip("[]").lower().rstrip(".")
    if not value or value in LOCAL_NAMES:
        return True
    try:
        address = ipaddress.ip_address(value.split("%", 1)[0])
        return not address.is_global
    except ValueError:
        pass
    if "." not in value:
        return True
    if value.endswith(PRIVATE_SUFFIXES):
        return True
    # Reject malformed hosts commonly used to bypass hostname checks.
    if any(ch.isspace() for ch in value) or "\\" in value or "@" in value:
        return True
    return False


def _validate_dns_is_public(host: str, port: int | None = None) -> None:
    """Resolve a hostname and reject it if any returned address is not globally routable.

    This is defense-in-depth, not a complete guarantee against DNS rebinding. The current
    browser URL is checked again after navigation and redirects.
    """
    try:
        answers = socket.getaddrinfo(host, port or None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ValueError(f"تعذر التحقق من عنوان الموقع عبر DNS: {host}") from exc
    if not answers:
        raise ValueError(f"لم يُرجع DNS عنوانًا للموقع: {host}")
    for answer in answers:
        ip_text = answer[4][0]
        try:
            address = ipaddress.ip_address(ip_text.split("%", 1)[0])
        except ValueError as exc:
            raise ValueError("أعاد DNS عنوانًا غير صالح.") from exc
        if not address.is_global:
            raise ValueError(f"الموقع يحلّ إلى عنوان محلي أو غير عام، فتم رفضه: {host}")


def check_allowed_url(raw_url: str, *, resolve_dns: bool = False) -> str:
    """Validate an HTTP(S) URL; broad public web browsing is allowed, local targets are not."""
    url = str(raw_url or "").strip()
    if not url or any(ord(ch) < 32 for ch in url):
        raise ValueError("الرابط فارغ أو يحتوي محارف تحكم غير مسموحة.")
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("يجب أن يبدأ الرابط بـ http:// أو https:// ويحتوي اسم موقع.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("الروابط التي تتضمن اسم مستخدم أو كلمة مرور مرفوضة.")
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError("رقم المنفذ في الرابط غير صالح.") from exc
    if port is not None and not (1 <= port <= 65535):
        raise ValueError("رقم المنفذ خارج النطاق.")
    host = parsed.hostname.lower().rstrip(".")
    if is_local_or_private_host(host):
        raise ValueError(f"الوصول إلى عنوان محلي أو خاص ممنوع: {host}")
    if resolve_dns:
        _validate_dns_is_public(host, port)
    return url


def host_is_allowed(host: str) -> bool:
    """Compatibility helper; true means the hostname is not syntactically local/private."""
    return not is_local_or_private_host(host)


def is_sensitive_interaction_url(raw_url: str) -> bool:
    """Identify likely private-account sites for extra UI warnings; does not block them."""
    try:
        host = (urlparse(str(raw_url or "")).hostname or "").lower().rstrip(".")
    except ValueError:
        return True
    return any(host_matches_domain(host, domain) for domain in SENSITIVE_INTERACTION_DOMAINS)


def is_risky_action_label(label: str) -> bool:
    value = str(label or "").strip()
    if not value:
        return False
    return bool(_RISKY_ENGLISH.search(value) or any(word in value for word in _RISKY_ARABIC))


_DELETE_ACTION_RE = re.compile(
    r"\b(delete|remove|erase|unlink|rmdir|rd|del|rm|shred|wipe|rmtree|truncate|format)\b|"
    r"(حذف|امسح|مسح|إزالة|ازالة|احذف|افرغ سلة|إفراغ سلة|مسح السجل|مسح البيانات|افرغ السلة)",
    re.IGNORECASE,
)


def _is_deletion_request(tool_name: str, args: dict) -> bool:
    """Classify deletion by the actual control or command, not incidental file names."""
    name = str(tool_name or "").strip().lower()
    if name.startswith("delete_") or name in {"remove_file", "remove_folder", "erase_file"}:
        return True

    # UI controls are classified by their visible label. Do not scan the whole
    # request, page text, or a destination path: a file named delete_notes.txt
    # is not itself a deletion command.
    if name == "browser_click_text":
        return bool(_DELETE_ACTION_RE.search(str(args.get("text", "") or "")))
    if name == "click_window_control":
        return bool(_DELETE_ACTION_RE.search(str(args.get("control_text", "") or "")))

    # Shell commands are inspected as commands, with deletion verbs anchored at
    # a command boundary. Incidental strings such as test_delete.py are ignored.
    if name in {"run_local_command", "run_shell_command"}:
        command_value = args.get("shell_command", args.get("command", ""))
        command = " ".join(str(part) for part in command_value) if isinstance(command_value, (list, tuple)) else str(command_value)
        return bool(re.search(
            r"(?i)(?:^|[\s;&|])(?:del|erase|rm|rmdir|rd|remove-item|remove-itemproperty|clear-content|clear-recyclebin|shred|wipe|format|truncate)(?:\.exe)?(?:[\s;&|]|$)|(?:os\.remove|os\.unlink|pathlib\.Path\.unlink|shutil\.rmtree)\s*\(",
            command,
        ))
    return False


# Action policy: distinguish low-impact automation, explicit external side effects,
# and high-impact system changes. Page/file/image contents are never an authorization source.
_SYSTEM_CHANGE_RE = re.compile(
    r"(?i)(?:\b(?:reg(?:\.exe)?\s+(?:add|delete|import)|(?:new|set|remove)-itemproperty|"
    r"set-mppreference|disable-windowsoptionalfeature|enable-windowsoptionalfeature|"
    r"format-volume|clear-disk|initialize-disk|diskpart|bcdedit|shutdown(?:\.exe)?|"
    r"restart-computer|stop-computer|net\s+user|sc(?:\.exe)?\s+(?:create|config|delete)|"
    r"schtasks(?:\.exe)?\s+/create|wevtutil\s+cl|cipher\s+/w)\b)"
    r"|(?:powershell(?:\.exe)?[^\r\n]{0,120}-(?:encodedcommand|enc)\b)"
    r"|(?:\b(?:invoke-expression|iex)\b)"
    r"|(?:\b(?:iwr|invoke-webrequest|curl|wget)\b[^\r\n]{0,300}\|\s*(?:iex|invoke-expression|bash|sh|python|powershell|pwsh))"
    r"|(?:\b(?:powershell|pwsh)(?:\.exe)?[^\r\n]{0,120}-(?:executionpolicy\s+bypass|windowstyle\s+hidden)\b)"
    r"|(?:\b(?:curl|wget|iwr|invoke-webrequest|certutil|bitsadmin)\b[^\r\n]{0,200}https?://)"
)

_USER_ACTION_CUES = {
    "send": re.compile(
        r"(?i)(?:\b(?:send|forward|reply to|send out)\s+(?:(?:me|us|him|her|them)\s+)?(?:(?:this|the|that|my|a|an)\s+)?"
        r"(?:email|e-mail|message|reply|response|text|mail|whatsapp message|telegram message|report|results?|summary|file|document|details|attachment)\b|"
        r"\bsend\s+(?:it|this)\s+to\s+|\bsend\b[^\r\n]{0,100}\b(?:report|results?|summary|file|document|details|attachment|email|message|reply|response)\b|\bclick\s+(?:the\s+)?send\b|"
        r"(?:أرسل|ارسل|ابعث|قم بإرسال|قم بارسال|إرسال|ارسال)\s*(?:لي\s+|لنا\s+|له\s+|لها\s+|إلى\s+|الى\s+|على\s+)?(?:هذه\s+)?"
        r"(?:الرسالة|البريد|الرد|رسالة|إيميل|ايميل|رسالة واتساب|رسالة تليجرام|التقرير|تقرير|النتيجة|نتيجة|النتائج|نتائج|"
        r"الملخص|ملخص|الملف|ملف|المرفق|المرفقات|التفاصيل|تفاصيل|البيانات|بيانات|الاختبار|نتائج\s+مختبر|"
        r"إلى\s+|الى\s+|واتساب|تليجرام|تلغرام|Gmail|WhatsApp|Telegram)|"
        r"اضغط\s+(?:على\s+)?(?:زر\s+)?إرسال|انقر\s+(?:على\s+)?(?:زر\s+)?إرسال)"
    ),
    "publish": re.compile(r"(?i)(?:\b(?:publish|post this|publish this|post it|post to|publish to)\b|(?:انشر|نشر|انشر هذا|انشرها|نشرها))"),
    "purchase": re.compile(r"(?i)(?:\b(?:buy(?: this)?|purchase(?: this)?|place (?:the )?order|checkout|pay for)\b|(?:اشترِ|اشتري|شراء|ادفع ثمن|قم بالشراء|تنفيذ الطلب))"),
    "transfer": re.compile(r"(?i)(?:\b(?:transfer funds|send money|withdraw|wire funds|make a payment)\b|(?:حوّل المبلغ|حول المبلغ|تحويل الأموال|اسحب الأموال|قم بالتحويل))"),
    "book": re.compile(r"(?i)(?:\b(?:book (?:it|this|the|a)|make (?:the )?reservation)\b|(?:احجز|قم بالحجز|أكد الحجز|اكد الحجز))"),
    "confirm": re.compile(r"(?i)(?:\b(?:confirm (?:it|this|the)|submit (?:the |this )?(?:form|request|application)|save(?: the| this)? (?:file|draft|settings|changes|document))\b|(?:أكد هذا|أكد التغيير|أكد الحجز|اكد الحجز|قم بتأكيد الحجز|أرسل النموذج|ارسل النموذج|أرسل الطلب|ارسل الطلب|قدّم الطلب|قدم الطلب|تأكيد التغيير|احفظ (?:الملف|المسودة|الإعدادات|التغييرات)|حفظ التغييرات))"),
    "delete": re.compile(r"(?i)(?:\b(?:delete|remove|erase|wipe|format|clear (?:history|data|cache|activity)|empty (?:the )?trash)\b|(?:احذف|حذف|امسح|مسح|إزالة|ازالة|افرغ سلة|إفراغ سلة))"),
    "share": re.compile(r"(?i)(?:\b(?:share (?:this|it)|invite (?:them|this person))\b|(?:شارك هذا|مشاركة هذا|ادعُ هذا الشخص|إرسال مشاركة))"),
    "reply": re.compile(r"(?i)(?:\b(?:reply to|forward this|forward the)\b|(?:رد على|أعد توجيه|اعادة توجيه))"),
    "cancel": re.compile(r"(?i)(?:\b(?:cancel (?:the |my |this )?(?:subscription|order|booking|payment)|cancel subscription)\b|(?:ألغِ الاشتراك|الغاء الاشتراك|إلغاء الاشتراك|إلغاء الطلب|الغاء الطلب|ألغِ الحجز|إلغاء الحجز))"),
    "logout": re.compile(r"(?i)(?:\b(?:log out|logout|sign out|signout)\b|تسجيل الخروج|سجل الخروج|سجّل الخروج|اخرج من الحساب)"),
    "login": re.compile(r"(?i)(?:\b(?:log in|login|sign in|signin|authenticate)\b|تسجيل الدخول|سجل الدخول|تسجيل دخولي|ادخل إلى الحساب)"),
    "install": re.compile(r"(?i)(?:\b(?:install|add extension|add to chrome)\b|تثبيت|ثبّت|ثبت|اضف الاضافة|أضف الإضافة)"),
    "download": re.compile(r"(?i)(?:\b(?:download|download file)\b|تنزيل|نزّل|نزل|حمّل|حمل الملف)"),
    "connect": re.compile(r"(?i)(?:\b(?:connect account|connect app|connect to)\b|اربط\s+(?:الحساب|حساب(?:\s+\S+)?)|ربط الحساب|وصّل الحساب|وصل الحساب)"),
    "enable": re.compile(r"(?i)(?:\b(?:enable|turn on|activate)\b|فعّل|فعل|تشغيل الميزة|تمكين)"),
    "subscribe": re.compile(r"(?i)(?:\b(?:subscribe|start free trial|start trial)\b|اشترك|الاشتراك|ابدأ التجربة المجانية)"),
}

_ACTION_NEGATIONS = {
    "send": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:send|submit|forward|reply)\b|(?:لا\s*(?:ترسل|ترسِل|تقم\s+بالإرسال|تقم\s+بارسال)|بدون\s+إرسال|دون\s+إرسال|لا\s+تبعت))"),
    "publish": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:publish|post)\b|(?:لا\s*(?:تنشر|تقُم\s+بالنشر)|بدون\s+نشر|دون\s+نشر))"),
    "purchase": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:buy|purchase|pay|checkout)\b|(?:لا\s*(?:تشتر|تشتري|تدفع|تنفذ\s+الطلب)|بدون\s+شراء))"),
    "transfer": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:transfer|withdraw|pay)\b|(?:لا\s*(?:تحول|تسحب|تدفع)|بدون\s+تحويل))"),
    "book": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+book\b|(?:لا\s*(?:تحجز|تؤكد\s+الحجز)|بدون\s+حجز))"),
    "confirm": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:confirm|submit|save)\b|(?:لا\s*(?:تؤكد|تأكد|ترسل|تحفظ\s+التغييرات)|بدون\s+(?:تأكيد|حفظ)))"),
    "delete": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:delete|remove|erase|format|clear|empty)\b|(?:لا\s*(?:تحذف|تحذفن|تمسح|تزيل|تفرغ)|بدون\s+حذف))"),
    "share": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+share\b|(?:لا\s*(?:تشارك|تدعُ)|بدون\s+مشاركة))"),
    "reply": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:reply|forward)\b|(?:لا\s*(?:ترد|تعيد\s+التوجيه)|بدون\s+رد))"),
    "cancel": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+cancel\b|(?:لا\s*(?:تلغِ|تلغي|تلغ|تُلغِ|تُلغي)|بدون\s+إلغاء))"),
    "logout": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:log out|logout|sign out)\b|(?:لا\s*(?:تسجل\s+الخروج|تخرج\s+من\s+الحساب)|بدون\s+تسجيل\s+الخروج))"),
    "login": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:log in|login|sign in|authenticate)\b|(?:لا\s*(?:تسجل\s+الدخول|تدخل\s+إلى\s+الحساب)|بدون\s+تسجيل\s+الدخول))"),
    "install": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:install|add extension)\b|(?:لا\s*(?:تثبت|تثبّت|تنصب)|بدون\s+تثبيت))"),
    "download": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+download\b|(?:لا\s*(?:تنزل|تنزّل|تحمّل|تحمل)|بدون\s+تنزيل))"),
    "connect": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+connect\b|(?:لا\s*(?:تربط|تصل|توصل)|بدون\s+ربط))"),
    "enable": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:enable|activate|turn on)\b|(?:لا\s*(?:تفعل|تفعّل|تمكن|تشغل)|بدون\s+تفعيل))"),
    "subscribe": re.compile(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:subscribe|start trial)\b|(?:لا\s*(?:تشترك|تبدأ\s+التجربة)|بدون\s+اشتراك))"),
}

def _flatten_action_value(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(_flatten_action_value(v) for v in value.values())
    if isinstance(value, (list, tuple, set)):
        return " ".join(_flatten_action_value(v) for v in value)
    return str(value or "")


def _action_label(tool_name: str, args: dict) -> str:
    """Only inspect target labels, not user-provided text bodies, to classify UI effects."""
    name = str(tool_name or "").strip().lower()
    if name == "browser_click_text":
        return str(args.get("text", ""))
    if name == "click_window_control":
        return str(args.get("control_text", ""))
    if name == "browser_press_key":
        return str(args.get("key", ""))
    if name == "press_window_key":
        return str(args.get("key_combo", ""))
    if name in {"run_local_command", "run_shell_command"}:
        return _flatten_action_value(args.get("command", ""))
    if name == "launch_program":
        return " ".join([str(args.get("program", "")), _flatten_action_value(args.get("arguments", []))])
    return ""


def _action_category(tool_name: str, args: dict) -> str | None:
    name = str(tool_name or "").strip().lower()
    if name.startswith("delete_") or name in {"remove_file", "remove_folder", "erase_file"} or _is_deletion_request(name, args):
        return "delete"
    # System-level changes are handled separately and always need explicit review.
    if name in {"browser_press_key", "press_window_key"}:
        key = str(args.get("key", args.get("key_combo", ""))).strip().lower()
        if key in {"enter", "return", "{enter}", "key.enter", "alt+f4", "ctrl+w", "ctrl+enter"}:
            return "commit"
    label = _action_label(name, args).strip()
    if not label:
        return None
    if re.fullmatch(r"(?i)(?:yes(?:,\s*(?:continue|proceed))?|okay|ok|proceed|authorize|accept|agree|continue|نعم|موافق|موافقة|متابعة|استمر|تنفيذ)", label):
        return "commit"
    if name in {"run_local_command", "run_shell_command"}:
        # Detect dangerous system changes separately below; otherwise a shell command is its own category.
        return "shell"
    if name == "launch_program":
        return "launch"
    for category in ("send", "publish", "purchase", "transfer", "book", "confirm", "delete", "share", "reply", "cancel", "logout", "login", "install", "download", "connect", "enable", "subscribe"):
        cues = {
            "send": r"(?i)\b(send|mail|إرسال|ارسال|أرسل|ارسل|ابعث)\b|إرسال|ارسال",
            "publish": r"(?i)\b(publish|post)\b|نشر|انشر",
            "purchase": r"(?i)\b(buy|purchase|checkout|pay|place order)\b|شراء|اشتر|ادفع|الشراء",
            "transfer": r"(?i)\b(transfer|withdraw|wire|payment)\b|تحويل|سحب|دفع",
            "book": r"(?i)\b(book|reservation|reserve)\b|حجز|احجز",
            "confirm": r"(?i)\b(confirm|submit|save|save changes|apply|continue|agree|accept)\b|تأكيد|حفظ|احفظ|تطبيق|موافقة|متابعة",
            "delete": r"(?i)\b(delete|remove|erase|format)\b|حذف|مسح|إزالة|ازالة",
            "share": r"(?i)\b(share|invite)\b|مشاركة|شارك|دعوة",
            "reply": r"(?i)\b(reply|forward)\b|رد|إعادة توجيه|اعادة توجيه",
            "cancel": r"(?i)\b(cancel subscription|cancel order|cancel booking)\b|إلغاء الاشتراك|الغاء الاشتراك|إلغاء الطلب|إلغاء الحجز",
            "logout": r"(?i)\b(log out|logout|sign out|signout)\b|تسجيل الخروج|اخرج من الحساب",
            "login": r"(?i)\b(log in|login|sign in|signin|authenticate)\b|تسجيل الدخول|ادخل إلى الحساب",
            "install": r"(?i)\b(install|add extension|add to chrome)\b|تثبيت|ثبّت|ثبت|أضف الإضافة|اضف الاضافة",
            "download": r"(?i)\b(download|download file)\b|تنزيل|نزّل|نزل|حمّل|حمل الملف",
            "connect": r"(?i)\b(connect account|connect app|connect to)\b|اربط الحساب|ربط الحساب|وصل الحساب|وصّل الحساب",
            "enable": r"(?i)\b(enable|turn on|activate)\b|فعّل|فعل|تمكين",
            "subscribe": r"(?i)\b(subscribe|start free trial|start trial)\b|اشترك|الاشتراك|ابدأ التجربة المجانية",
        }[category]
        if re.search(cues, label):
            return category
    return None


def _request_forbids_action(category: str, user_request: str) -> bool:
    request = str(user_request or "")
    pattern = _ACTION_NEGATIONS.get(category)
    if pattern and pattern.search(request):
        return True
    if category == "send":
        # A read-only task must not pause at a Send button asking for permission;
        # deny the mismatched action outright. Explicitly requested reporting/sending
        # still works, including tasks that read data first and then send a summary.
        send_pattern = _USER_ACTION_CUES.get("send")
        reply_pattern = _USER_ACTION_CUES.get("reply")
        explicitly_authorized = bool(
            (send_pattern and send_pattern.search(request))
            or (reply_pattern and reply_pattern.search(request))
        )
        read_only = bool(
            re.search(
                r"(?i)\b(?:read|review|summarize|inspect|check|open|view)\b.{0,80}\b(?:only|just)\b|"
                r"\b(?:read-only|read only|do not send|don't send|without sending)\b",
                request,
            )
            or re.search(
                r"(?:اقرأ|قراءة|لخّص|لخص|راجع|افحص|اعرض|فتح).{0,80}(?:فقط|ولا ترسل|لا ترسل|دون إرسال|بدون إرسال)|"
                r"(?:قراءة فقط|للقراءة فقط|عرض فقط|لا ترسل شيئًا|لا ترسل شيئا)",
                request,
            )
        )
        if read_only and not explicitly_authorized:
            return True
    if category == "commit" and re.search(r"(?i)(?:\b(?:do not|don't|never|without)\s+(?:submit|send|confirm|enter)\b|(?:لا\s*(?:ترسل|تؤكد|تضغط\s+إدخال)|بدون\s+(?:إرسال|تأكيد)))", request):
        return True
    if category in {"shell", "launch"} and re.search(r"(?i)(?:\b(?:do not|don't|never)\s+(?:run|execute|launch)\b|(?:لا\s*(?:تشغل|تنفذ|تفتح)\s+(?:الأمر|البرنامج|PowerShell|PowerShell|السكربت)?))", request):
        return True
    return False


def _request_authorizes_action(category: str, user_request: str, action_label: str = "") -> bool:
    request = str(user_request or "")
    if category in _USER_ACTION_CUES:
        pattern = _USER_ACTION_CUES[category]
        matched = bool(pattern.search(request))
        # A requested reply is finally committed by a UI button labelled "Send";
        # bind those two stages together instead of asking again at the last click.
        if category == "send" and not matched:
            reply_pattern = _USER_ACTION_CUES.get("reply")
            matched = bool(reply_pattern and reply_pattern.search(request))
        elif category == "reply" and not matched:
            send_pattern = _USER_ACTION_CUES.get("send")
            matched = bool(send_pattern and send_pattern.search(request))
        return matched
    if category == "commit":
        # Generic words such as "continue" or "yes" in a long task description
        # are not sufficient by themselves. Bind the authorization to the actual
        # target control or to a clear transactional intent.
        label = str(action_label or "").strip().casefold()
        key_label = label in {"enter", "return", "{enter}", "key.enter", "ctrl+enter", "control+enter"}
        if key_label:
            return bool(re.search(
                r"(?i)(?:\b(?:press|hit|use)\s+(?:the\s+)?(?:enter|return)\b|"
                r"\b(?:search|submit|confirm|send|execute)\b|"
                r"(?:ابحث|اضغط\s+(?:على\s+)?(?:زر\s+)?(?:Enter|إدخال|بحث|إرسال|تأكيد)|"
                r"أرسل\s+(?:الرسالة|البريد)|قم\s+بإرسال|أكد\s+الحجز|اكد\s+الحجز|نفذ\s+الأمر))", request
            ))
        # Exact mention of the button is explicit enough; vague task wording isn't.
        button_terms = {
            "yes": r"(?:yes|نعم)", "ok": r"(?:ok|okay|موافق)", "okay": r"(?:ok|okay|موافق)",
            "proceed": r"(?:proceed|تابع|متابعة|استمر)", "authorize": r"(?:authorize|أذن|أوافق)",
            "accept": r"(?:accept|أوافق|موافق)", "agree": r"(?:agree|أوافق|موافق)",
            "continue": r"(?:continue|تابع|متابعة|استمر)", "استمر": r"(?:استمر|تابع|متابعة)",
            "متابعة": r"(?:تابع|متابعة|استمر)", "نعم": r"(?:نعم|yes)", "موافق": r"(?:موافق|ok|okay)",
            "تنفيذ": r"(?:تنفيذ|نفذ)",
        }
        term = button_terms.get(label)
        if term and re.search(rf"(?i)\bclick\s+(?:the\s+)?(?:button\s+)?{term}\b", request):
            return True
        if term and re.search(rf"اضغط\s+(?:على\s+)?(?:زر\s+)?{term}", request, re.IGNORECASE):
            return True
        # A generic "Yes" can be authorized by an explicitly requested transaction,
        # but unrelated requests such as "read email" or "search the web" cannot.
        if label in {"yes", "نعم", "ok", "okay", "موافق"}:
            for intent_category in ("send", "publish", "purchase", "transfer", "book", "confirm", "share", "reply", "cancel", "logout", "login"):
                pattern = _USER_ACTION_CUES.get(intent_category)
                if pattern and pattern.search(request) and not _request_forbids_action(intent_category, request):
                    return True
        return False
    if category == "shell":
        explicit_intent = bool(re.search(
            r"(?i)(?:\b(?:run|execute|test|build|compile|install|start|launch|debug|check|review|inspect)\b|"
            r"\bpython(?:\.exe)?\b|\bpytest\b|\bstreamlit\b|\bpip\s+install\b|"
            r"(?:شغّل|شغل|نفذ|اختبر|اختبارات|فحص|افحص|تشييك|راجع\s+الكود|راجع\s+الملفات|ابنِ|بناء|ترجم|ثبت|تثبيت|التثبيت|تحقق|تحقّق|أصلح|اصلح|راجع))",
            request,
        ))
        return explicit_intent
    if category == "launch":
        # A launch request only authorizes a program explicitly named in the user's own prompt.
        program = str(getattr(_request_authorizes_action, "_program", "") or "")
        return bool(program and re.search(re.escape(program), request, re.IGNORECASE))
    return False


def _high_impact_system_command(tool_name: str, args: dict) -> bool:
    name = str(tool_name or "").strip().lower()
    if name not in {"run_local_command", "run_shell_command"}:
        return False
    command = _flatten_action_value(args.get("command", ""))
    return bool(_SYSTEM_CHANGE_RE.search(command))


def _has_explicit_financial_intent(user_request: str) -> bool:
    """Detect explicit purchase/payment/transfer intent for generic confirmation buttons."""
    request = str(user_request or "")
    for category in ("purchase", "transfer", "subscribe"):
        pattern = _USER_ACTION_CUES.get(category)
        if pattern and pattern.search(request) and not _request_forbids_action(category, request):
            return True
    return False


def _has_explicit_setup_intent(user_request: str) -> bool:
    return bool(re.search(
        r"(?i)(?:\b(?:install|setup|set up|start|launch|run|prepare|configure)\s+(?:the\s+)?(?:project|dependencies|requirements|aurora|assistant|application)\b|"
        r"(?:ثبت|تثبيت)\s+(?:اعتماديات|متطلبات|متطلبات\s+المشروع|الاعتماديات|المتطلبات)|"
        r"(?:شغل|شغّل|ابدأ|افتح|جهز|جهّز|إعداد)\s+(?:المساعد|أورورا|اورورا|Aurora|المشروع|الحزمة))",
        str(user_request or ""),
    ))


def _project_root_for_command(args: dict) -> Path | None:
    raw = str(args.get("cwd", "") or "").strip().strip('"')
    if not raw:
        return None
    try:
        path = Path(raw).expanduser().resolve()
        if path.is_dir() and (path / "requirements.txt").is_file() and (path / "app.py").is_file():
            return path
    except (OSError, RuntimeError, ValueError):
        pass
    return None


def _is_project_requirements_install(tool_name: str, args: dict) -> bool:
    """Only recognize installation of this project's own requirements into its venv."""
    if tool_name not in {"run_local_command", "run_shell_command"}:
        return False
    root = _project_root_for_command(args)
    if root is None:
        return False
    raw = args.get("command", "")
    if isinstance(raw, (list, tuple)):
        parts = [str(part).strip().strip('"') for part in raw]
        if len(parts) != 6:
            return False
        exe = parts[0].replace("/", "\\").casefold()
        expected_tail = ["-m", "pip", "install", "-r", "requirements.txt"]
        if not exe.endswith(".venv\\scripts\\python.exe") or [x.casefold() for x in parts[1:]] != expected_tail:
            return False
        return (root / ".venv" / "Scripts" / "python.exe").is_file()
    command = " ".join(str(raw or "").strip().strip('"').split())
    # Exact shape only: no arbitrary package names, URLs, flags, or command chaining.
    match = re.fullmatch(
        r'(?i)(?:"?[^"\r\n]*?\.venv[\\/]Scripts[\\/]python\.exe"?)\s+-m\s+pip\s+install\s+-r\s+requirements\.txt',
        command,
    )
    return bool(match and (root / ".venv" / "Scripts" / "python.exe").is_file())


def _is_project_start_command(tool_name: str, args: dict) -> bool:
    """Recognize the project's exact launcher, not arbitrary batch/shell files."""
    if tool_name != "run_shell_command":
        return False
    root = _project_root_for_command(args)
    if root is None or not (root / "START_WINDOWS.bat").is_file():
        return False
    command = str(args.get("command", "") or "").strip().strip('"').replace("/", "\\")
    return command.casefold() in {"start_windows.bat", ".\\start_windows.bat", "..\\start_windows.bat"} and command.casefold() != "..\\start_windows.bat"


def _explicit_scoped_workspace_delete(tool_name: str, args: dict, user_request: str) -> bool:
    """Allow requested cleanup of a plainly named, non-sensitive workspace artifact only."""
    if str(tool_name or "").strip().lower() != "delete_workspace_file":
        return False
    raw = str(args.get("path", "") or "").strip().strip('"')
    if not raw or raw in {".", ".."}:
        return False
    # Windows absolute/UNC paths and parent traversal are never accepted by this shortcut.
    normalized = raw.replace("\\", "/")
    if re.match(r"(?i)^[a-z]:/", normalized) or normalized.startswith("//") or any(part == ".." for part in normalized.split("/")):
        return False
    basename = normalized.rsplit("/", 1)[-1].strip()
    if not basename or basename.startswith("."):
        return False
    lowered = basename.casefold()
    protected_names = {
        "aurora.sqlite3", "chat_history.sqlite3", "long_term_memory.sqlite3", "credentials", "secrets",
        "credentials.json", "token.json", "id_rsa", "id_ed25519", "known_hosts",
    }
    protected_suffixes = {".sqlite", ".sqlite3", ".db", ".pem", ".key", ".p12", ".pfx", ".env"}
    if lowered in protected_names or Path(lowered).suffix in protected_suffixes:
        return False
    request = str(user_request or "")
    if _request_forbids_action("delete", request):
        return False
    delete_pattern = _USER_ACTION_CUES.get("delete")
    if not delete_pattern or not delete_pattern.search(request):
        return False
    # Prefer the exact artifact name in the user's request. Deictic reference is
    # accepted only for a cleanup task and stays confined to Aurora's workspace.
    if basename.casefold() in request.casefold():
        return True
    return bool(re.search(
        r"(?i)(?:\b(?:delete|remove)\s+(?:this|that|the selected|the temporary)\s+file\b|"
        r"(?:احذف|احذف لي|احذف هذا|احذف ذلك|أزل|ازل)\s+(?:هذا\s+|ذلك\s+)?(?:الملف|الملف المؤقت|ملف العمل)|"
        r"(?:نظف|نظّف)\s+(?:الملفات المؤقتة|ملفات العمل))",
        request,
    ))


def _routine_login_prerequisite_authorized(user_request: str, args: dict) -> bool:
    """Allow routine sign-in navigation only for an official service and matching user task."""
    raw_url = str(args.get("_policy_current_url", "") or "").strip()
    try:
        host = (urlparse(raw_url).hostname or "").lower().rstrip(".")
    except ValueError:
        return False
    request = str(user_request or "")
    services = (
        (("gmail.com", "google.com"), r"(?i)(?:\b(?:email|e-mail|mail|inbox|unread|gmail)\b|البريد|بريد|الرسائل غير المقروءة|البريد غير المقروء)"),
        (("whatsapp.com",), r"(?i)(?:\b(?:whatsapp|message|messages|chat|chats|reply|send)\b|واتساب|محادث|رسائل|رسالة|رد على)"),
        (("telegram.org",), r"(?i)(?:\b(?:telegram|message|messages|chat|chats|reply|send)\b|تليجرام|تلغرام|محادث|رسائل|رسالة|رد على)"),
    )
    return any(
        any(host_matches_domain(host, domain) for domain in domains) and re.search(task_pattern, request)
        for domains, task_pattern in services
    )


def tool_action_decision(tool_name: str, args: dict | None = None, user_request: str = "", mode: str = "balanced") -> tuple[str, str]:
    """Return (allow|review|deny, reason) using the current user request only, never page/file text."""
    name = str(tool_name or "").strip().lower()
    args = args if isinstance(args, dict) else {}
    request = str(user_request or "")
    category = _action_category(name, args)

    if category and _request_forbids_action(category, request):
        return "deny", f"طلب المستخدم الحالي يمنع الإجراء المصنف «{category}»."

    # Generic confirmation controls can otherwise bypass the financial-action
    # gate (for example, a page labels the final payment button simply "Yes").
    # This does not interrupt a direct Send/Reply action; it covers generic
    # Confirm/Submit/Yes controls in a transaction flow only.
    if category in {"commit", "confirm"} and _has_explicit_financial_intent(request):
        label = _action_label(name, args).strip()
        if re.search(r"(?i)^(?:yes|ok|okay|authorize|accept|agree|confirm|submit|apply|نعم|موافق|موافقة|أكد|تأكيد|إرسال الطلب)$", label):
            return "review", "زر التأكيد عام لكن المهمة تتضمن التزامًا ماليًا أو اشتراكًا؛ يلزم تأكيد هذا الأثر مرة واحدة عند بوابة الالتزام."

    # Elevated system changes always remain review-gated, even in routine-auto mode.
    if _high_impact_system_command(name, args):
        return "review", "الأمر يتضمن تغييرًا حساسًا في النظام أو تنزيل/تنفيذ شيفرة؛ راجع الأمر قبل تشغيله."

    if category == "delete":
        if mode == "routine_auto" and _explicit_scoped_workspace_delete(name, args, request):
            return "allow", "حذف ملف محدد بالاسم داخل مساحة عمل Aurora فقط. ملفات الإعدادات والأسرار وقواعد البيانات والمسارات خارج مساحة العمل ليست مشمولة بهذا الاختصار."
        return "review", "تغييرات الحذف خارج تنظيف ملف عادي ومحدد داخل مساحة العمل تحتاج مراجعة واحدة؛ لا تُطلب مراجعة للخطوات الروتينية الأخرى."
    if category == "install":
        explicitly_requested = _request_authorizes_action("install", request, _action_label(name, args))
        if mode == "routine_auto" and explicitly_requested:
            if name in {"browser_click_text", "click_window_control"}:
                return "allow", "التثبيت طُلب صراحةً؛ التنفيذ التلقائي نشط ولن تتكرر الموافقة على الخطوات التابعة لهذا الطلب."
            if _is_project_requirements_install(name, args) and _has_explicit_setup_intent(request):
                return "allow", "تثبيت اعتماديات requirements.txt داخل البيئة الافتراضية لهذا المشروع فقط، بطلب إعداد صريح."
        return "review", "التثبيت يحتاج طلبًا واضحًا. في الوضع التلقائي يُنفّذ التثبيت المطلوب صراحةً، ويظل تثبيت البرامج العامة أو الأوامر غير المحددة للمراجعة."
    if category == "subscribe":
        return "review", "الاشتراك قد ينشئ التزامًا متكررًا أو مدفوعًا؛ هذه من الحالات القليلة التي تتطلب مراجعة مستقلة."
    if category in {"purchase", "transfer"}:
        return "review", "هذه خطوة شراء أو تحويل مالي. بقية الخطوات الروتينية تنفّذ تلقائيًا، لكن الالتزام المالي يحتاج مراجعة واحدة قبل التنفيذ."

    if category == "login" and mode == "routine_auto" and name in {"browser_click_text", "click_window_control"}:
        label = _action_label(name, args).strip()
        login_button = bool(re.search(r"(?i)(?:sign\s*in|log\s*in|login|تسجيل\s+الدخول|سجل\s+الدخول|ادخل\s+إلى\s+الحساب)", label))
        if login_button and _routine_login_prerequisite_authorized(request, args):
            return "allow", "خطوة دخول روتينية إلى نطاق رسمي تابع للمهمة المطلوبة؛ لا تتطلب موافقة منفصلة. لا يُدخل المساعد كلمات مرور أو رموز تحقق تلقائيًا."

    if category in {"send", "publish", "book", "confirm", "share", "reply", "cancel", "logout", "login", "download", "connect", "enable"}:
        if not _request_authorizes_action(category, request, _action_label(name, args)):
            return "review", "الزر أو العنصر قد ينفذ أثرًا خارجيًا، وطلب المستخدم الحالي لا يصرح بهذا الأثر بوضوح."
        return "allow", "الأثر الخارجي مصرح به صراحةً في طلب المستخدم الحالي."

    if category == "commit":
        if not _request_authorizes_action(category, request, _action_label(name, args)):
            return "review", "ضغط مفتاح الإرسال/التأكيد قد يلتزم بنموذج أو ينفذ أمرًا؛ يلزم توضيح قصد المستخدم."
        return "allow", "استخدام المفتاح مرتبط صراحةً ببحث أو إرسال أو تنفيذ طلب المستخدم."

    if category == "shell":
        command = _flatten_action_value(args.get("command", ""))
        if mode == "routine_auto" and _has_explicit_setup_intent(request):
            if _is_project_start_command(name, args):
                return "allow", "تشغيل START_WINDOWS.bat من جذر مشروع Aurora المحدد صراحةً؛ لن تُطلب موافقة إضافية على مشغّل المشروع."
            if _is_project_requirements_install(name, args):
                return "allow", "تثبيت الاعتماديات من requirements.txt داخل .venv للمشروع المحدد صراحةً."
        # High-risk expressions are already held above. Routine test/version commands need an explicit dev task.
        no_shell_metacharacters = not re.search(r"[&|<>^%$()`!\r\n]", command)
        safe_read_or_test_command = no_shell_metacharacters and bool(re.fullmatch(
            r"(?is)\s*(?:"
            r"python(?:\.exe)?\s+-m\s+unittest\s+discover\s+-s\s+tests(?:\s+-(?:q|v))?|"
            r"python(?:\.exe)?\s+-m\s+compileall(?:\s+-q)?(?:\s+\.)?|"
            r"python(?:\.exe)?\s+-m\s+pytest(?:\s+-q)?(?:\s+tests)?|"
            r"python(?:\.exe)?\s+--version|pip(?:\.exe)?\s+--version|streamlit\s+--version|"
            r"git\s+(?:status|diff|log)(?:\s+--short)?"
            r")\s*", command
        ))
        if safe_read_or_test_command and _request_authorizes_action("shell", request):
            return "allow", "أمر فحص/اختبار معروف ومحدود ضمن طلب التطوير الحالي."
        if re.search(r"(?i)(?:pip(?:\.exe)?\s+install|START_WINDOWS\.bat)", command):
            explicit_setup_or_start = bool(re.search(
                r"(?i)(?:\b(?:install|setup|start|launch|run)\s+(?:the\s+)?(?:dependencies|requirements|aurora|assistant|application)|"
                r"(?:ثبت|تثبيت)\s+(?:الاعتماديات|المتطلبات)|(?:شغل|شغّل|ابدأ|افتح)\s+(?:المساعد|اورورا|أورورا|Aurora))", request
            ))
            if explicit_setup_or_start and not _request_forbids_action("shell", request):
                return "review", "طلب الإعداد أو التشغيل واضح، لكن الأمر يغيّر البيئة أو يطلق التطبيق؛ راجع التفاصيل قبل التنفيذ."
        return "review", "تنفيذ shell بصلاحيات حساب Windows قد يغير النظام؛ يلزم مراجعة الأمر وتفويضه."

    if category == "launch":
        raw_program = str(args.get("program", "")).strip().replace("/", "\\")
        program = raw_program.rsplit("\\", 1)[-1].lower()
        aliases = {
            "terminal64.exe": ("mt5", "metatrader 5", "ميتاتريدر", "ميتاتريدر 5", "ام تي 5", "mt5"),
            "terminal.exe": ("mt5", "metatrader 5", "ميتاتريدر", "ميتاتريدر 5", "ام تي 5", "mt5"),
            "metaeditor64.exe": ("metaeditor", "meta editor", "ميتا اديتور", "محرر mql5"),
            "metaeditor.exe": ("metaeditor", "meta editor", "ميتا اديتور", "محرر mql5"),
            "chrome.exe": ("chrome", "كروم", "google chrome"),
            "notepad.exe": ("notepad", "المفكرة", "دفتر الملاحظات"),
            "telegram.exe": ("telegram", "تليجرام", "تلغرام"),
            "whatsapp.exe": ("whatsapp", "واتساب"),
        }
        requested_names = aliases.get(program, (program.removesuffix(".exe"),))
        contains_path = "\\" in raw_program or "/" in raw_program or ":" in raw_program
        explicit_path = bool(raw_program and re.search(re.escape(raw_program), request, re.IGNORECASE))
        if contains_path and not explicit_path:
            return "review", "المسار التنفيذي الكامل غير مذكور في طلب المستخدم؛ يلزم التحقق من هوية الملف قبل تشغيله."
        if any(alias and re.search(re.escape(alias), request, re.IGNORECASE) for alias in requested_names):
            return "allow", "اسم البرنامج أو اسمه البديل مطلوب صراحةً في طلب المستخدم الحالي."
        return "review", "تشغيل برنامج لم يطلبه المستخدم صراحةً يحتاج إلى مراجعة."

    return "allow", "لا يظهر من معاملات الأداة أثر حساس يحتاج إلى بوابة موافقة إضافية."


def action_requires_approval(tool_name: str, args: dict | None = None, mode: str = "balanced") -> bool:
    """Compatibility wrapper; new integrations should inspect tool_action_decision()."""
    return tool_action_decision(tool_name, args, user_request="", mode=mode)[0] != "allow"
