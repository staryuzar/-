@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
rem Keep pip download cache and temporary installer files on the bundle drive (e.g. E:).
if not exist ".pip-cache" mkdir ".pip-cache"
if not exist ".tmp" mkdir ".tmp"
if not exist ".selenium-cache" mkdir ".selenium-cache"
set "PIP_CACHE_DIR=%~dp0.pip-cache"
set "TEMP=%~dp0.tmp"
set "TMP=%~dp0.tmp"
rem Keep Selenium Manager driver/browser cache on the bundle drive too.
set "SE_CACHE_PATH=%~dp0.selenium-cache"

echo =====================================================
echo   Aurora Control Room v2.4.0 - OPERATIONS CENTER
echo =====================================================
where py >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python Launcher ^(py.exe^) was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
  echo During installation, enable the Python Launcher and Add Python to PATH.
  pause
  exit /b 1
)
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo [ERROR] Python 3.10 or newer is required.
  pause
  exit /b 1
)
py -3 -c "import sqlite3; print('SQLite module OK; engine:', sqlite3.sqlite_version)"
if errorlevel 1 (
  echo [ERROR] This Python build does not provide the standard-library sqlite3 module.
  echo Install the full official Python distribution from https://www.python.org/downloads/windows/
  echo SQLite is not a separate Aurora pip dependency; do not install an unrelated sqlite3 package.
  pause
  exit /b 1
)

set NEW_ENV=0
if not exist ".env" (
  copy ".env.example" ".env" >nul
  set NEW_ENV=1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating isolated Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto failed
)

echo [2/5] Choosing one data location and migrating old C: data to E: if safe...
".venv\Scripts\python.exe" setup_data.py
if errorlevel 1 goto failed

if "%NEW_ENV%"=="1" (
  echo.
  echo A .env file was created. Add your Gemini API key in GEMINI_API_KEY, save it, then run START_WINDOWS.bat again.
  notepad ".env"
  pause
  exit /b 0
)

rem Install/upgrade packages only once per package release, not on every launch.
rem To reinstall after editing requirements.txt, delete .venv\.aurora-deps-v240.ok.
if exist ".venv\.aurora-deps-v240.ok" goto run_assistant

echo [3/5] Preparing pip for the first dependency setup...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed

echo [4/5] Installing project dependencies. Internet access is required for first setup...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
> ".venv\.aurora-deps-v240.ok" echo dependencies-installed-for-v2.4.0

:run_assistant
echo [5/5] Starting the local chat room at http://127.0.0.1:8501
echo Keep this window open while using the assistant.
".venv\Scripts\python.exe" -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --browser.gatherUsageStats false
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
echo [ERROR] Startup failed. Copy the complete error text before closing this window.
echo If pip reports a DNS/network error, check your internet connection and retry.
pause
exit /b 1
