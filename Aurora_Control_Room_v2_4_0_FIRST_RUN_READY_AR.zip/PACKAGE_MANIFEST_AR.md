# فهرس ملفات Aurora Control Room v2.4.0 — تهيئة أول تشغيل

عدد الملفات المضمنة في ZIP: **73** (يشمل هذا الفهرس وقائمة SHA-256).

الحزمة لا تضم ملف `.env` شخصيًا أو قاعدة SQLite للمستخدم أو بيئة `.venv` أو ملفات مؤقتة. تنشئ `START_WINDOWS.bat` قاعدة البيانات على الجهاز في أول تشغيل.

| الملف | الدور |
|---|---|
| `.env.example` | قالب إعدادات دون مفاتيح سرية. |
| `.gitignore` | استثناء ملفات الأسرار والبيانات المحلية والكاش. |
| `CHANGELOG_AR.md` | سجل التغييرات. |
| `DEPARTMENT_REVIEW_REPORT_V240_AR.md` | ملاحظات الأقسام والإصلاحات المغلقة. |
| `DIAGNOSE_WINDOWS.bat` | تشغيل فحص البيئة وقاعدة البيانات. |
| `ENGINEERING_COUNCIL_AR.md` | تقرير مجلس الهندسة والقبول. |
| `FINAL_QA_REPORT_V240_AR.md` | تقرير ضمان الجودة النهائي. |
| `FIRST_RUN_DATA_SETUP_AR.md` | شرح أول تشغيل ومحتويات مجلد E. |
| `GENERAL_MANAGER_ROADMAP_AR.md` | الرؤية وترتيب الأولويات. |
| `MOVE_DATA_TO_E.bat` | ترحيل اختياري لبيانات إصدار قديم؛ غير مطلوب لتثبيت جديد. |
| `OPERATIONS_CENTER_GUIDE_AR.md` | دليل غرفة العمليات. |
| `PATCH_REPORT_AR.md` | سجل الإصلاحات الأخيرة. |
| `PRODUCT_ARCHITECTURE_AND_CORRECT_BEHAVIOR_AR.md` | معمارية السلوك الصحيح. |
| `README_AR.md` | دليل بدء الاستخدام والتكاملات والحدود. |
| `RELEASE_ACCEPTANCE_GATES_AR.md` | بوابات قبول الإصدار. |
| `RELEASE_NOTES_AR.md` | ملاحظات الإصدار. |
| `RUN_TESTS_WINDOWS.bat` | تشغيل اختبارات الوحدة في Windows. |
| `SQLITE_ARCHITECTURE_AR.md` | معمارية SQLite الواحدة وتهيئة أول تشغيل. |
| `STARTER_KNOWLEDGE_CATALOG_AR.md` | كتالوج الإجراءات والذكريات الأولية. |
| `START_WINDOWS.bat` | الإعداد الأول وتهيئة البيانات وتثبيت الاعتماديات وتشغيل الواجهة. |
| `TEST_LOG_EN_AR.txt` | نتائج الاختبار بالإنجليزية والعربية والقيود. |
| `TEST_RESULTS_AR.txt` | ملخص الاختبارات المحلية. |
| `UPDATE_STEPS_AR.txt` | خطوات الإعداد والتشغيل والتحقق. |
| `VERSION.txt` | رقم الإصدار. |
| `VERSION_AR.txt` | رقم الإصدار بالعربية. |
| `WEB_RESEARCH_SOURCES_V240_AR.md` | مصادر التوثيق الرسمي التي راجعتها الهندسة. |
| `app.py` | واجهة المحادثة، دورة الأدوات، مزود النموذج وغرفة العمليات. |
| `app_paths.py` | المصدر الواحد لمسار البيانات النشط. |
| `assistant_core.py` | منطق الرسائل وسياق الأدوات ونقاط الاستئناف. |
| `browser_control.py` | التحكم في Chrome/Selenium وأسماء الخدمات. |
| `builtin_knowledge.py` | 13 إجراءً و8 ذكريات عربية أولية تزرع بشكل تكراري آمن. |
| `conversation_store.py` | حفظ المحادثات داخل SQLite الموحدة. |
| `database_manager.py` | تهيئة قاعدة واحدة وترحيل قواعد النسخ القديمة. |
| `diagnose.py` | فحص تشخيصي مستقل من سطر الأوامر. |
| `gemini_diagnostics.py` | فحوص اتصال Gemini وتشخيصه. |
| `gemini_native_client.py` | عميل Gemini والأدوات والمحتوى متعدد الوسائط. |
| `image_support.py` | التحقق من الصور وإرفاقها بمزودي النموذج. |
| `long_term_memory.py` | الذاكرة طويلة المدى والإجراءات في SQLite. |
| `memory_context.py` | استرجاع الذاكرة والإجراء المناسب للسياق. |
| `move_data_to_e.py` | منطق النسخ الاحتياطي والتحقق عند نقل بيانات قديمة. |
| `operations_center.py` | فحوص النظام وسجل الأحداث وحالة المهام. |
| `provider_config.py` | اختيار مزود النموذج والتحقق من الإعدادات. |
| `rate_limit.py` | إدارة مؤقتات التهدئة وحدود المزود. |
| `requirements.txt` | اعتماديات Python وحدود الإصدارات. |
| `security_utils.py` | قرار السماح/المراجعة/المنع ونطاقات الروابط. |
| `setup_data.py` | إنشاء المجلد وقاعدة SQLite والجداول والذاكرة في أول تشغيل. |
| `tests/test_app_paths.py` | اختبارات وحدة وانحدار: app paths. |
| `tests/test_app_smoke.py` | اختبارات وحدة وانحدار: app smoke. |
| `tests/test_assistant_core.py` | اختبارات وحدة وانحدار: assistant core. |
| `tests/test_browser_control.py` | اختبارات وحدة وانحدار: browser control. |
| `tests/test_builtin_knowledge.py` | اختبارات وحدة وانحدار: builtin knowledge. |
| `tests/test_chrome_tab_aliases.py` | اختبارات وحدة وانحدار: chrome tab aliases. |
| `tests/test_conversation_store.py` | اختبارات وحدة وانحدار: conversation store. |
| `tests/test_database_manager.py` | اختبارات وحدة وانحدار: database manager. |
| `tests/test_dependency_security_floors.py` | اختبارات وحدة وانحدار: dependency security floors. |
| `tests/test_gemini_diagnostics.py` | اختبارات وحدة وانحدار: gemini diagnostics. |
| `tests/test_gemini_native_client.py` | اختبارات وحدة وانحدار: gemini native client. |
| `tests/test_image_support.py` | اختبارات وحدة وانحدار: image support. |
| `tests/test_integration_wiring.py` | اختبارات وحدة وانحدار: integration wiring. |
| `tests/test_long_term_memory.py` | اختبارات وحدة وانحدار: long term memory. |
| `tests/test_memory_context.py` | اختبارات وحدة وانحدار: memory context. |
| `tests/test_move_data_to_e.py` | اختبارات وحدة وانحدار: move data to e. |
| `tests/test_operations_center.py` | اختبارات وحدة وانحدار: operations center. |
| `tests/test_provider_config.py` | اختبارات وحدة وانحدار: provider config. |
| `tests/test_rate_limit.py` | اختبارات وحدة وانحدار: rate limit. |
| `tests/test_security_utils.py` | اختبارات وحدة وانحدار: security utils. |
| `tests/test_setup_data.py` | اختبارات وحدة وانحدار: setup data. |
| `tests/test_tool_executor.py` | اختبارات وحدة وانحدار: tool executor. |
| `tests/test_ui_design.py` | اختبارات وحدة وانحدار: ui design. |
| `tool_executor.py` | التنفيذ الفعلي لأدوات Windows والويب والملفات والذاكرة. |
| `windows_tools.py` | أدوات Windows واللوحة والحافظة والتقاط الشاشة. |
| `PACKAGE_MANIFEST_AR.md` | فهرس ملفات هذه الحزمة؛ يسرد المحتويات والأدوار. |
| `PACKAGE_SHA256SUMS_AR.txt` | قائمة SHA-256 للتحقق من جميع الملفات الأخرى. |

## الإعداد الأول على جهاز المستخدم
- فك الحزمة مباشرة إلى `E:\mosaeed` ثم شغّل `START_WINDOWS.bat`.
- ينشئ الإعداد `E:\AuroraData\LocalAssistant\aurora.sqlite3` إذا كان E متاحًا، ويهيئ الجداول والإجراءات الأولية قبل إدخال مفتاح النموذج.
- `MOVE_DATA_TO_E.bat` مخصص فقط لنقل بيانات إصدار قديم؛ غير مطلوب في تثبيت جديد.
- `PACKAGE_SHA256SUMS_AR.txt` يحتوي بصمات SHA-256 لكل الملفات عدا ملف البصمات نفسه.
