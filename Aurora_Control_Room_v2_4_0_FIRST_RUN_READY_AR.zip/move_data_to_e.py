"""Safely copy Aurora local data to E: and point the local .env at it.

Run this only after closing Aurora Control Room. Source data is intentionally
retained as a rollback copy; this tool never deletes the old directory.
"""
from __future__ import annotations

import os
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterable


DB_NAMES = ("chat_history.sqlite3", "long_term_memory.sqlite3")
SIDECAR_SUFFIXES = ("-wal", "-shm", "-journal")


def _read_dotenv_key(path: Path, key: str) -> str | None:
    if not path.is_file():
        return None
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if name.strip() == key:
            return value.strip().strip('"').strip("'")
    return None


def _is_db_sidecar(name: str) -> bool:
    return any(name == db + suffix for db in DB_NAMES for suffix in SIDECAR_SUFFIXES)


def _copy_sqlite_database(source: Path, target: Path) -> dict[str, object]:
    """Use SQLite's online backup API so committed WAL data is included."""
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".migrating")
    if temporary.exists():
        temporary.unlink()
    src = sqlite3.connect(str(source), timeout=30)
    dst = None
    try:
        dst = sqlite3.connect(str(temporary), timeout=30)
        src.backup(dst)
        dst.commit()
        integrity = str(dst.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity.lower() != "ok":
            raise RuntimeError(f"Integrity check failed for {source.name}: {integrity}")
        src_tables = [r[0] for r in src.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )]
        dst_tables = [r[0] for r in dst.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )]
        if src_tables != dst_tables:
            raise RuntimeError(f"Table verification failed for {source.name}")
        row_counts: dict[str, int] = {}
        for table in src_tables:
            # Table names originate from SQLite metadata; quote embedded double quotes.
            quoted = '"' + table.replace('"', '""') + '"'
            src_count = int(src.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0])
            dst_count = int(dst.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0])
            if src_count != dst_count:
                raise RuntimeError(f"Row-count verification failed for {source.name}, table {table}")
            row_counts[table] = dst_count
        dst.close()
        dst = None
        src.close()
        os.replace(temporary, target)
        return {"database": source.name, "integrity": integrity, "tables": row_counts}
    except Exception:
        if dst is not None:
            dst.close()
        src.close()
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _copy_other_files(source: Path, staging: Path) -> int:
    copied = 0
    deferred_dbs: list[tuple[Path, Path]] = []
    for path in source.rglob("*"):
        # Don't follow a junction/symlink outside the data directory.
        if path.is_symlink():
            continue
        relative = path.relative_to(source)
        if path.is_dir():
            (staging / relative).mkdir(parents=True, exist_ok=True)
            continue
        if not path.is_file():
            continue
        if len(relative.parts) == 1 and path.name in DB_NAMES:
            deferred_dbs.append((path, staging / relative))
            continue
        if len(relative.parts) == 1 and _is_db_sidecar(path.name):
            continue
        destination = staging / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        copied += 1
    for source_db, target_db in deferred_dbs:
        _copy_sqlite_database(source_db, target_db)
        copied += 1
    return copied


def _set_data_dir_in_env(env_file: Path, target: Path, example_file: Path | None = None) -> Path | None:
    env_file.parent.mkdir(parents=True, exist_ok=True)
    if not env_file.exists():
        if example_file and example_file.is_file():
            content = example_file.read_text(encoding="utf-8", errors="replace")
        else:
            content = ""
    else:
        content = env_file.read_text(encoding="utf-8", errors="replace")
    backup = None
    if env_file.exists():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = env_file.with_name(f"{env_file.name}.backup_before_data_move_{stamp}")
        shutil.copy2(env_file, backup)
    lines = content.splitlines()
    output: list[str] = []
    inserted = False
    for line in lines:
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key = line.split("=", 1)[0].strip()
            if key == "AURORA_DATA_DIR":
                if not inserted:
                    output.append(f"AURORA_DATA_DIR={target.as_posix()}")
                    inserted = True
                continue
        output.append(line)
    if not inserted:
        if output and output[-1].strip():
            output.append("")
        output.append("# Aurora data directory moved by move_data_to_e.py")
        output.append(f"AURORA_DATA_DIR={target.as_posix()}")
    env_file.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    return backup


def migrate_data(source: Path, target: Path, env_file: Path, example_file: Path | None = None) -> dict[str, object]:
    source = source.expanduser()
    target = target.expanduser()
    env_file = env_file.expanduser()
    if not source.is_dir():
        raise FileNotFoundError(f"Source data folder does not exist: {source}")
    source_resolved = source.resolve()
    target_resolved = target.resolve()
    if source_resolved == target_resolved:
        raise ValueError("Source and target folders are identical; no migration is needed.")
    if target.exists() and any(target.iterdir()):
        raise FileExistsError(f"Target is not empty; refusing to overwrite: {target}")
    staging = target.with_name(target.name + ".migration_tmp")
    if staging.exists():
        raise FileExistsError(f"A previous temporary migration folder exists; inspect it first: {staging}")
    target.parent.mkdir(parents=True, exist_ok=True)
    # Estimate the complete source footprint, including SQLite WAL sidecars;
    # the backup API may fold WAL pages into the destination database.
    source_bytes = sum(p.stat().st_size for p in source.rglob("*") if p.is_file() and not p.is_symlink())
    free_bytes = shutil.disk_usage(target.parent).free
    required_bytes = source_bytes + max(64 * 1024 * 1024, int(source_bytes * 0.10))
    if free_bytes < required_bytes:
        raise OSError(
            f"Target drive has insufficient free space: need about {required_bytes} bytes, "
            f"have {free_bytes} bytes. No target data was activated."
        )
    staging.mkdir(parents=True, exist_ok=False)
    try:
        copied = _copy_other_files(source, staging)
        db_reports = []
        for db_name in DB_NAMES:
            db_path = staging / db_name
            if db_path.is_file():
                con = sqlite3.connect(str(db_path), timeout=30)
                try:
                    integrity = str(con.execute("PRAGMA integrity_check").fetchone()[0])
                    if integrity.lower() != "ok":
                        raise RuntimeError(f"Integrity check failed for {db_name}: {integrity}")
                    tables = [r[0] for r in con.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
                    )]
                    db_reports.append({"database": db_name, "integrity": integrity, "table_count": len(tables)})
                finally:
                    con.close()
        if not any(staging.iterdir()):
            raise RuntimeError("No files were found to migrate; target was not activated.")
        if target.exists():
            target.rmdir()  # It was verified empty above.
        staging.rename(target)
        backup = _set_data_dir_in_env(env_file, target, example_file)
        return {
            "source": str(source), "target": str(target), "files_copied": copied,
            "databases": db_reports, "env_file": str(env_file),
            "env_backup": str(backup) if backup else None,
            "source_retained": True,
        }
    except Exception:
        # The source is only copied, never moved. Remove only the staging folder
        # this invocation created, so a retry is possible without touching user data.
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise


def main() -> int:
    root = Path(__file__).resolve().parent
    env_file = root / ".env"
    explicit_env = os.environ.get("AURORA_DATA_DIR", "").strip()
    configured_in_file = _read_dotenv_key(env_file, "AURORA_DATA_DIR")
    target = Path(r"E:\AuroraData\LocalAssistant")
    if explicit_env:
        source = Path(os.path.expandvars(os.path.expanduser(explicit_env.strip().strip('"').strip("'"))))
    elif configured_in_file:
        source = Path(os.path.expandvars(os.path.expanduser(configured_in_file)))
    else:
        # This script's explicit purpose is migration from the historical C:\ path.
        # Do not use get_app_data_dir() here because modern defaults prefer E: on Windows.
        local = os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))
        source = Path(local) / "LocalAssistant"

    print("Aurora — نقل مجلد البيانات إلى القرص E")
    print("أغلق Aurora Control Room قبل المتابعة. ستبقى النسخة القديمة في C كنسخة احتياطية.")
    print(f"المصدر: {source}")
    print(f"الهدف:  {target}")
    if os.name == "nt" and not Path("E:/").exists():
        print("خطأ: القرص E غير موجود أو غير متاح. لم يتم نقل أي بيانات.")
        return 2
    if source.resolve() == target.resolve():
        print("البيانات موجودة بالفعل في الهدف المحدد.")
        return 0
    try:
        result = migrate_data(source, target, env_file, root / ".env.example")
    except Exception as exc:
        print(f"فشل النقل بأمان: {type(exc).__name__}: {exc}")
        print("لم يتم حذف مجلد المصدر. عالج السبب ثم أعد المحاولة.")
        return 1
    print("\nتم النقل والتحقق بنجاح:")
    print(f"الملفات المنسوخة: {result['files_copied']}")
    for db in result["databases"]:
        print(f"قاعدة {db['database']}: integrity_check={db['integrity']}; الجداول={db['table_count']}")
    print(f"مسار البيانات الجديد: {result['target']}")
    print(f"تم تحديث إعدادات: {result['env_file']}")
    if result["env_backup"]:
        print(f"نسخة احتياطية من الإعدادات: {result['env_backup']}")
    print("لم تُحذف بيانات C. شغّل START_WINDOWS.bat، تحقق من الذاكرة والمحادثات، ثم احذف النسخة القديمة يدويًا فقط إذا تأكدت من سلامة E.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
