"""Pure, testable conversation and audit helpers (no Streamlit dependency)."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Mapping
from urllib.parse import urlsplit, urlunsplit


def json_list(raw: Any) -> list:
    try:
        value = json.loads(raw or "[]") if isinstance(raw, (str, bytes, bytearray)) else raw
    except (TypeError, json.JSONDecodeError):
        return []
    return value if isinstance(value, list) else []


def conversation_from_row(row: Mapping[str, Any]) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "messages": json_list(row["messages_json"]),
        "log": json_list(row["log_json"]),
        "pending": json_list(row["pending_json"]),
    }


def _tool_history_checkpoint(messages: list[dict]) -> str:
    """Summarize older tool activity without copying private tool payloads into prompts."""
    output_by_id: dict[str, dict] = {}
    for item in messages:
        if item.get("role") != "tool":
            continue
        try:
            value = json.loads(item.get("content", "{}") or "{}")
            output_by_id[str(item.get("tool_call_id", ""))] = value if isinstance(value, dict) else {}
        except (TypeError, json.JSONDecodeError):
            output_by_id[str(item.get("tool_call_id", ""))] = {}

    lines = []
    for item in messages:
        if item.get("role") != "assistant":
            continue
        for call in item.get("tool_calls", []) or []:
            if not isinstance(call, dict):
                continue
            function = call.get("function", {})
            if not isinstance(function, dict):
                continue
            name = str(function.get("name", "unknown_tool"))[:80]
            result = output_by_id.get(str(call.get("id", "")), {})
            if result.get("ok"):
                state = "نجحت الأداة" + (" وتم التحقق من أثرها" if result.get("effect_verified") else " لكن الأثر النهائي غير متحقق")
            elif result:
                state = "فشلت الأداة أو رُفض الإجراء"
            else:
                state = "لا توجد نتيجة محفوظة لهذه الخطوة"
            message = str(result.get("message", "") or "").replace("\n", " ").replace("\r", " ")[:110]
            lines.append(f"- {name}: {state}" + (f"؛ {message}" if message else ""))

    if not lines:
        return "نقطة استئناف تلقائية: سياق المهمة طويل؛ تابع من آخر الإجراءات، ولا تفترض نجاح خطوة بلا نتيجة محفوظة."
    return "نقطة استئناف تلقائية — ملخص الخطوات الأقدم (حُذفت الحمولات الخاصة والتفاصيل الطويلة):\n" + "\n".join(lines[-12:])


def messages_for_model(messages: list[dict], max_messages: int = 40) -> list[dict]:
    """Bound model history while preserving valid recent tool-call/result pairs."""
    clean = [dict(m) for m in messages if isinstance(m, dict) and m.get("role") in {"system", "user", "assistant", "tool"}]
    # Four messages are the minimum safe window for user + checkpoint + tool call + tool result.
    max_messages = max(4, int(max_messages))
    if len(clean) <= max_messages:
        return clean

    cut = len(clean) - max_messages
    boundaries = [i for i, item in enumerate(clean[:cut + 1]) if item.get("role") == "user"]
    start = boundaries[-1] if boundaries else cut
    while start < len(clean) and clean[start].get("role") == "tool":
        start += 1
    recent = clean[start:]
    if len(recent) <= max_messages:
        return recent

    # One long task can contain hundreds of tool steps but only one user message.
    # Keep the original request, a compact checkpoint, and the newest complete tool batch(es).
    first_user = next((item for item in recent if item.get("role") == "user"), recent[0])
    call_indices = [i for i, item in enumerate(recent) if item.get("role") == "assistant" and item.get("tool_calls")]
    for index in reversed(call_indices):
        tail = recent[index:]
        if len(tail) <= max_messages - 2:
            checkpoint = {"role": "assistant", "content": _tool_history_checkpoint(recent[1:index])}
            return [first_user, checkpoint, *tail]

    if call_indices:
        # A single batch may contain many parallel calls. Keep only the newest calls
        # with their matching tool responses, otherwise a large batch could bypass the cap.
        index = call_indices[-1]
        batch = dict(recent[index])
        all_calls = [call for call in (batch.get("tool_calls") or []) if isinstance(call, dict)]
        keep_count = max(1, max_messages - 3)
        # For Gemini 3, a parallel function-call batch may carry thoughtSignature only
        # on its first call. Preserve any signed call that fits, then fill remaining
        # slots from the newest calls. Keep matching tool replies for every retained ID.
        selected = {str(call.get("id", "")): call for call in all_calls[-keep_count:]}
        signed_calls = [call for call in all_calls if call.get("thoughtSignature") or call.get("thought_signature")]
        for signed_call in signed_calls:
            signed_id = str(signed_call.get("id", ""))
            if signed_id in selected:
                continue
            removable_id = next((
                str(call.get("id", "")) for call in all_calls
                if str(call.get("id", "")) in selected
                and not (call.get("thoughtSignature") or call.get("thought_signature"))
            ), None)
            if removable_id is not None:
                selected.pop(removable_id, None)
                selected[signed_id] = signed_call
        kept_ids = set(selected)
        kept_calls = [call for call in all_calls if str(call.get("id", "")) in kept_ids]
        batch["tool_calls"] = kept_calls
        paired_results = [item for item in recent[index + 1:] if item.get("role") == "tool" and str(item.get("tool_call_id", "")) in kept_ids]
        checkpoint = {"role": "assistant", "content": _tool_history_checkpoint(recent[1:index])}
        return [first_user, checkpoint, batch, *paired_results]

    # Non-tool histories can be trimmed to the recent safe tail; no tool protocol is orphaned.
    return recent[-max_messages:]


def _redact_url(value: Any) -> str:
    raw = str(value or "")
    try:
        parts = urlsplit(raw)
        if parts.scheme.lower() not in {"http", "https"} or not parts.netloc:
            return raw[:400]
        return urlunsplit((parts.scheme, parts.netloc, parts.path, "[query hidden]" if parts.query else "", "[fragment hidden]" if parts.fragment else ""))
    except Exception:
        return "[URL hidden]"

def safe_url_for_display(raw_url: Any) -> str:
    """Keep enough URL context to recognize a site while hiding query/fragment secrets."""
    return _redact_url(raw_url)

def redact_tool_log(name: str, args: Any, output: Any) -> tuple[dict, dict]:
    safe_args = dict(args) if isinstance(args, Mapping) else {"value": str(args)}
    safe_output = dict(output) if isinstance(output, Mapping) else {"value": str(output)}
    for field in ("url", "current_url", "final_url"):
        if field in safe_args:
            safe_args[field] = _redact_url(safe_args[field])
        if field in safe_output:
            safe_output[field] = _redact_url(safe_output[field])
    hidden_arg_fields = {
        "browser_type_text": {"text"},
        "type_window_text": {"text"},
        "create_draft": {"content"},
        "run_local_command": {"command"},
        "browser_search_web": {"query"},
        "memory_save": {"content"},
        "procedure_save": {"steps", "intent", "triggers", "verification", "fallback"},
        "procedure_update": {"steps", "intent", "triggers", "verification", "fallback"},
        "procedure_record_result": {"notes"},
    }
    for field in hidden_arg_fields.get(name, set()):
        if field in safe_args:
            value = str(safe_args[field])
            safe_args[field] = f"[مخفى؛ {len(value)} حرفًا]"
    for field in ("content", "text", "stdout", "stderr", "page_text", "controls", "windows", "results", "procedures"):
        if field in safe_output:
            value = str(safe_output[field])
            safe_output[field] = f"[مخفى من السجل؛ {len(value)} حرفًا]"
    if "_image_attachment" in safe_output:
        safe_output["_image_attachment"] = "[مرفق صورة محلي؛ المسار محجوب من سجل الأدوات]"
    if name == "browser_read_page" and "text" in safe_output:
        safe_output["text"] = "[محتوى الصفحة الخاصة غير محفوظ في سجل العمليات]"
    return safe_args, safe_output


def action_summary(tool_name: str, args: Mapping[str, Any]) -> tuple[str, str]:
    """Return an Arabic action title and user-facing impact warning for approval cards."""
    labels = {
        "browser_open_url": "فتح موقع في متصفح المساعد",
        "browser_read_page": "قراءة محتوى الصفحة الحالية",
        "browser_click_text": "النقر على عنصر في الصفحة",
        "browser_type_text": "كتابة نص في الصفحة",
        "browser_press_key": "ضغط مفتاح في المتصفح",
        "browser_search_web": "البحث على الويب",
        "read_workspace_file": "قراءة ملف وإرسال محتواه للتحليل",
        "create_draft": "إنشاء مسودة ملف",
        "delete_workspace_file": "حذف ملف من مساحة العمل",
        "launch_program": "تشغيل برنامج على الجهاز",
        "run_local_command": "تنفيذ أمر محلي على الجهاز",
        "run_shell_command": "تنفيذ أمر عبر مفسر النظام بصلاحيات حساب Windows",
        "list_open_windows": "قراءة عناوين النوافذ المفتوحة",
        "switch_existing_chrome_tab": "الانتقال إلى علامة موجودة في Chrome الشخصي",
        "read_existing_chrome_page": "قراءة النص الظاهر في Chrome الشخصي",
        "inspect_window": "فحص عناصر نافذة برنامج",
        "click_window_control": "النقر على عنصر في برنامج Windows",
        "type_window_text": "كتابة نص في برنامج Windows",
        "press_window_key": "ضغط اختصار لوحة مفاتيح في Windows",
    }
    name = labels.get(tool_name, f"تنفيذ الأداة: {tool_name}")
    warnings = []
    if tool_name in {"browser_read_page", "read_existing_chrome_page", "read_workspace_file", "inspect_window", "list_open_windows"}:
        warnings.append("قد تحتوي النتيجة على معلومات خاصة، وسيُرسل ما يلزم منها إلى مزود النموذج المحدد (Gemini أو OpenRouter).")
    if tool_name in {"browser_click_text", "browser_press_key", "click_window_control", "press_window_key"}:
        warnings.append("قد يؤدي النقر أو المفتاح إلى إرسال رسالة أو حذف/نشر محتوى أو تنفيذ إجراء خارجي. راجع العنصر والسياق قبل الموافقة.")
    if tool_name == "browser_type_text":
        warnings.append("راجع النص المعروض؛ ستتم كتابته في الحقل النشط وقد يتضمن بيانات خاصة.")
    if tool_name == "type_window_text":
        warnings.append("سيتم لصق النص في عنصر النافذة المحددة. تحقق من النافذة والحقل قبل المتابعة.")
    if tool_name in {"run_local_command", "run_shell_command"}:
        warnings.append("الأمر يعمل بصلاحيات حساب Windows نفسه، وقد يقرأ أو يغيّر ملفات خارج مساحة العمل أو إعدادات النظام. راجع الأمر كاملًا وافهم أثره قبل الموافقة.")
    if tool_name == "launch_program":
        warnings.append("سيتم تشغيل برنامج على جهازك؛ تحقّق من الاسم والمسار والمعاملات.")
    if tool_name == "browser_open_url":
        warnings.append("سيُفتح موقع عام. إذا طلب تسجيل الدخول، سجّل الدخول بنفسك وتحقق من النطاق.")
    details = []
    for key in ("url", "_context_url", "text", "query", "program", "window_title", "control_text", "path", "filename"):
        if args.get(key) is not None:
            value = str(args[key])
            if key in {"url", "_context_url"}:
                value = _redact_url(value)
            if len(value) > 600:
                value = value[:600] + "…"
            details.append(f"{key}: {value}")
    if tool_name in {"run_local_command", "run_shell_command"}:
        details.append("command: " + json.dumps(args.get("command", [] if tool_name == "run_local_command" else ""), ensure_ascii=False))
    if tool_name == "type_window_text":
        text = str(args.get("text", ""))
        details.append(f"النص ({len(text)} حرفًا): {text[:600]}{'…' if len(text)>600 else ''}")
    if tool_name == "browser_type_text":
        text = str(args.get("text", ""))
        details.append(f"النص ({len(text)} حرفًا): {text[:600]}{'…' if len(text)>600 else ''}")
    summary = "\n".join(details) if details else "راجع معاملات الأداة قبل الموافقة."
    warning = "\n\n⚠️ ".join(warnings) if warnings else "تحقق من المطلوب قبل الموافقة."
    return name, f"{warning}\n\n{summary}"



def redact_messages_for_storage(messages: list[dict]) -> list[dict]:
    """Redact private tool contents from SQLite while keeping in-memory model context intact."""
    safe = []
    tool_names: dict[str, str] = {}
    for message in messages:
        if not isinstance(message, dict):
            continue
        if message.get("role") == "assistant":
            for call in message.get("tool_calls", []) or []:
                try:
                    tool_names[str(call.get("id", ""))] = str(call.get("function", {}).get("name", ""))
                except Exception:
                    pass
    for source in messages:
        if not isinstance(source, dict):
            continue
        item = dict(source)
        if item.get("role") == "assistant" and item.get("tool_calls"):
            copied_calls = []
            for raw_call in item.get("tool_calls", []):
                call = dict(raw_call)
                function = dict(call.get("function", {}))
                tool_name = str(function.get("name", ""))
                try:
                    args = json.loads(function.get("arguments", "{}") or "{}")
                    if isinstance(args, dict):
                        redact_fields = {
                            "browser_type_text": ("text",),
                            "type_window_text": ("text",),
                            "create_draft": ("content",),
                            "run_local_command": ("command",),
                            "browser_search_web": ("query",),
                            "memory_save": ("content",),
                            "procedure_save": ("steps", "intent", "triggers", "verification", "fallback"),
                            "procedure_update": ("steps", "intent", "triggers", "verification", "fallback"),
                            "procedure_record_result": ("notes",),
                        }.get(tool_name, ())
                        for field in redact_fields:
                            if field in args:
                                raw_value = json.dumps(args[field], ensure_ascii=False)
                                if field == "command" and isinstance(args[field], list):
                                    args[field] = [f"[مخفى من سجل المحادثة؛ {len(args[field])} معاملات]"]
                                else:
                                    args[field] = f"[مخفى من سجل المحادثة؛ {len(raw_value)} حرفًا]"
                        if tool_name in {"browser_open_url"} and "url" in args:
                            args["url"] = _redact_url(args["url"])
                        function["arguments"] = json.dumps(args, ensure_ascii=False)
                except Exception:
                    pass
                call["function"] = function
                copied_calls.append(call)
            item["tool_calls"] = copied_calls
        elif item.get("role") == "tool":
            name = tool_names.get(str(item.get("tool_call_id", "")), "")
            try:
                output = json.loads(item.get("content", "{}") or "{}")
                if isinstance(output, dict):
                    redact_fields = {
                        "browser_read_page": ("text",),
                        "read_existing_chrome_page": ("text",),
                        "read_workspace_file": ("content",),
                        "run_local_command": ("stdout", "stderr"),
                        "inspect_window": ("controls",),
                        "list_open_windows": ("windows",),
                        "memory_search": ("results",),
                        "procedure_search": ("procedures",),
                    }.get(name, ())
                    for field in redact_fields:
                        if field in output:
                            raw_value = json.dumps(output[field], ensure_ascii=False)
                            output[field] = f"[مخفى من سجل المحادثة؛ {len(raw_value)} حرفًا]"
                    for field in ("url", "current_url", "final_url"):
                        if field in output:
                            output[field] = _redact_url(output[field])
                    item["content"] = json.dumps(output, ensure_ascii=False)
            except Exception:
                pass
        safe.append(item)
    return safe

def export_conversation_markdown(conv: Mapping[str, Any]) -> str:
    title = str(conv.get("title") or "محادثة")
    lines = [f"# {title}", ""]
    role_names = {"user": "المستخدم", "assistant": "المساعد"}
    for message in conv.get("messages", []):
        role = message.get("role")
        if role in role_names and message.get("content"):
            lines.extend([f"## {role_names[role]}", str(message.get("content", "")), ""])
    return "\n".join(lines)


def new_tool_result(ok: bool, verified: bool, message: str, **details) -> dict:
    return {"ok": bool(ok), "effect_verified": bool(verified), "message": str(message), **details}



def probe_model_connection(client: Any, model: str) -> str:
    """Send a minimal non-sensitive prompt to verify model connectivity and response shape."""
    model_name = str(model or "").strip()
    if not model_name:
        raise ValueError("اسم النموذج فارغ.")
    response = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": "أجب بكلمة واحدة فقط: متصل"}],
        max_tokens=12,
        temperature=0,
    )
    choices = getattr(response, "choices", None) or []
    if not choices:
        raise RuntimeError("وصل الاتصال لكن النموذج لم يُرجع أي اختيار.")
    message = getattr(choices[0], "message", None)
    content = getattr(message, "content", None)
    if not isinstance(content, str) or not content.strip():
        raise RuntimeError("وصل الاتصال لكن الرد النصي فارغ؛ قد لا يدعم النموذج هذا الطلب.")
    return content.strip()[:240]

def tool_call_fingerprint(name: str, args: Mapping[str, Any]) -> tuple[str, str]:
    """Stable per-batch identity used to suppress accidental duplicate tool calls."""
    return (str(name or ""), json.dumps(dict(args or {}), ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def tool_call_payload(call: Any) -> tuple[str, str, dict]:
    """Normalize OpenAI-compatible function-call objects for robust unit tests."""
    call_id = str(getattr(call, "id", "") or "")
    function = getattr(call, "function", None)
    name = str(getattr(function, "name", "") or "")
    raw_args = getattr(function, "arguments", "{}") or "{}"
    try:
        args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
        if not isinstance(args, dict):
            raise ValueError("يجب أن تكون معاملات الأداة كائن JSON.")
    except Exception as exc:
        args = {"_invalid_arguments": str(exc)}
    return call_id, name, args


def timestamp_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def rehydrate_pending_tool_calls(conversation: dict) -> None:
    """Restore true arguments from the approval queue after loading a redacted database history."""
    pending_by_id = {str(item.get("id", "")): item for item in conversation.get("pending", [])}
    if not pending_by_id:
        return
    for message in conversation.get("messages", []):
        if message.get("role") != "assistant":
            continue
        for call in message.get("tool_calls", []) or []:
            call_id = str(call.get("id", ""))
            item = pending_by_id.get(call_id)
            if item is None:
                continue
            function = call.setdefault("function", {})
            args = {key: value for key, value in (item.get("args", {}) or {}).items() if key != "_context_url"}
            function["arguments"] = json.dumps(args, ensure_ascii=False)


def resolve_approval_action(conversation: dict, pending_id: str, approved: bool, executor, logger=None) -> dict | None:
    """Resolve one pending approval; rejected actions are never sent to the executor."""
    item = next((p for p in conversation.get("pending", []) if p.get("id") == pending_id), None)
    if item is None:
        return None
    if approved:
        output = executor(item["name"], item.get("args", {}))
    else:
        output = new_tool_result(False, False, "رفض المستخدم تنفيذ الإجراء.")
    conversation["messages"].append({
        "role": "tool", "tool_call_id": item["id"],
        "content": json.dumps(output, ensure_ascii=False),
    })
    if logger:
        logger(conversation, item["name"], item.get("args", {}), output)
    conversation["pending"] = [p for p in conversation.get("pending", []) if p.get("id") != pending_id]
    return output
