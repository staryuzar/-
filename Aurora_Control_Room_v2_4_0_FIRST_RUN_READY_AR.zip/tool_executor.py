"""Local tool execution separated from Streamlit to enable offline simulation tests."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from urllib.parse import quote_plus, urlparse, urljoin
from typing import Callable, Any

from assistant_core import new_tool_result
from browser_control import (
    find_text_target, get_visible_page_text, key_code, page_read_warning,
    validate_current_page, validate_text_entry,
)
from security_utils import check_allowed_url
import windows_tools
from long_term_memory import LongTermMemory


class LocalToolExecutor:
    def __init__(
        self,
        workspace: str | Path,
        drafts_dir: str | Path,
        browser_provider: Callable[[], Any],
        *,
        resolve_dns: bool = True,
        browser_peeker: Callable[[], Any | None] | None = None,
        memory_path: str | Path | None = None,
    ):
        self.workspace = Path(workspace).resolve()
        self.drafts_dir = Path(drafts_dir).resolve()
        self.browser_provider = browser_provider
        self.browser_peeker = browser_peeker
        self.resolve_dns = resolve_dns
        self.memory = LongTermMemory(memory_path or (self.workspace.parent / "aurora.sqlite3"))
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.drafts_dir.mkdir(parents=True, exist_ok=True)

    def checked_workspace_path(self, raw_path: str) -> Path:
        raw = str(raw_path or "").strip()
        if not raw:
            raise ValueError("المسار فارغ.")
        candidate = (self.workspace / raw).resolve()
        if candidate != self.workspace and self.workspace not in candidate.parents:
            raise ValueError("المسار خارج مساحة عمل المساعد.")
        return candidate

    def _public_url(self, raw_url: str) -> str:
        return check_allowed_url(raw_url, resolve_dns=self.resolve_dns)

    @staticmethod
    def _url_context_key(raw_url: str) -> tuple:
        parsed = urlparse(str(raw_url or ""))
        path = parsed.path or "/"
        if path != "/":
            path = path.rstrip("/") or "/"
        return (parsed.scheme.lower(), (parsed.hostname or "").lower().rstrip("."), parsed.port, path, parsed.query, parsed.fragment)

    def _browser_for_context(self, args: dict):
        driver = self.browser_provider()
        expected = str(args.get("_context_url", "") or "").strip()
        current = str(getattr(driver, "current_url", "") or "")
        if expected:
            self._public_url(expected)
            if current in {"", "about:blank"}:
                # The app/browser may have restarted while approval was pending.
                driver.get(expected)
                current = str(getattr(driver, "current_url", "") or "")
            if self._url_context_key(current) != self._url_context_key(expected):
                raise ValueError("تغيّرت الصفحة منذ طلب الموافقة؛ لم أنفّذ الإجراء على الصفحة الجديدة. أعد الطلب بعد التحقق من الصفحة الحالية.")
        current = validate_current_page(driver, resolve_dns=self.resolve_dns)
        return driver, current

    def execute(self, name: str, args: dict | None = None) -> dict:
        args = args if isinstance(args, dict) else {}
        try:
            return self._execute(name, args)
        except Exception as exc:
            return new_tool_result(False, False, f"{type(exc).__name__}: {exc}")

    def _execute(self, name: str, args: dict) -> dict:
        if name == "capture_screen":
            attachment = windows_tools.capture_screen(self.workspace.parent / "Attachments")
            return new_tool_result(
                True, True,
                "التُقطت الشاشة الأساسية وحُفظت محليًا. ستُرسل الصورة إلى مزود النموذج المحدد لتحليلها ضمن الخطوة التالية.",
                _image_attachment=attachment,
            )

        if name == "memory_save":
            result = self.memory.save(
                title=args.get("title", ""), content=args.get("content", ""),
                category=args.get("category", "note"), tags=args.get("tags", ""),
                source=args.get("source", ""), record_key=args.get("record_key", ""),
            )
            return new_tool_result(True, True, "حُفظت المعلومة في الذاكرة المحلية الدائمة ويمكن استرجاعها في محادثة لاحقة.", **result)

        if name == "memory_search":
            query = str(args.get("query", ""))
            limit = int(args.get("limit", 8))
            results = self.memory.search(query, limit)
            return new_tool_result(True, True, f"تم البحث في الذاكرة المحلية؛ عدد النتائج: {len(results)}.", results=results, total_memories=self.memory.count())

        if name == "procedure_save":
            result = self.memory.save_procedure(
                procedure_key=args.get("procedure_key", ""), name=args.get("name", ""),
                intent=args.get("intent", ""), steps=args.get("steps", []),
                triggers=args.get("triggers", ""), verification=args.get("verification", ""),
                fallback=args.get("fallback", ""), app_name=args.get("app_name", ""),
            )
            return new_tool_result(True, True, "حُفظ الإجراء كمرشح؛ لم يُعتمد بوصفه موثوقًا حتى يتم التحقق من نجاح تنفيذه.", **result)

        if name == "procedure_update":
            allowed = {k: args[k] for k in ("name", "intent", "steps", "triggers", "verification", "fallback", "app_name") if k in args}
            result = self.memory.update_procedure(procedure_key=args.get("procedure_key", ""), **allowed)
            return new_tool_result(True, True, result.pop("message", "تم تحديث الإجراء."), **result)

        if name == "procedure_search":
            query = str(args.get("query", ""))
            limit = int(args.get("limit", 5))
            results = self.memory.search_procedures(query, limit)
            return new_tool_result(True, True, f"تم البحث عن الإجراءات المحفوظة؛ عدد النتائج: {len(results)}.", procedures=results, total_procedures=self.memory.procedure_count())

        if name == "procedure_record_result":
            result = self.memory.record_procedure_result(
                procedure_key=args.get("procedure_key", ""), outcome=args.get("outcome", "partial"),
                verified=bool(args.get("verified", False)), notes=args.get("notes", ""),
            )
            return new_tool_result(True, True, "تم تسجيل نتيجة الإجراء. لا يُعتمد النجاح إلا إذا حُدد التحقق صراحةً.", **result)

        if name == "list_workspace_files":
            subfolder = str(args.get("subfolder", "")).strip()
            folder = self.checked_workspace_path(subfolder) if subfolder else self.workspace
            if not folder.exists() or not folder.is_dir():
                raise ValueError("المجلد غير موجود.")
            items = []
            for path in sorted(folder.iterdir(), key=lambda p: p.name.casefold())[:200]:
                items.append({"name": path.name, "type": "folder" if path.is_dir() else "file", "size_bytes": path.stat().st_size if path.is_file() else None})
            return new_tool_result(True, True, "تم عرض محتويات مساحة العمل.", files=items)

        if name == "read_workspace_file":
            path = self.checked_workspace_path(args.get("path", ""))
            if not path.is_file():
                raise FileNotFoundError("الملف غير موجود داخل مساحة العمل.")
            if path.stat().st_size > 200_000:
                raise ValueError("الملف أكبر من الحد المسموح: 200,000 بايت.")
            content = path.read_text(encoding="utf-8", errors="replace")
            return new_tool_result(True, True, "تمت قراءة الملف؛ محتواه سيُرسل إلى النموذج للتحليل.", path=str(path), content=content)

        if name == "create_draft":
            filename_raw = str(args.get("filename", "")).strip()
            filename = Path(filename_raw).name
            content = str(args.get("content", ""))
            if not filename or filename in {".", ".."} or filename != filename_raw:
                raise ValueError("اسم الملف غير صالح. استخدم اسم ملف فقط دون مسار.")
            if len(content) > 50_000:
                raise ValueError("المسودة تتجاوز الحد: 50,000 حرف.")
            target = (self.drafts_dir / filename).resolve()
            if self.drafts_dir not in target.parents:
                raise ValueError("المسار غير مسموح.")
            if target.exists():
                raise FileExistsError("يوجد ملف بالاسم نفسه؛ غيّر الاسم لتجنب الاستبدال.")
            target.write_text(content, encoding="utf-8", newline="\n")
            return new_tool_result(True, target.is_file(), "تم إنشاء المسودة.", path=str(target), characters=len(content))

        if name == "delete_workspace_file":
            path = self.checked_workspace_path(args.get("path", ""))
            if not path.is_file():
                raise FileNotFoundError("الملف غير موجود داخل مساحة العمل.")
            path.unlink()
            return new_tool_result(True, not path.exists(), "تم حذف الملف المحدد داخل مساحة العمل.", path=str(path))

        if name == "browser_open_url":
            url = self._public_url(args.get("url", ""))
            driver = self.browser_provider()
            # Reuse an already-open tab in the assistant-managed Selenium session
            # when its host exactly matches the requested host. Never create a new tab
            # just to revisit the same site. This cannot see unrelated personal Chrome
            # profiles unless Chrome was explicitly configured for remote debugging.
            requested_host = (urlparse(url).hostname or "").lower().rstrip(".")
            reused_tab = False
            handles = []
            try:
                handles = list(driver.window_handles)
            except Exception:
                handles = []
            if handles and hasattr(driver, "switch_to"):
                original_handle = None
                try:
                    original_handle = driver.current_window_handle
                except Exception:
                    pass
                for handle in handles:
                    try:
                        driver.switch_to.window(handle)
                        tab_url = str(getattr(driver, "current_url", "") or "")
                        tab_host = (urlparse(tab_url).hostname or "").lower().rstrip(".")
                        if tab_host and tab_host == requested_host:
                            reused_tab = True
                            break
                    except Exception:
                        continue
                if not reused_tab and original_handle is not None:
                    try:
                        driver.switch_to.window(original_handle)
                    except Exception:
                        pass
            if not reused_tab:
                driver.get(url)
            final_url = validate_current_page(driver, resolve_dns=self.resolve_dns)
            message = "عُثر على لسان مفتوح للموقع وانتقلت إليه." if reused_tab else "تم فتح الصفحة في جلسة متصفح المساعد والتحقق من عنوانها الحالي."
            return new_tool_result(True, True, message, url=final_url, reused_existing_tab=reused_tab, private_account_warning=page_read_warning(final_url))

        if name == "list_browser_tabs":
            driver = self.browser_peeker() if self.browser_peeker else None
            if driver is None:
                return new_tool_result(True, True, "لا توجد جلسة متصفح للمساعد مفتوحة بعد.", tabs=[])
            tabs = []
            try:
                current_handle = driver.current_window_handle
            except Exception:
                current_handle = None
            try:
                for handle in list(driver.window_handles):
                    try:
                        driver.switch_to.window(handle)
                        tab_url = str(getattr(driver, "current_url", "") or "")
                        if tab_url and tab_url != "about:blank":
                            validate_current_page(driver, resolve_dns=self.resolve_dns)
                        tabs.append({"title": str(getattr(driver, "title", "") or "")[:250], "url": tab_url[:1000], "active": handle == current_handle})
                    except Exception as exc:
                        tabs.append({"title": "تعذر قراءة اللسان", "url": "", "active": False, "error": type(exc).__name__})
            finally:
                if current_handle is not None:
                    try:
                        driver.switch_to.window(current_handle)
                    except Exception:
                        pass
            return new_tool_result(True, True, "تم فحص ألسنة جلسة متصفح المساعد.", tabs=tabs, note="هذه القائمة تشمل جلسة المساعد فقط، لا ملفات Chrome الشخصية الأخرى.")

        if name == "browser_read_page":
            driver, current_url = self._browser_for_context(args)
            text = get_visible_page_text(driver, limit=20000)
            return new_tool_result(True, True, "تمت قراءة النص الظاهر في الصفحة.", url=current_url, text=text, private_account_warning=page_read_warning(current_url))

        if name == "browser_click_text":
            target_text = str(args.get("text", "")).strip()
            driver, current_url = self._browser_for_context(args)
            element, label = find_text_target(driver, target_text)
            # Preflight declared link/form targets before dispatching any click. A public page is
            # untrusted and could include a visible link to localhost/private infrastructure.
            declared_targets = []
            for attr in ("href", "formaction"):
                value = str(element.get_attribute(attr) or "").strip()
                if value:
                    declared_targets.append(value)
            try:
                form = element.find_element("xpath", "ancestor::form")
                form_action = str(form.get_attribute("action") or "").strip()
                if form_action:
                    declared_targets.append(form_action)
            except Exception:
                pass
            for target in declared_targets:
                self._public_url(urljoin(current_url, target))
            element.click()
            # Validate the post-click URL too, because a script/redirect can ignore declared targets.
            final_url = validate_current_page(driver, resolve_dns=self.resolve_dns)
            # The click was dispatched; remote delivery/navigation may still need separate verification.
            return new_tool_result(True, False, f"تم إرسال أمر النقر إلى العنصر: {label}. لم أتحقق من الأثر الخارجي النهائي.", url=current_url, final_url=final_url, clicked_label=label)

        if name == "browser_type_text":
            text = str(args.get("text", ""))
            if len(text) > 10000:
                raise ValueError("النص يتجاوز الحد: 10,000 حرف.")
            driver, current_url = self._browser_for_context(args)
            element = driver.switch_to.active_element
            kind = validate_text_entry(element)
            element.send_keys(text)
            return new_tool_result(True, True, f"كُتب النص في {kind}; راجع الصفحة قبل الإرسال.", url=current_url, characters=len(text))

        if name == "browser_press_key":
            key_name = str(args.get("key", "")).strip().upper()
            code = key_code(key_name)
            driver, current_url = self._browser_for_context(args)
            element = driver.switch_to.active_element
            if str(element.get_attribute("type") or "").lower() == "password":
                raise ValueError("التعامل الآلي مع حقول كلمات المرور محظور.")
            # Enter may submit forms or send messages, which is why this tool always needs approval.
            element.send_keys(code)
            final_url = validate_current_page(driver, resolve_dns=self.resolve_dns)
            return new_tool_result(True, False, f"تم إرسال المفتاح {key_name}; لم أتحقق من الأثر الخارجي.", url=current_url, final_url=final_url, key=key_name)

        if name == "browser_search_web":
            query = str(args.get("query", "")).strip()
            if not query or len(query) > 300:
                raise ValueError("عبارة البحث يجب أن تكون بين حرف واحد و300 حرف.")
            url = "https://duckduckgo.com/?q=" + quote_plus(query)
            self._public_url(url)
            driver = self.browser_provider()
            driver.get(url)
            current_url = validate_current_page(driver, resolve_dns=self.resolve_dns)
            return new_tool_result(True, True, "تم فتح صفحة البحث والتحقق من عنوانها.", url=current_url)

        if name == "get_browser_status":
            try:
                driver = self.browser_peeker() if self.browser_peeker else None
                if driver is None:
                    return new_tool_result(True, True, "لا توجد جلسة متصفح مفتوحة.", url="غير مفتوح")
                url = str(getattr(driver, "current_url", "") or "")
                if url and url != "about:blank":
                    validate_current_page(driver, resolve_dns=self.resolve_dns)
                return new_tool_result(True, True, "تم جلب حالة المتصفح دون فتح جلسة جديدة.", url=url or "about:blank")
            except Exception:
                return new_tool_result(True, True, "لا توجد جلسة متصفح صالحة.", url="غير مفتوح")

        if name == "launch_program":
            program = str(args.get("program", "")).strip()
            arguments = args.get("arguments", [])
            result = windows_tools.launch_program(program, arguments, cwd=self.workspace)
            return new_tool_result(True, bool(result.get("started")), "تم طلب تشغيل البرنامج. ظهوره الكامل قد يستغرق لحظات.", **result)

        if name == "run_local_command":
            command = args.get("command")
            raw_timeout = args.get("timeout", None)
            timeout = int(raw_timeout) if raw_timeout not in (None, "") else 60
            background = bool(args.get("background", False))
            cwd = str(args.get("cwd", "") or self.workspace)
            result = windows_tools.run_local_command(command, cwd=cwd, timeout=timeout, background=background)
            ok = bool(result.get("background")) or (result.get("returncode") == 0 and not result.get("timed_out"))
            result_data = dict(result)
            message = result_data.pop("message", None) or ("شُغّل الأمر المحلي في الخلفية." if background else ("انتهى الأمر المحلي." if not result.get("timed_out") else "انتهت مهلة الأمر وتم إيقاف شجرة العمليات."))
            return new_tool_result(ok, result.get("returncode") is not None and not result.get("background"), message, **result_data)

        if name == "run_shell_command":
            command = str(args.get("command", ""))
            raw_timeout = args.get("timeout", None)
            timeout = int(raw_timeout) if raw_timeout not in (None, "") else 60
            background = bool(args.get("background", False))
            cwd = str(args.get("cwd", "") or self.workspace)
            result = windows_tools.run_shell_command(command, cwd=cwd, timeout=timeout, background=background)
            ok = bool(result.get("background")) or (result.get("returncode") == 0 and not result.get("timed_out"))
            result_data = dict(result)
            message = result_data.pop("message", None) or ("شُغّل أمر shell في الخلفية." if background else ("انتهى أمر shell." if not result.get("timed_out") else "انتهت المهلة وأُوقفت شجرة العمليات."))
            return new_tool_result(ok, result.get("returncode") is not None and not result.get("background"), message, **result_data)

        if name == "switch_existing_chrome_tab":
            query = str(args.get("tab_query", "Gmail"))
            result = windows_tools.switch_existing_chrome_tab(query)
            message = result.get("message", "")
            payload = {k: v for k, v in result.items() if k != "message"}
            return new_tool_result(bool(result.get("found")), bool(result.get("found")), message, **payload)

        if name == "read_existing_chrome_page":
            title = str(args.get("window_title", "Google Chrome"))
            raw_limit = args.get("limit", 16000)
            result = windows_tools.read_existing_chrome_page(title, raw_limit)
            ok = bool(result.get("ok"))
            message = result.get("message", "")
            payload = {k: v for k, v in result.items() if k != "message"}
            return new_tool_result(ok, ok, message, **payload)

        if name == "list_open_windows":
            windows = windows_tools.list_open_windows()
            return new_tool_result(True, True, "تمت قراءة عناوين النوافذ الظاهرة.", windows=windows)

        if name == "inspect_window":
            window_title = str(args.get("window_title", ""))
            result = windows_tools.inspect_window(window_title)
            return new_tool_result(True, True, "تم فحص عناصر النافذة.", **result)

        if name == "click_window_control":
            result = windows_tools.click_window_control(str(args.get("window_title", "")), str(args.get("control_text", "")))
            return new_tool_result(True, False, "تم إرسال أمر النقر إلى عنصر Windows؛ لم أتحقق من الأثر الخارجي.", **result)

        if name == "type_window_text":
            result = windows_tools.type_window_text(str(args.get("window_title", "")), str(args.get("text", "")), str(args.get("control_text", "")))
            return new_tool_result(True, True, "تم لصق النص في عنصر النافذة المحددة؛ راجع النتيجة.", **result)

        if name == "press_window_key":
            result = windows_tools.press_window_key(str(args.get("window_title", "")), str(args.get("key_combo", "")))
            return new_tool_result(True, False, "تم إرسال اختصار لوحة المفاتيح؛ لم أتحقق من الأثر النهائي.", **result)

        return new_tool_result(False, False, f"الأداة غير معروفة: {name}")
