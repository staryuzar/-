"""Windows desktop automation. Imports are lazy so the app's pure logic is testable elsewhere."""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
import re
import unicodedata
from urllib.parse import urlparse
from pathlib import Path
from typing import Any

from app_paths import get_app_data_dir


def _desktop():
    if os.name != "nt":
        raise RuntimeError("التحكم بنوافذ Windows متاح عند تشغيل البرنامج على Windows فقط.")
    from pywinauto import Desktop
    return Desktop(backend="uia")


def list_open_windows(limit: int = 100) -> list[dict[str, Any]]:
    desktop = _desktop()
    results = []
    for window in desktop.windows(visible_only=True)[:limit]:
        try:
            title = str(window.window_text() or "").strip()
            if not title:
                continue
            results.append({"title": title[:250], "handle": int(window.handle), "enabled": bool(window.is_enabled())})
        except Exception:
            continue
    return results


def _find_window(title: str):
    needle = str(title or "").strip().casefold()
    if not needle:
        raise ValueError("عنوان النافذة مطلوب.")
    windows = _desktop().windows(visible_only=True)
    matches = []
    for window in windows:
        try:
            name = str(window.window_text() or "").strip()
            if needle in name.casefold():
                matches.append((window, name))
        except Exception:
            pass
    if not matches:
        raise ValueError(f"لم أعثر على نافذة ظاهرة بعنوان يتضمن: {title}")
    exact = [item for item in matches if item[1].casefold() == needle]
    if len(exact) == 1:
        return exact[0][0]
    if len(matches) > 1:
        raise ValueError("عنوان النافذة يطابق أكثر من نتيجة؛ استخدم عنوانًا أدق: " + " | ".join(x[1] for x in matches[:8]))
    return matches[0][0]


def inspect_window(window_title: str, limit: int = 120) -> dict[str, Any]:
    window = _find_window(window_title)
    controls = []
    for control in window.descendants()[:limit]:
        try:
            name = str(control.window_text() or "").strip()
            ctype = str(control.element_info.control_type or "")
            if not name and ctype not in {"Edit", "Document", "ComboBox", "List", "Pane"}:
                continue
            controls.append({
                "name": name[:200], "control_type": ctype,
                "enabled": bool(control.is_enabled()), "class_name": str(control.class_name() or "")[:100],
            })
        except Exception:
            continue
    return {"window_title": str(window.window_text() or ""), "controls": controls}


def click_window_control(window_title: str, control_text: str) -> dict[str, Any]:
    window = _find_window(window_title)
    needle = str(control_text or "").strip().casefold()
    if not needle or len(needle) > 400:
        raise ValueError("نص عنصر التحكم فارغ أو طويل جدًا.")
    matches = []
    for control in window.descendants():
        try:
            name = str(control.window_text() or "").strip()
            if needle in name.casefold() and control.is_visible() and control.is_enabled():
                matches.append((control, name))
        except Exception:
            continue
    if not matches:
        raise ValueError(f"لم أجد عنصرًا ظاهرًا يحتوي النص: {control_text}")
    exact = [item for item in matches if item[1].casefold() == needle]
    if len(exact) == 1:
        control = exact[0][0]
    elif len(matches) == 1:
        control = matches[0][0]
    else:
        raise ValueError("عدة عناصر متشابهة: " + " | ".join(name for _, name in matches[:8]))
    control.click_input()
    return {"window_title": str(window.window_text() or ""), "clicked": str(control.window_text() or control_text)}


def type_window_text(window_title: str, text: str, control_text: str = "") -> dict[str, Any]:
    value = str(text or "")
    if len(value) > 10000:
        raise ValueError("النص أطول من 10,000 حرف.")
    window = _find_window(window_title)
    control = window
    needle = str(control_text or "").strip().casefold()
    if needle:
        matches = []
        for item in window.descendants():
            try:
                label = str(item.window_text() or "").strip()
                ctype = str(item.element_info.control_type or "")
                if needle in label.casefold() and ctype in {"Edit", "Document", "ComboBox"} and item.is_visible() and item.is_enabled():
                    matches.append(item)
            except Exception:
                continue
        if len(matches) != 1:
            raise ValueError("يجب أن يطابق نص الحقل عنصر تحرير واحدًا بالضبط.")
        control = matches[0]
    # Clipboard paste is Unicode-friendly for Arabic text.
    import pyperclip
    import pyautogui
    control.set_focus()
    pyperclip.copy(value)
    pyautogui.hotkey("ctrl", "v")
    return {"window_title": str(window.window_text() or ""), "typed_characters": len(value), "target": str(control.window_text() or control_text or "النافذة النشطة")}



def _chrome_windows():
    """Return visible Chrome top-level windows without launching a browser."""
    matches = []
    for window in _desktop().windows(visible_only=True):
        try:
            title = str(window.window_text() or "").strip()
            cls = str(window.class_name() or "")
            if title and ("Google Chrome" in title or cls == "Chrome_WidgetWin_1"):
                matches.append(window)
        except Exception:
            continue
    return matches


def _normalize_tab_query(value: str) -> str:
    """Normalize Arabic/English labels for robust tab matching, without fuzzy URL matching."""
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    text = text.replace("ـ", "")
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^\w]+", "", text, flags=re.UNICODE)


_TAB_SITE_ALIASES = {
    "gmail": {
        "terms": ("gmail", "جيميل", "جي ميل", "جوجل ميل"),
        "domains": ("mail.google.com", "gmail.com"),
        "search": "Gmail",
    },
    "whatsapp": {
        "terms": ("whatsapp", "واتساب", "واتس اب", "واتسآب", "واتس"),
        "domains": ("web.whatsapp.com", "whatsapp.com"),
        "search": "WhatsApp",
    },
    "telegram": {
        "terms": ("telegram", "تليجرام", "تيليجرام", "تلغرام", "تلجرام", "تيليغرام"),
        "domains": ("web.telegram.org", "telegram.org"),
        "search": "Telegram",
    },
    "youtube": {
        "terms": ("youtube", "يوتيوب"),
        "domains": ("youtube.com", "youtu.be"),
        "search": "YouTube",
    },
    "outlook": {
        "terms": ("outlook", "اوتلوك", "أوتلوك", "مايكروسوفت اوتلوك"),
        "domains": ("outlook.com", "outlook.live.com", "office.com", "office365.com"),
        "search": "Outlook",
    },
}


def canonical_chrome_tab_search(query: str) -> str:
    """Convert known Arabic/English site aliases to Chrome's likely English tab title."""
    normalized = _normalize_tab_query(query)
    for config in _TAB_SITE_ALIASES.values():
        if any(_normalize_tab_query(term) in normalized for term in config["terms"]):
            return config["search"]
    return str(query or "").strip()


def chrome_tab_matches_query(query: str, url: str, title: str = "") -> bool:
    """Confirm the selected tab by title or exact/subdomain host, not loose URL substring."""
    query_norm = _normalize_tab_query(query)
    title_norm = _normalize_tab_query(title)
    url_norm = _normalize_tab_query(url)
    host = (urlparse(str(url or "")).hostname or "").lower().rstrip(".")
    for config in _TAB_SITE_ALIASES.values():
        if any(_normalize_tab_query(term) in query_norm for term in config["terms"]):
            if any(host == domain or host.endswith("." + domain) for domain in config["domains"]):
                return True
            # For a known account service, its title alone is not proof of identity:
            # a third-party page can name itself "WhatsApp" or "Gmail". Require its host.
            return False
    return bool(query_norm and (query_norm in title_norm or query_norm in url_norm))


def switch_existing_chrome_tab(tab_query: str = "Gmail") -> dict[str, Any]:
    """Switch to an existing Chrome tab, recognizing supported Arabic and English site names.

    This intentionally never starts Chrome or Selenium, so an existing signed-in
    session can be reused without creating a second browser profile.
    """
    query = str(tab_query or "").strip()
    if not query or len(query) > 100:
        raise ValueError("اكتب جزءًا واضحًا من عنوان اللسان، مثل Gmail أو واتساب.")
    search_term = canonical_chrome_tab_search(query)
    windows = _chrome_windows()
    if not windows:
        raise RuntimeError("لم أعثر على نافذة Chrome مفتوحة. افتح Chrome وسجّل الدخول يدويًا أولًا.")
    import time
    import pyautogui
    import pyperclip
    attempted = []
    for window in windows:
        try:
            before = str(window.window_text() or "")
            window.set_focus()
            time.sleep(0.2)
            pyautogui.hotkey("ctrl", "shift", "a")
            time.sleep(0.35)
            pyperclip.copy(search_term)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.45)
            pyautogui.press("enter")
            time.sleep(0.9)
            # Read the selected tab's URL from the address bar, then restore page focus.
            pyautogui.hotkey("ctrl", "l")
            time.sleep(0.15)
            pyautogui.hotkey("ctrl", "c")
            time.sleep(0.15)
            selected_url = str(pyperclip.paste() or "").strip()
            pyautogui.press("esc")
            time.sleep(0.15)
            try:
                after = str(window.window_text() or "")
            except Exception:
                after = before
            attempted.append({"before": before[:180], "after": after[:180], "url": selected_url[:500], "search_term": search_term})
            if chrome_tab_matches_query(query, selected_url, after):
                return {
                    "found": True, "query": query, "search_term": search_term,
                    "window_title": after, "url": selected_url, "created_new_window": False,
                    "message": "تم تأكيد الانتقال إلى علامة الموقع المطلوبة داخل Chrome المفتوح؛ لم تُنشأ نافذة جديدة.",
                }
        except Exception as exc:
            attempted.append({"error": type(exc).__name__, "detail": str(exc)[:180], "search_term": search_term})
    return {"found": False, "query": query, "search_term": search_term, "created_new_window": False, "attempts": attempted, "message": "لم أتمكن من تأكيد علامة مطابقة. لم أفتح Chrome جديدًا؛ تحقق من أن نافذة Chrome قابلة للتحكم وأن علامة الموقع مسجلة بعنوان معروف."}


def read_existing_chrome_page(window_title: str = "Google Chrome", limit: int = 16000) -> dict[str, Any]:
    """Copy visible page text from an already-open Chrome window using the clipboard."""
    try:
        cap = max(500, min(int(limit), 20000))
    except Exception:
        cap = 16000
    windows = _chrome_windows()
    needle = str(window_title or "").strip().casefold()
    if needle and needle not in {"chrome", "google chrome", ""}:
        selected = [w for w in windows if needle in str(w.window_text() or "").casefold()]
    else:
        selected = windows[:1]
    if not selected:
        raise RuntimeError("لم أعثر على نافذة Chrome مطابقة لقراءة الصفحة.")
    window = selected[0]
    import time
    import pyautogui
    import pyperclip
    window.set_focus()
    time.sleep(0.2)
    # Copy the page's visible text; never read the browser's password manager or password fields.
    pyperclip.copy("")
    pyautogui.hotkey("ctrl", "a")
    time.sleep(0.15)
    pyautogui.hotkey("ctrl", "c")
    time.sleep(0.35)
    text = str(pyperclip.paste() or "")[:cap]
    title = str(window.window_text() or "")[:250]
    if not text.strip():
        return {"ok": False, "window_title": title, "text": "", "message": "لم تُنسخ نصوص الصفحة. قد تكون الصفحة غير مركزة أو تمنع النسخ؛ لم يتم فتح متصفح جديد."}
    return {"ok": True, "window_title": title, "text": text, "characters": len(text), "message": "قُرئ النص الظاهر من علامة Chrome الحالية باستخدام جلسة المستخدم الموجودة."}

def launch_program(program: str, arguments: list[str] | None = None, cwd: str | Path | None = None) -> dict[str, Any]:
    """Launch a program without shell=True. Exact command/args must be shown for approval."""
    target = str(program or "").strip()
    if not target or len(target) > 500:
        raise ValueError("اسم البرنامج فارغ أو طويل جدًا.")
    args = arguments or []
    if not isinstance(args, list) or len(args) > 40 or any(not isinstance(x, str) or len(x) > 2000 for x in args):
        raise ValueError("قائمة معاملات البرنامج غير صالحة.")
    # Accept an installed executable from PATH or a concrete existing path. No command shell.
    resolved = shutil.which(target)
    if resolved:
        executable = resolved
    else:
        candidate = Path(target).expanduser()
        if candidate.is_file():
            executable = str(candidate.resolve())
        elif os.name == "nt" and target.lower().endswith((".lnk", ".url")) and candidate.is_file():
            executable = str(candidate.resolve())
        else:
            # Let CreateProcess resolve standard Windows application names (e.g. notepad.exe).
            if os.name != "nt" or any(sep in target for sep in ("/", "\\")):
                raise FileNotFoundError(f"لم أجد البرنامج في PATH أو في المسار المحدد: {target}")
            executable = target
    process = subprocess.Popen([executable, *args], cwd=str(cwd) if cwd else None, shell=False, close_fds=(os.name != "nt"))
    return {"program": executable, "pid": process.pid, "started": process.poll() is None}


def _terminate_process_tree(proc: subprocess.Popen) -> None:
    """Stop a timed-out command and descendants so inherited pipes cannot hang the UI."""
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, timeout=8, check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        else:
            import signal
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _run_command(command, *, cwd_path: Path, shell: bool, timeout: int | None, background: bool) -> dict[str, Any]:
    # Foreground commands must never hold a Streamlit script run forever.
    effective_timeout = 60 if timeout in (None, "") else max(1, min(int(timeout), 3600))
    creationflags = 0
    popen_kwargs: dict[str, Any] = {}
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if background:
            creationflags |= getattr(subprocess, "DETACHED_PROCESS", 0)
    else:
        popen_kwargs["start_new_session"] = True

    if background:
        log_dir = get_app_data_dir() / "command_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        import datetime
        import uuid
        log_path = log_dir / f"command_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.log"
        with log_path.open("ab") as log_file:
            proc = subprocess.Popen(
                command, cwd=str(cwd_path), shell=shell, stdin=subprocess.DEVNULL,
                stdout=log_file, stderr=subprocess.STDOUT, close_fds=(os.name != "nt"),
                creationflags=creationflags, **popen_kwargs,
            )
        # Reap short-lived background processes without blocking the Streamlit thread.
        threading.Thread(target=proc.wait, name=f"aurora-reap-{proc.pid}", daemon=True).start()
        return {
            "returncode": None, "stdout": "", "stderr": "", "timed_out": False,
            "background": True, "pid": proc.pid, "log_path": str(log_path),
            "cwd": str(cwd_path), "shell": shell,
            "message": "شُغّل الأمر في الخلفية حتى لا تتجمد غرفة المحادثة. راجع ملف السجل لمعرفة مخرجاته.",
        }

    proc = subprocess.Popen(
        command, cwd=str(cwd_path), shell=shell, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
        errors="replace", close_fds=(os.name != "nt"), creationflags=creationflags,
        **popen_kwargs,
    )
    try:
        stdout, stderr = proc.communicate(timeout=effective_timeout)
        return {
            "returncode": proc.returncode, "stdout": (stdout or "")[-12000:],
            "stderr": (stderr or "")[-8000:], "timed_out": False,
            "background": False, "cwd": str(cwd_path), "shell": shell,
            "timeout_seconds": effective_timeout,
        }
    except subprocess.TimeoutExpired:
        _terminate_process_tree(proc)
        try:
            stdout, stderr = proc.communicate(timeout=3)
        except Exception:
            stdout, stderr = "", ""
        return {
            "returncode": proc.returncode, "stdout": (stdout or "")[-4000:],
            "stderr": (stderr or "")[-4000:], "timed_out": True,
            "background": False, "cwd": str(cwd_path), "shell": shell,
            "timeout_seconds": effective_timeout,
            "message": f"توقف الأمر بعد {effective_timeout} ثانية لمنع تعليق غرفة المحادثة. شغّله بالخلفية إذا كان من المفترض أن يستمر.",
        }


def run_local_command(command: list[str], *, cwd: str | Path, timeout: int | None = None, background: bool = False) -> dict[str, Any]:
    """Run a local command with bounded foreground wait or detached background mode."""
    if not isinstance(command, list) or not command or len(command) > 40:
        raise ValueError("الأمر يجب أن يكون قائمة غير فارغة من المعاملات.")
    if any(not isinstance(part, str) or len(part) > 4000 for part in command):
        raise ValueError("إحدى معاملات الأمر غير صالحة أو طويلة جدًا.")
    cwd_path = Path(cwd).expanduser().resolve()
    if not cwd_path.exists():
        raise FileNotFoundError(f"مجلد العمل غير موجود: {cwd_path}")
    if not cwd_path.is_dir():
        raise NotADirectoryError(f"مجلد العمل ليس مجلدًا: {cwd_path}")
    return _run_command(command, cwd_path=cwd_path, shell=False, timeout=timeout, background=bool(background))


def run_shell_command(command: str, *, cwd: str | Path, timeout: int | None = None, background: bool = False) -> dict[str, Any]:
    """Run a shell expression without allowing foreground commands to block forever."""
    value = str(command or "").strip()
    if not value or len(value) > 20000:
        raise ValueError("أمر shell فارغ أو يتجاوز 20,000 حرف.")
    cwd_path = Path(cwd).expanduser().resolve()
    if not cwd_path.exists():
        raise FileNotFoundError(f"مجلد العمل غير موجود: {cwd_path}")
    if not cwd_path.is_dir():
        raise NotADirectoryError(f"مجلد العمل ليس مجلدًا: {cwd_path}")
    return _run_command(value, cwd_path=cwd_path, shell=True, timeout=timeout, background=bool(background))


def press_window_key(window_title: str, key_combo: str) -> dict[str, Any]:
    """Dispatch a constrained keyboard shortcut to a named visible Windows window."""
    key = str(key_combo or "").strip().upper().replace(" ", "")
    allowed_tokens = {
        "CTRL", "CONTROL", "ALT", "SHIFT", "WIN", "WINDOWS", "ENTER", "TAB", "ESC",
        "ESCAPE", "BACKSPACE", "DELETE", "SPACE", "HOME", "END", "INSERT", "PAGEUP",
        "PAGEDOWN", "UP", "DOWN", "LEFT", "RIGHT", "ARROW_UP", "ARROW_DOWN",
        "ARROW_LEFT", "ARROW_RIGHT", *{f"F{i}" for i in range(1, 25)},
        *{chr(i) for i in range(ord("A"), ord("Z") + 1)},
        *{str(i) for i in range(10)},
    }
    parts = key.split("+")
    if not key or any(part not in allowed_tokens for part in parts) or len(parts) > 5:
        raise ValueError("تركيبة المفاتيح غير صالحة؛ استخدم مفاتيح معروفة مفصولة بعلامة +.")
    window = _find_window(window_title)
    window.set_focus()
    import pyautogui
    mapping = {
        "ENTER": ["enter"], "TAB": ["tab"], "ESC": ["esc"], "BACKSPACE": ["backspace"],
        "DELETE": ["delete"], "CTRL+A": ["ctrl", "a"], "CTRL+C": ["ctrl", "c"],
        "CTRL+V": ["ctrl", "v"], "CTRL+S": ["ctrl", "s"], "CTRL+P": ["ctrl", "p"],
        "CTRL+W": ["ctrl", "w"], "CTRL+L": ["ctrl", "l"], "ALT+F4": ["alt", "f4"],
        "WIN+R": ["win", "r"], "F5": ["f5"], "HOME": ["home"], "END": ["end"],
        "CTRL+HOME": ["ctrl", "home"], "CTRL+END": ["ctrl", "end"],
        "SHIFT+TAB": ["shift", "tab"], "ALT+TAB": ["alt", "tab"],
        "ARROW_UP": ["up"], "ARROW_DOWN": ["down"], "ARROW_LEFT": ["left"], "ARROW_RIGHT": ["right"],
    }
    if key in mapping:
        keys = mapping[key]
    else:
        token_map = {"CTRL": "ctrl", "CONTROL": "ctrl", "ALT": "alt", "SHIFT": "shift",
                     "WIN": "win", "WINDOWS": "win", "ESCAPE": "esc", "SPACE": "space",
                     "PAGEUP": "pageup", "PAGEDOWN": "pagedown", "ARROW_UP": "up",
                     "ARROW_DOWN": "down", "ARROW_LEFT": "left", "ARROW_RIGHT": "right"}
        keys = [token_map.get(part, part.lower()) for part in key.split("+")]
    if len(keys) == 1:
        pyautogui.press(keys[0])
    else:
        pyautogui.hotkey(*keys)
    return {"window_title": str(window.window_text() or ""), "key_combo": key, "dispatched": True}


def capture_screen(attachments_dir: str | Path, *, max_bytes: int = 6 * 1024 * 1024) -> dict[str, Any]:
    """Capture the primary Windows display and save a bounded JPEG for explicit visual analysis."""
    if os.name != "nt":
        raise RuntimeError("التقاط شاشة الجهاز متاح فقط عند تشغيل Aurora على Windows.")
    target_dir = Path(attachments_dir).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        import io
        import uuid
        from datetime import datetime
        from PIL import Image
        import pyautogui
        image = pyautogui.screenshot().convert("RGB")
    except Exception as exc:
        raise RuntimeError(f"تعذر التقاط الشاشة الأساسية: {type(exc).__name__}: {str(exc)[:180]}") from None

    original_width, original_height = image.size
    image.thumbnail((1920, 1200), Image.Resampling.LANCZOS)
    payload = b""
    for quality in (88, 82, 76, 70):
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=quality, optimize=True, progressive=True)
        payload = buffer.getvalue()
        if len(payload) <= max_bytes:
            break
    if len(payload) > max_bytes:
        image.thumbnail((1440, 900), Image.Resampling.LANCZOS)
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=72, optimize=True, progressive=True)
        payload = buffer.getvalue()
    if not payload or len(payload) > max_bytes:
        raise RuntimeError("تعذر ضغط لقطة الشاشة دون تجاوز حد 6 ميبيبايت.")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = target_dir / f"screen_{stamp}_{uuid.uuid4().hex[:8]}.jpg"
    with path.open("xb") as stream:
        stream.write(payload)
    return {
        "path": str(path), "name": "لقطة الشاشة الأساسية", "mime_type": "image/jpeg",
        "size_bytes": len(payload), "width": image.size[0], "height": image.size[1],
        "original_width": original_width, "original_height": original_height,
    }
