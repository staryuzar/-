"""Choose one canonical Aurora data directory on first startup.

- Honors an explicit AURORA_DATA_DIR in the environment or .env.
- On Windows, prefers E:\\AuroraData\\LocalAssistant when E: is available.
- When migrating from the old C: data folder to a fresh E: folder, performs a
  verified copy and writes the selected path to .env. It never deletes source data.
- Refuses to silently merge two already-populated data directories.
"""
from __future__ import annotations

import os
from pathlib import Path
from contextlib import closing
from typing import Callable, Mapping

from app_paths import get_app_data_dir
from move_data_to_e import _read_dotenv_key, _set_data_dir_in_env, migrate_data


class DataPathConflictError(RuntimeError):
    pass


def _has_files(path: Path) -> bool:
    return path.is_dir() and any(path.iterdir())


def prepare_data_location(
    project_dir: str | Path,
    *,
    environ: Mapping[str, str] | None = None,
    platform_windows: bool | None = None,
    e_drive_available: bool | None = None,
    e_data_path: str | Path | None = None,
    local_app_data: str | Path | None = None,
    migrate_fn: Callable[..., dict] | None = None,
) -> Path:
    root = Path(project_dir).resolve()
    env_file = root / ".env"
    example_file = root / ".env.example"
    env = dict(os.environ if environ is None else environ)
    windows = os.name == "nt" if platform_windows is None else bool(platform_windows)

    explicit_process = str(env.get("AURORA_DATA_DIR", "") or "").strip().strip('"').strip("'")
    explicit_file = _read_dotenv_key(env_file, "AURORA_DATA_DIR")
    configured = explicit_process or str(explicit_file or "").strip().strip('"').strip("'")
    if configured:
        selected = Path(os.path.expandvars(os.path.expanduser(configured)))
        # A Windows drive path is not absolute on POSIX test/build hosts; never
        # create a misleading directory like "D:/..." in the current folder.
        if selected.is_absolute() or os.name == "nt":
            selected.mkdir(parents=True, exist_ok=True)
        return selected

    if windows:
        has_e = Path("E:/").exists() if e_drive_available is None else bool(e_drive_available)
        if has_e:
            target = Path(e_data_path) if e_data_path is not None else Path("E:/AuroraData/LocalAssistant")
            if local_app_data is not None:
                source_root = Path(local_app_data) / "LocalAssistant"
            else:
                local = str(env.get("LOCALAPPDATA", "") or "").strip()
                source_root = (Path(local) if local else Path.home() / "AppData" / "Local") / "LocalAssistant"

            source_has_data = _has_files(source_root) and source_root.resolve() != target.resolve()
            target_has_data = _has_files(target)
            if source_has_data and target_has_data:
                raise DataPathConflictError(
                    "وجدت بيانات موجودة في C وE معًا. لم أدمجهما تلقائيًا حتى لا أستبدل أو أكرر بياناتك. "
                    "قارن النسختين واختر يدويًا مجلد البيانات الصحيح، أو اضبط AURORA_DATA_DIR صراحةً في .env. "
                    "لم يتم حذف أو دمج أي بيانات."
                )
            if source_has_data and not target_has_data:
                copier = migrate_fn or migrate_data
                copier(source_root, target, env_file, example_file)
            else:
                target.mkdir(parents=True, exist_ok=True)
                _set_data_dir_in_env(env_file, target, example_file)
            return target

    selected = get_app_data_dir(env, platform_windows=windows, e_drive_available=False)
    selected.mkdir(parents=True, exist_ok=True)
    # Persist one explicit canonical location so startup tools and the UI agree.
    _set_data_dir_in_env(env_file, selected, example_file)
    return selected


def bootstrap_data_directory(data_dir: str | Path) -> dict:
    """Create and verify Aurora's complete first-run local data foundation.

    This deliberately runs before the first API key is configured. The database
    and candidate procedures are local-only; no model or network request is made.
    """
    selected = Path(data_dir).expanduser()
    selected.mkdir(parents=True, exist_ok=True)

    # Import lazily to keep path selection tests lightweight and to ensure setup
    # uses the same SQLite initialization code as the running application.
    from database_manager import DATABASE_FILENAME, initialize_unified_database
    from operations_center import initialize_operations_log
    from long_term_memory import LongTermMemory
    from builtin_knowledge import seed_builtin_knowledge
    import sqlite3

    bootstrap = initialize_unified_database(selected)
    db_path = selected / DATABASE_FILENAME
    initialize_operations_log(db_path)
    knowledge = seed_builtin_knowledge(LongTermMemory(db_path))

    # Create stable folders now, so the first diagnostics page does not report
    # missing paths merely because the user has not opened a browser or uploaded an image yet.
    for relative in ("Workspace/Drafts", "Attachments", "ChromeProfile"):
        (selected / relative).mkdir(parents=True, exist_ok=True)

    with closing(sqlite3.connect(str(db_path), timeout=20)) as con:
        integrity = str(con.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity.lower() != "ok":
            raise RuntimeError(f"فشل فحص SQLite بعد التهيئة: {integrity}")
        tables = {str(row[0]) for row in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )}
        required = {"conversations", "memories", "procedures", "operation_events", "operation_task_runs", "aurora_migration_ledger"}
        missing = sorted(required - tables)
        if missing:
            raise RuntimeError("جداول أساسية ناقصة بعد التهيئة: " + ", ".join(missing))
        counts = {
            "conversations": int(con.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]),
            "memories": int(con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]),
            "procedures": int(con.execute("SELECT COUNT(*) FROM procedures").fetchone()[0]),
        }
    return {
        "data_dir": str(selected),
        "database_path": str(db_path),
        "integrity": integrity,
        "required_tables": sorted(required),
        "counts": counts,
        "bootstrap": bootstrap,
        "starter_knowledge": knowledge,
    }


def main() -> int:
    root = Path(__file__).resolve().parent
    try:
        selected = prepare_data_location(root)
        report = bootstrap_data_directory(selected)
    except Exception as exc:
        print(f"تعذر تحديد/تهيئة مجلد بيانات Aurora بأمان: {type(exc).__name__}: {exc}")
        print("لم يتم حذف أو استبدال بيانات المصدر. عالج الخطأ ثم أعد التشغيل.")
        return 1
    print(f"مجلد بيانات Aurora الموحد: {selected}")
    print(f"قاعدة SQLite النشطة: {report['database_path']}")
    print(f"فحص SQLite: {report['integrity']}")
    print("جداول التهيئة: " + ", ".join(report["required_tables"]))
    print("عدد الإجراءات الأولية المحفوظة: " + str(report["counts"]["procedures"]))
    print("اكتمل إنشاء مجلد البيانات وقاعدة SQLite قبل إعداد مفتاح النموذج.")
    print("عند أول تشغيل نظيف، لن يُطلب منك أي سكربت نقل منفصل.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
