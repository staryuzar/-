﻿@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" diagnose.py
) else (
  py -3 diagnose.py
)
pause
