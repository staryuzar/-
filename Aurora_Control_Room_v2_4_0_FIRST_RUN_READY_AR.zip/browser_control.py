"""Small Selenium helpers with guards, injectable for headless simulation tests."""
from __future__ import annotations

from urllib.parse import urlparse
import ipaddress
import re

from security_utils import check_allowed_url, is_sensitive_interaction_url


def validate_debugger_address(raw: str) -> str:
    """Accept only loopback Chrome DevTools endpoints; never attach to a remote host."""
    value = str(raw or "").strip()
    if not value or len(value) > 120 or any(ch in value for ch in "\r\n/@?#"):
        raise ValueError("عنوان تصحيح Chrome غير صالح؛ استخدم 127.0.0.1:9222.")
    # Support IPv4/localhost and bracketed IPv6 loopback only.
    match = re.fullmatch(r"(localhost|127\.0\.0\.1|\[::1\]):([0-9]{1,5})", value, re.IGNORECASE)
    if not match:
        raise ValueError("لأسباب أمنية، اتصال Chrome Debugging مسموح بعنوان loopback فقط مثل 127.0.0.1:9222.")
    host, port_text = match.groups()
    port = int(port_text)
    if not 1 <= port <= 65535:
        raise ValueError("منفذ Chrome Debugging يجب أن يكون بين 1 و65535.")
    if host.lower() not in {"localhost", "127.0.0.1", "[::1]"}:
        try:
            if not ipaddress.ip_address(host).is_loopback:
                raise ValueError("يجب أن يكون عنوان Chrome Debugging محليًا.")
        except ValueError as exc:
            raise ValueError("عنوان Chrome Debugging غير صالح.") from exc
    return f"{host}:{port}"


def chrome_translation_preferences() -> dict:
    """Configure the dedicated Chrome profile to offer/auto-translate English pages to Arabic.

    Chrome may ignore automatic translation in some managed, offline, or unsupported states;
    callers must still treat the page DOM as the source of what is actually visible.
    """
    return {
        "translate.enabled": True,
        # Current Chromium preference name plus legacy compatibility for older Chrome builds.
        "translate_allowlists": {"en": "ar"},
        "translate_whitelists": {"en": "ar"},
        "intl.accept_languages": "ar,en-US,en",
    }


def validate_current_page(driver, *, resolve_dns: bool = True) -> str:
    current_url = str(getattr(driver, "current_url", "") or "")
    try:
        check_allowed_url(current_url, resolve_dns=resolve_dns)
    except Exception as exc:
        try:
            driver.get("about:blank")
        except Exception:
            pass
        raise ValueError("توقفت العملية لأن المتصفح وصل إلى عنوان غير مسموح أو تعذر التحقق منه.") from exc
    return current_url


def page_read_warning(url: str) -> str:
    if is_sensitive_interaction_url(url):
        return "هذا يبدو موقع حساب خاص أو مراسلة؛ راجع النص قبل مشاركته مع النموذج."
    return ""


def _attr(element, name: str) -> str:
    try:
        return str(element.get_attribute(name) or "").strip()
    except Exception:
        return ""


def element_label(element) -> str:
    try:
        text = str(getattr(element, "text", "") or "").strip()
    except Exception:
        text = ""
    return text or _attr(element, "aria-label") or _attr(element, "title") or _attr(element, "value") or ""


def find_text_target(driver, target_text: str):
    """Find a visible link/button by label; the caller must enforce current-user action policy."""
    text = str(target_text or "").strip()
    if not text or len(text) > 500:
        raise ValueError("نص العنصر فارغ أو أطول من الحد المسموح.")
    selector = "a, button, [role='button'], [role='link'], input[type='button'], input[type='submit']"
    candidates = driver.find_elements("css selector", selector)
    visible = []
    for element in candidates:
        try:
            if not element.is_displayed() or not element.is_enabled():
                continue
            label = element_label(element)
            if label and text.casefold() in label.casefold():
                visible.append((element, label))
        except Exception:
            continue
    if not visible:
        raise ValueError(f"لم أجد رابطًا أو زرًا ظاهرًا يحتوي النص: {text}")
    # Prefer a single exact match; never guess among duplicate Send/Delete buttons.
    exact = [(element, label) for element, label in visible if label.casefold() == text.casefold()]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        raise ValueError("وجدت أكثر من عنصر بالعنوان المطابق نفسه؛ استخدم وصفًا أدق أو افحص عناصر الصفحة.")
    if len(visible) > 1:
        choices = [label[:120] for _, label in visible[:8]]
        raise ValueError("وجدت عدة عناصر متشابهة؛ استخدم نصًا أدق. العناصر: " + " | ".join(choices))
    return visible[0]


def validate_text_entry(element) -> str:
    """Ensure active element is a visible text field/editor, never a password or file input."""
    try:
        if not element.is_displayed() or not element.is_enabled():
            raise ValueError("الحقل النشط غير ظاهر أو غير مفعّل.")
    except AttributeError:
        pass
    tag = str(getattr(element, "tag_name", "") or "").lower()
    input_type = _attr(element, "type").lower()
    role = _attr(element, "role").lower()
    editable = _attr(element, "contenteditable").lower() == "true"
    if input_type in {"password", "file", "hidden", "checkbox", "radio", "submit", "button", "reset", "image"}:
        raise ValueError("نوع الحقل غير مسموح للكتابة الآلية.")
    if tag == "textarea" or editable or role in {"textbox", "searchbox"}:
        return "محرر نصي"
    allowed_types = {"", "text", "search", "email", "tel", "url", "number"}
    if tag == "input" and input_type in allowed_types:
        return "حقل نصي"
    raise ValueError("العنصر النشط ليس حقلًا نصيًا يمكن الكتابة فيه بأمان.")


def get_visible_page_text(driver, *, limit: int = 20000) -> str:
    element = driver.find_element("tag name", "body")
    text = str(getattr(element, "text", "") or "")
    return text[:max(0, limit)]


def key_code(key_name: str) -> str:
    key = str(key_name or "").strip().upper()
    mapping = {
        "ENTER": "\ue007", "TAB": "\ue004", "ESC": "\ue00c", "ESCAPE": "\ue00c",
        "BACKSPACE": "\ue003", "DELETE": "\ue017", "ARROW_UP": "\ue013",
        "ARROW_DOWN": "\ue015", "ARROW_LEFT": "\ue012", "ARROW_RIGHT": "\ue014",
        "HOME": "\ue011", "END": "\ue010", "PAGE_UP": "\ue00e", "PAGE_DOWN": "\ue00f",
    }
    if key not in mapping:
        raise ValueError("المفتاح غير مسموح. استخدم مفتاحًا من القائمة المعروفة.")
    return mapping[key]


def is_enter_risky_context(element) -> bool:
    """Enter may submit/send in editable areas; approval UI must warn before it is dispatched."""
    try:
        validate_text_entry(element)
        return True
    except ValueError:
        return False
