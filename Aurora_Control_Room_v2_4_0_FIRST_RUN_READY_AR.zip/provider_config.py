"""Provider selection and placeholder-secret validation for Aurora."""
from __future__ import annotations

import os
from typing import Mapping

_PLACEHOLDER_MARKERS = (
    "ضع_مفتاح", "ضع مفتاح", "your_api_key", "your-api-key", "your key",
    "changeme", "change_me", "change-me", "replace_me", "replace-me",
    "placeholder", "insert_key", "insert-key", "api_key_here", "api-key-here",
    "<your", "<api", "YOUR_", "YOUR-",
)


def is_real_api_key(value: object) -> bool:
    """Return false for blank/example/template values without exposing secret contents."""
    key = str(value or "").strip()
    if not key:
        return False
    lowered = key.casefold()
    if any(marker.casefold() in lowered for marker in _PLACEHOLDER_MARKERS):
        return False
    if key.startswith("<") and key.endswith(">"):
        return False
    return True


def selected_provider(env: Mapping[str, str] | None = None) -> str:
    """Respect explicit provider choice; auto-select Gemini only for a non-placeholder key."""
    values = os.environ if env is None else env
    configured = str(values.get("AI_PROVIDER", "")).strip().lower()
    if configured in {"gemini", "openrouter"}:
        return configured
    return "gemini" if is_real_api_key(values.get("GEMINI_API_KEY", "")) else "openrouter"


def has_provider_key(provider: str, env: Mapping[str, str] | None = None) -> bool:
    values = os.environ if env is None else env
    provider = str(provider or "").strip().lower()
    if provider == "gemini":
        return is_real_api_key(values.get("GEMINI_API_KEY", ""))
    if provider == "openrouter":
        return is_real_api_key(values.get("OPENROUTER_API_KEY", ""))
    return False


def provider_key_name(provider: str) -> str:
    return "GEMINI_API_KEY" if str(provider or "").strip().lower() == "gemini" else "OPENROUTER_API_KEY"
