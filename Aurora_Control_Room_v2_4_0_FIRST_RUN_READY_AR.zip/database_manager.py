"""Bootstrap one shared SQLite database and safely consolidate legacy databases.

Active database: <data_dir>/aurora.sqlite3
Legacy files are archived only after their data has been imported and the archive
copy has passed SQLite integrity and table/row-count checks. The app uses only
the shared database after bootstrap.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

DATABASE_FILENAME = "aurora.sqlite3"
_BOOTSTRAP_RESULTS: dict[str, dict[str, Any]] = {}
LEGACY_DATABASES = ("chat_history.sqlite3", "long_term_memory.sqlite3")
SIDECAR_SUFFIXES = ("-wal", "-shm", "-journal")


class DatabaseBootstrapError(RuntimeError):
    """Raised when database migration cannot be completed safely."""


def _sha256_file(path: Path) -> str:
    """Hash the main DB plus data-bearing SQLite sidecars (WAL/journal)."""
    h = hashlib.sha256()
    candidates = (path, Path(str(path) + "-wal"), Path(str(path) + "-journal"))
    for candidate in candidates:
        if not candidate.is_file():
            continue
        h.update(candidate.name.encode("utf-8", errors="replace"))
        with candidate.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
    return h.hexdigest()


def _integrity(path: Path) -> str:
    con = sqlite3.connect(str(path), timeout=30)
    try:
        return str(con.execute("PRAGMA integrity_check").fetchone()[0])
    finally:
        con.close()


def _table_names(con: sqlite3.Connection) -> list[str]:
    return [
        str(row[0])
        for row in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]


def _row_count(con: sqlite3.Connection, table: str) -> int:
    quoted = '"' + table.replace('"', '""') + '"'
    return int(con.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0])


def _ensure_migration_table(db_path: Path) -> None:
    con = sqlite3.connect(str(db_path), timeout=30)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute(
            """CREATE TABLE IF NOT EXISTS aurora_migration_ledger (
                source_key TEXT PRIMARY KEY,
                source_name TEXT NOT NULL,
                source_sha256 TEXT NOT NULL,
                migrated_at TEXT NOT NULL,
                detail_json TEXT NOT NULL DEFAULT '{}'
            )"""
        )
        con.commit()
    finally:
        con.close()


def _import_conversations(src: sqlite3.Connection, dst: sqlite3.Connection) -> dict[str, int]:
    if "conversations" not in _table_names(src):
        return {}
    source_columns = {str(row[1]) for row in src.execute('PRAGMA table_info("conversations")')}
    destination_columns = [str(row[1]) for row in dst.execute('PRAGMA table_info("conversations")')]
    known = {"id", "title", "created_at", "updated_at", "messages_json", "log_json", "pending_json"}
    if "id" not in source_columns:
        raise DatabaseBootstrapError("القاعدة القديمة conversations لا تحتوي عمود id؛ أوقفت النقل حفاظًا على البيانات.")

    inserted = skipped = 0
    rows = src.execute('SELECT * FROM "conversations"').fetchall()
    for raw in rows:
        row = dict(raw)
        old_log = row.get("log_json")
        if (old_log is None or old_log == "[]" or old_log == "") and row.get("tool_log_json"):
            old_log = row.get("tool_log_json")
        values: dict[str, Any] = {
            "id": row.get("id"),
            "title": row.get("title") or "محادثة جديدة",
            "created_at": row.get("created_at") or "",
            "updated_at": row.get("updated_at") or row.get("created_at") or "",
            "messages_json": row.get("messages_json") or "[]",
            "log_json": old_log if old_log is not None else "[]",
            "pending_json": row.get("pending_json") or "[]",
        }
        cols = [c for c in destination_columns if c in known and c in values]
        placeholders = ",".join("?" for _ in cols)
        colsql = ",".join('"' + c + '"' for c in cols)
        cur = dst.execute(
            f'INSERT OR IGNORE INTO "conversations" ({colsql}) VALUES ({placeholders})',
            [values[c] for c in cols],
        )
        if cur.rowcount:
            inserted += 1
        else:
            skipped += 1
    return {"source_rows": len(rows), "inserted": inserted, "conflict_or_duplicate": skipped}


def _import_generic_table(src: sqlite3.Connection, dst: sqlite3.Connection, table: str) -> dict[str, int]:
    if table not in _table_names(src) or table not in _table_names(dst):
        return {}
    source_columns = [str(row[1]) for row in src.execute(f'PRAGMA table_info("{table}")')]
    destination_columns = [str(row[1]) for row in dst.execute(f'PRAGMA table_info("{table}")')]
    columns = [c for c in destination_columns if c in source_columns]
    if not columns:
        return {}
    colsql = ",".join('"' + c.replace('"', '""') + '"' for c in columns)
    rows = src.execute(f'SELECT {colsql} FROM "{table}"').fetchall()
    placeholders = ",".join("?" for _ in columns)
    inserted = skipped = 0
    for row in rows:
        cur = dst.execute(f'INSERT OR IGNORE INTO "{table}" ({colsql}) VALUES ({placeholders})', tuple(row))
        if cur.rowcount:
            inserted += 1
        else:
            skipped += 1
    return {"source_rows": len(rows), "inserted": inserted, "conflict_or_duplicate": skipped}


def _import_legacy_file(source: Path, target: Path) -> dict[str, Any]:
    source_hash = _sha256_file(source)
    source_key = f"{source.name}:{source_hash}"
    src = sqlite3.connect(str(source), timeout=30)
    src.row_factory = sqlite3.Row
    try:
        integrity = str(src.execute("PRAGMA integrity_check").fetchone()[0])
        if integrity.lower() != "ok":
            raise DatabaseBootstrapError(f"القاعدة القديمة {source.name} تالفة: {integrity}")
        source_tables = _table_names(src)
        dst = sqlite3.connect(str(target), timeout=30)
        dst.row_factory = sqlite3.Row
        try:
            dst.execute("PRAGMA busy_timeout=30000")
            dst.execute("PRAGMA foreign_keys=ON")
            dst.execute(
                """CREATE TABLE IF NOT EXISTS aurora_migration_ledger (
                    source_key TEXT PRIMARY KEY,
                    source_name TEXT NOT NULL,
                    source_sha256 TEXT NOT NULL,
                    migrated_at TEXT NOT NULL,
                    detail_json TEXT NOT NULL DEFAULT '{}'
                )"""
            )
            existing = dst.execute(
                "SELECT detail_json FROM aurora_migration_ledger WHERE source_key=?", (source_key,)
            ).fetchone()
            if existing:
                return {"source": source.name, "status": "already_imported", "detail": json.loads(existing[0])}

            dst.execute("BEGIN IMMEDIATE")
            detail: dict[str, Any] = {"source_integrity": integrity, "tables": {}}
            for table in source_tables:
                if table == "conversations":
                    detail["tables"][table] = _import_conversations(src, dst)
                elif table in {"memories", "procedures"}:
                    detail["tables"][table] = _import_generic_table(src, dst, table)
                # Unknown tables remain preserved in the legacy backup rather than
                # being copied into the live database without a defined schema.
            dst.execute(
                "INSERT INTO aurora_migration_ledger(source_key,source_name,source_sha256,migrated_at,detail_json) VALUES(?,?,?,?,?)",
                (
                    source_key,
                    source.name,
                    source_hash,
                    datetime.now().isoformat(timespec="seconds"),
                    json.dumps(detail, ensure_ascii=False),
                ),
            )
            dst.commit()
            check = str(dst.execute("PRAGMA integrity_check").fetchone()[0])
            if check.lower() != "ok":
                raise DatabaseBootstrapError(f"قاعدة Aurora بعد دمج {source.name} لم تجتز فحص السلامة: {check}")
            return {"source": source.name, "status": "imported", "detail": detail, "source_tables": source_tables}
        except Exception:
            dst.rollback()
            raise
        finally:
            dst.close()
    finally:
        src.close()


def _verified_sqlite_backup(source: Path, backup: Path) -> dict[str, Any]:
    backup.parent.mkdir(parents=True, exist_ok=True)
    tmp = backup.with_suffix(backup.suffix + ".tmp")
    tmp.unlink(missing_ok=True)
    src = sqlite3.connect(str(source), timeout=30)
    dst = sqlite3.connect(str(tmp), timeout=30)
    try:
        src.backup(dst)
        dst.commit()
        source_tables = _table_names(src)
        backup_tables = _table_names(dst)
        if source_tables != backup_tables:
            raise DatabaseBootstrapError(f"فشل التحقق من جداول النسخة القديمة: {source.name}")
        counts: dict[str, int] = {}
        for table in source_tables:
            if _row_count(src, table) != _row_count(dst, table):
                raise DatabaseBootstrapError(f"فشل التحقق من عدد الصفوف في {source.name}/{table}")
            counts[table] = _row_count(dst, table)
        if str(dst.execute("PRAGMA integrity_check").fetchone()[0]).lower() != "ok":
            raise DatabaseBootstrapError(f"نسخة الأرشيف غير سليمة: {backup.name}")
    except Exception:
        dst.close()
        src.close()
        tmp.unlink(missing_ok=True)
        raise
    else:
        dst.close()
        src.close()
    os.replace(tmp, backup)
    return {"backup": str(backup), "tables": counts, "integrity": "ok"}


def _archive_legacy_file(source: Path, data_dir: Path) -> dict[str, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    archive_dir = data_dir / "Backups" / "LegacySQLite" / stamp
    backup = archive_dir / source.name
    report = _verified_sqlite_backup(source, backup)
    removal: list[str] = []
    for candidate in (source, *(Path(str(source) + suffix) for suffix in SIDECAR_SUFFIXES)):
        try:
            candidate.unlink(missing_ok=True)
        except OSError as exc:
            removal.append(f"تعذر إبعاد {candidate.name} بعد إنشاء نسخة احتياطية سليمة: {exc}")
    report["source_removed_from_active_root"] = not source.exists()
    report["notes"] = removal
    return report


def initialize_unified_database(data_dir: str | Path) -> dict[str, Any]:
    """Create the single active database and import/retire legacy DB files once."""
    base = Path(data_dir).expanduser()
    base.mkdir(parents=True, exist_ok=True)
    cache_key = str(base.resolve())
    if cache_key in _BOOTSTRAP_RESULTS and (base / DATABASE_FILENAME).is_file():
        cached = dict(_BOOTSTRAP_RESULTS[cache_key])
        cached["cached_for_this_process"] = True
        return cached
    target = base / DATABASE_FILENAME
    if target.exists():
        integrity = _integrity(target)
        if integrity.lower() != "ok":
            raise DatabaseBootstrapError(
                f"قاعدة البيانات الموحدة {target} غير سليمة ({integrity}). لم أستبدلها أو أنشئ قاعدة جديدة فوقها."
            )
    # Preflight old databases before creating a new target, so a corrupt legacy
    # source cannot leave an apparently valid but empty new DB behind.
    for legacy_name in LEGACY_DATABASES:
        source = base / legacy_name
        if source.is_file():
            integrity = _integrity(source)
            if integrity.lower() != "ok":
                raise DatabaseBootstrapError(
                    f"القاعدة القديمة {source.name} غير سليمة ({integrity}); لم أبدأ الدمج أو الأرشفة."
                )

    # Use existing store initializers to create/upgrade their tables in this SAME file.
    from conversation_store import ConversationStore
    from long_term_memory import LongTermMemory

    ConversationStore(target)
    LongTermMemory(target)
    _ensure_migration_table(target)

    migrated: list[dict[str, Any]] = []
    archived: list[dict[str, Any]] = []
    warnings: list[str] = []
    for legacy_name in LEGACY_DATABASES:
        source = base / legacy_name
        if not source.is_file():
            continue
        if source.resolve() == target.resolve():
            continue
        result = _import_legacy_file(source, target)
        migrated.append(result)
        if result.get("status") in {"imported", "already_imported"}:
            try:
                archived_result = _archive_legacy_file(source, base)
                archived.append(archived_result)
                warnings.extend(archived_result.get("notes", []))
            except Exception as exc:
                warnings.append(
                    f"تم دمج {legacy_name} في القاعدة الموحدة، لكن تعذر أرشفة النسخة القديمة تلقائيًا؛ بقيت في مكانها ولم تُحذف: {type(exc).__name__}: {exc}"
                )

    final_integrity = _integrity(target)
    if final_integrity.lower() != "ok":
        raise DatabaseBootstrapError(f"قاعدة البيانات الموحدة فشلت في الفحص النهائي: {final_integrity}")
    con = sqlite3.connect(str(target), timeout=30)
    try:
        tables = _table_names(con)
        counts = {table: _row_count(con, table) for table in tables if table in {"conversations", "memories", "procedures"}}
    finally:
        con.close()
    result = {
        "database_path": str(target),
        "integrity": final_integrity,
        "active_database_count": 1,
        "migrated": migrated,
        "archived": archived,
        "warnings": warnings,
        "tables": counts,
    }
    _BOOTSTRAP_RESULTS[cache_key] = dict(result)
    return result
