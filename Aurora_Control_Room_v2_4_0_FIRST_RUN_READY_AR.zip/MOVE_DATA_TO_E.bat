@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo =====================================================
echo   Aurora Control Room - Move local data to drive E:
echo =====================================================
echo Close Aurora Control Room before continuing.
echo Your old C: data will be retained as a rollback copy.
echo.
pause
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" move_data_to_e.py
) else (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python Launcher was not found. Install Python 3.10 or newer.
    pause
    exit /b 1
  )
  py -3 move_data_to_e.py
)
set RESULT=%ERRORLEVEL%
echo.
if not "%RESULT%"=="0" (
  echo Migration did not complete. No source data was deleted.
) else (
  echo Migration completed. Run START_WINDOWS.bat and verify your data.
)
pause
exit /b %RESULT%
