"""Safe local image storage and multimodal request adapters for Aurora.

Images are validated from their bytes, decoded and re-encoded with Pillow,
stored under the configured local data directory, and only sent to a provider
when included in a conversation that is being submitted for model analysis.
"""
from __future__ import annotations

import base64
import io
import os
import re
import warnings
import uuid
from pathlib import Path
from typing import Any, Iterable

from PIL import Image, ImageOps, UnidentifiedImageError

MAX_IMAGE_BYTES = 6 * 1024 * 1024
MAX_TOTAL_IMAGE_BYTES = 8 * 1024 * 1024
MAX_IMAGES_PER_MESSAGE = 4
MAX_IMAGE_PIXELS = 40_000_000
_ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


class ImageAttachmentError(ValueError):
    """Raised when an image attachment violates Aurora's safety/size limits."""


def _safe_name(value: Any) -> str:
    raw = Path(str(value or "image")).name
    raw = re.sub(r"[^\w .()\-\u0600-\u06ff]", "_", raw, flags=re.UNICODE).strip(" .")
    return (raw or "image")[:120]


def _read_upload(file_obj: Any) -> bytes:
    try:
        if hasattr(file_obj, "getvalue"):
            data = file_obj.getvalue()
        elif hasattr(file_obj, "read"):
            data = file_obj.read(MAX_IMAGE_BYTES + 1)
        elif isinstance(file_obj, (bytes, bytearray, memoryview)):
            data = bytes(file_obj)
        else:
            raise ImageAttachmentError("تعذر قراءة ملف الصورة المرفق.")
    except ImageAttachmentError:
        raise
    except Exception as exc:
        raise ImageAttachmentError(f"تعذر قراءة الصورة: {type(exc).__name__}.") from None
    if not isinstance(data, (bytes, bytearray)):
        raise ImageAttachmentError("صيغة بيانات الصورة غير صالحة.")
    data = bytes(data)
    if not data:
        raise ImageAttachmentError("ملف الصورة فارغ.")
    if len(data) > MAX_IMAGE_BYTES:
        raise ImageAttachmentError("حجم كل صورة يجب ألا يتجاوز 6 ميبيبايت.")
    return data


def _inspect_image(raw: bytes) -> tuple[str, str, int, int]:
    """Verify actual image bytes and dimensions without trusting MIME or filename."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as probe:
                fmt = str(probe.format or "").upper()
                if fmt not in _ALLOWED_FORMATS:
                    raise ImageAttachmentError("الأنواع المقبولة هي PNG وJPEG وWebP فقط.")
                width, height = probe.size
                if width < 1 or height < 1 or width * height > MAX_IMAGE_PIXELS:
                    raise ImageAttachmentError("أبعاد الصورة غير صالحة أو تتجاوز حد 40 مليون بكسل.")
                probe.verify()
            # Open and decode the pixels too; verify() alone does not prove complete decodeability.
            with Image.open(io.BytesIO(raw)) as image:
                image.load()
                width, height = image.size
        mime = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}[fmt]
        return fmt, mime, width, height
    except ImageAttachmentError:
        raise
    except (Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise ImageAttachmentError("رفضت الحماية صورة ذات أبعاد خطرة محتملة.") from None
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ImageAttachmentError(f"الملف ليس صورة سليمة أو تعذر فكّه ({type(exc).__name__}).") from None


def _decode_and_normalize(raw: bytes) -> tuple[bytes, str, int, int]:
    """Decode and re-encode to JPEG/PNG, stripping metadata and avoiding active content."""
    fmt, _source_mime, width, height = _inspect_image(raw)
    try:
        with Image.open(io.BytesIO(raw)) as image:
            image.load()
            image = ImageOps.exif_transpose(image)
            width, height = image.size
            has_alpha = image.mode in {"RGBA", "LA"} or (image.mode == "P" and "transparency" in image.info)
            buffer = io.BytesIO()
            if has_alpha:
                clean = image.convert("RGBA")
                clean.save(buffer, format="PNG", optimize=True, compress_level=7)
                mime = "image/png"
            elif fmt == "PNG":
                clean = image.convert("RGB")
                clean.save(buffer, format="PNG", optimize=True, compress_level=7)
                mime = "image/png"
            else:
                clean = image.convert("RGB")
                clean.save(buffer, format="JPEG", quality=88, optimize=True, progressive=True)
                mime = "image/jpeg"
            result = buffer.getvalue()
            if not result:
                raise ImageAttachmentError("تعذر تجهيز الصورة للإرسال.")
            if len(result) > MAX_IMAGE_BYTES:
                raise ImageAttachmentError("الصورة بعد تجهيزها تتجاوز حد 6 ميبيبايت؛ قلّل دقتها أو حجمها.")
            return result, mime, width, height
    except ImageAttachmentError:
        raise
    except (Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise ImageAttachmentError("رفضت الحماية صورة ذات أبعاد خطرة محتملة.") from None
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ImageAttachmentError(f"الملف ليس صورة سليمة أو تعذر فكّه ({type(exc).__name__}).") from None


def store_uploaded_images(files: Iterable[Any], attachments_dir: str | Path) -> list[dict[str, Any]]:
    """Validate multiple upload objects, store sanitized copies, and return DB-safe metadata."""
    uploads = list(files or [])
    if not uploads:
        return []
    if len(uploads) > MAX_IMAGES_PER_MESSAGE:
        raise ImageAttachmentError("يمكن إرفاق أربع صور كحد أقصى في الرسالة الواحدة.")

    root = Path(attachments_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    root = root.resolve()
    created: list[Path] = []
    results: list[dict[str, Any]] = []
    total_bytes = 0
    try:
        for upload in uploads:
            original_name = _safe_name(getattr(upload, "name", "image"))
            raw = _read_upload(upload)
            normalized, mime, width, height = _decode_and_normalize(raw)
            total_bytes += len(normalized)
            if total_bytes > MAX_TOTAL_IMAGE_BYTES:
                raise ImageAttachmentError("مجموع أحجام الصور في الرسالة تجاوز 8 ميبيبايت.")
            ext = ".png" if mime == "image/png" else ".jpg"
            target = root / f"img_{uuid.uuid4().hex}{ext}"
            # Exclusive create avoids overwriting even in the very unlikely event of a name collision.
            with target.open("xb") as stream:
                stream.write(normalized)
            created.append(target)
            results.append({
                "path": str(target), "name": original_name, "mime_type": mime,
                "size_bytes": len(normalized), "width": width, "height": height,
            })
        return results
    except Exception:
        for path in created:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        raise


def load_attachment(attachment: dict[str, Any], attachments_dir: str | Path) -> dict[str, Any]:
    """Load and re-validate an image constrained to the attachment directory."""
    if not isinstance(attachment, dict):
        raise ImageAttachmentError("بيانات مرفق الصورة غير صالحة.")
    root = Path(attachments_dir).expanduser().resolve()
    raw_path = str(attachment.get("path") or "").strip()
    if not raw_path:
        raise ImageAttachmentError("مرفق الصورة لا يحتوي مسارًا.")
    path = Path(raw_path).expanduser().resolve(strict=True)
    if path.parent != root or not path.is_file():
        raise ImageAttachmentError("رُفض مسار مرفق خارج مجلد الصور المحلي.")
    size = path.stat().st_size
    if size < 1 or size > MAX_IMAGE_BYTES:
        raise ImageAttachmentError("حجم مرفق الصورة غير صالح أو أكبر من الحد.")
    data = path.read_bytes()
    _fmt, mime, width, height = _inspect_image(data)
    # Re-validate bytes on every send; preserve the sanitized image as stored.
    if mime != str(attachment.get("mime_type") or mime):
        raise ImageAttachmentError("نوع الصورة المحفوظة لا يطابق بيانات المرفق.")
    return {"data": data, "mime_type": mime, "name": _safe_name(attachment.get("name", path.name)),
            "size_bytes": len(data), "width": width, "height": height}


def messages_with_openai_images(messages: list[dict], attachments_dir: str | Path) -> list[dict]:
    """Convert persisted attachment metadata to OpenAI-compatible data-URL message parts."""
    converted: list[dict] = []
    total_request_image_bytes = 0
    for message in messages or []:
        if not isinstance(message, dict):
            continue
        outgoing = {key: value for key, value in message.items() if key != "attachments"}
        attachments = message.get("attachments") or []
        if attachments and message.get("role") == "user":
            content_parts = []
            text = message.get("content")
            if isinstance(text, str) and text.strip():
                content_parts.append({"type": "text", "text": text})
            if len(attachments) > MAX_IMAGES_PER_MESSAGE:
                raise ImageAttachmentError("تحتوي الرسالة المحفوظة على صور أكثر من الحد.")
            for item in attachments:
                loaded = load_attachment(item, attachments_dir)
                total_request_image_bytes += loaded["size_bytes"]
                if total_request_image_bytes > MAX_TOTAL_IMAGE_BYTES:
                    raise ImageAttachmentError("مجموع الصور المرسلة في الطلب الحالي يتجاوز 8 ميبيبايت؛ ابدأ محادثة جديدة أو أعد إرفاق الصورة المطلوبة فقط.")
                data_url = f"data:{loaded['mime_type']};base64,{base64.b64encode(loaded['data']).decode('ascii')}"
                content_parts.append({"type": "image_url", "image_url": {"url": data_url, "detail": "auto"}})
            outgoing["content"] = content_parts
        converted.append(outgoing)
    return converted
