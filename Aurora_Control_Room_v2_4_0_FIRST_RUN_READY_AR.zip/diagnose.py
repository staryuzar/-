from __future__ import annotations

import importlib.util
import os
import platform
import shutil
import sys
from pathlib import Path
from contextlib import closing
import sqlite3

from provider_config import has_provider_key, selected_provider
from app_paths import get_app_data_dir

# Reflect the app's .env-selected storage path without displaying any secrets.
ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
if "AURORA_DATA_DIR" not in os.environ and ENV_PATH.is_file():
    for _raw in ENV_PATH.read_text(encoding="utf-8", errors="replace").splitlines():
        _line = _raw.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _key, _value = _line.split("=", 1)
            if _key.strip() == "AURORA_DATA_DIR":
                os.environ["AURORA_DATA_DIR"] = _value.strip().strip('"').strip("'")
                break
APP_DIR = get_app_data_dir()


def read_dotenv_without_printing_values(path: Path) -> dict[str, str]:
    """Read simple KEY=VALUE pairs for status only; never print their values."""
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            values[key] = value
    return values


print("=== Aurora Control Room v2.4.0 — Operations Diagnostics ===")
print(f"Python: {sys.version.split()[0]} ({sys.executable})")
print(f"Operating system: {platform.platform()}")
print(f"Project folder: {ROOT}")
print(f"Local data folder: {APP_DIR}")
print(f".env exists: {ENV_PATH.is_file()}")
active_db = APP_DIR / "aurora.sqlite3"
print(f"Unified SQLite database: {active_db} ({'found' if active_db.is_file() else 'MISSING'})")
if active_db.is_file():
    try:
        with closing(sqlite3.connect(f"file:{active_db.resolve().as_posix()}?mode=ro", uri=True, timeout=3)) as connection:
            check = connection.execute("PRAGMA quick_check").fetchone()[0]
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            print(f"SQLite quick_check: {check}")
            for table in ("conversations", "memories", "procedures", "operation_events"):
                if table in tables:
                    print(f"SQLite rows {table}: {connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]}")
            if not {"conversations", "memories", "procedures"}.issubset(tables):
                print("SQLite schema WARNING: one or more expected core tables are missing.")
    except Exception as exc:
        print(f"SQLite check FAILED: {type(exc).__name__}: {str(exc)[:180]}")

file_values = read_dotenv_without_printing_values(ENV_PATH)
# Environment values take precedence, matching python-dotenv's default behavior.
resolved = dict(file_values)
resolved.update(os.environ)
provider = selected_provider(resolved)
print(f"Selected AI provider: {provider}")
print(f"Gemini API key configured: {has_provider_key('gemini', resolved)} (key value never displayed)")
print(f"OpenRouter API key configured: {has_provider_key('openrouter', resolved)} (key value never displayed)")

for module in ("streamlit", "dotenv", "openai", "selenium", "pywinauto", "pyautogui", "pyperclip"):
    print(f"Module {module}: {'installed' if importlib.util.find_spec(module) else 'MISSING'}")

chrome_candidates = [
    Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Google/Chrome/Application/chrome.exe",
]
chrome = next((p for p in chrome_candidates if p.is_file()), None)
print(f"Chrome executable: {chrome if chrome else (shutil.which('chrome') or 'not found in standard locations/PATH')}")
print("Windows desktop automation and live service sessions must be verified by running this diagnostic on the user's Windows device.")
