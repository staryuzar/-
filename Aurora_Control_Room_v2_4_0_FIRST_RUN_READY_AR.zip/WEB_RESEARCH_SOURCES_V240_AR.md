# مصادر البحث والتحقق الرسمية — v2.4.0 (2026-10-19)

| المجال | المصدر | تطبيقه في المراجعة | الحد |
|---|---|---|---|
| مخاطر تطبيقات LLM وحقن التعليمات | https://owasp.org/www-project-top-10-for-large-language-model-applications/ | يفصل مصدر التفويض عن نص الصفحة/المرفق ويختبر prompt injection والأفعال الزائدة | المبادئ لا تثبت سلامة كل مسار وحدها |
| Excessive Agency | https://genai.owasp.org/llmrisk2023-24/llm08-excessive-agency/ | حد أدنى لصلاحيات الأدوات ومراجعة الآثار عالية الأثر | لا يعني المطالبة بموافقة كل خطوة روتينية |
| Agentic Security Playbook | https://github.com/OWASP/secure-agent-playbook | ربط الموافقة بالعواقب وتمرير التحقق إلى كود الأداة | المصدر مرجع تصميم وليس اختبار تكامل |
| تنفيذ العمليات | https://docs.python.org/3/library/subprocess.html | تجنب أوامر shell مفتوحة، وتحقق خاص من استخدام `shell=True` | على Windows قد تمر ملفات `.bat` عبر shell؛ لا تستخدم args غير موثوقة |
| Gemini models | https://ai.google.dev/gemini-api/docs/models | التحقق من أن `gemini-3.8-flash` اسم مدرج في الوثائق الحالية | قائمة النموذج لا تثبت صلاحية مفتاح المستخدم أو حصته |
| Gemini function calling | https://ai.google.dev/gemini-api/docs/function-calling | فصل طلب النموذج للأداة عن تنفيذها في التطبيق | يلزم اختبار حي لكل استدعاء API |
| Streamlit chat input | https://docs.streamlit.io/develop/api-reference/chat/st.chat_input | توافق مدخل المحادثة مع إصدار Streamlit المدرج | يختبر كود الواجهة بمحاكاة محلية؛ تشغيل Windows حي غير منفذ هنا |
| Selenium Manager | https://www.selenium.dev/documentation/selenium_manager/ | مكان cache وإدارة driver | توافق Chrome/ChromeDriver يعتمد على جهاز المستخدم |
| SQLite backup API | https://sqlite.org/backup.html | نسخ القواعد القديمة والتحقق قبل التفعيل | النقل الفعلي على E لدى المستخدم لم يُنفذ في هذه البيئة |

المراجعة عبر الإنترنت تؤكد التوثيق/الواجهات المذكورة فقط، ولا تُعد إثباتًا لاتصال Aurora بحساب Google أو WhatsApp أو Telegram أو MT5.
