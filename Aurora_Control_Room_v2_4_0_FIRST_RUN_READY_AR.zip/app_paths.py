"""Single source of truth for Aurora's local data directory."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping


def get_app_data_dir(
    environ: Mapping[str, str] | None = None,
    *,
    platform_windows: bool | None = None,
    e_drive_available: bool | None = None,
) -> Path:
    """Return Aurora's data directory.

    Order:
      1. Explicit AURORA_DATA_DIR setting.
      2. E:\\AuroraData\\LocalAssistant on Windows when E: exists.
      3. Historical LOCALAPPDATA\\LocalAssistant on Windows, otherwise ~/LocalAssistant.

    Parameters after ``*`` are injectable for deterministic tests.
    """
    env = os.environ if environ is None else environ
    configured = str(env.get("AURORA_DATA_DIR", "") or "").strip().strip('"').strip("'")
    if configured:
        expanded = os.path.expandvars(os.path.expanduser(configured))
        return Path(expanded)

    is_windows = os.name == "nt" if platform_windows is None else bool(platform_windows)
    if is_windows:
        has_e = Path("E:/").exists() if e_drive_available is None else bool(e_drive_available)
        if has_e:
            return Path("E:/AuroraData/LocalAssistant")
        local_app_data = str(env.get("LOCALAPPDATA", "") or "").strip()
        base = Path(local_app_data) if local_app_data else Path.home() / "AppData" / "Local"
        return base / "LocalAssistant"

    local_app_data = str(env.get("LOCALAPPDATA", "") or "").strip()
    base = Path(local_app_data) if local_app_data else Path.home()
    return base / "LocalAssistant"
