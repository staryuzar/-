@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import ast,pathlib,sys; files=list(pathlib.Path('.').glob('*.py'))+list(pathlib.Path('tests').glob('*.py')); [ast.parse(p.read_text(encoding='utf-8'), filename=str(p)) for p in files]"
  if errorlevel 1 goto failed
  ".venv\Scripts\python.exe" -m unittest discover -s tests -v
) else (
  py -3 -c "import ast,pathlib,sys; files=list(pathlib.Path('.').glob('*.py'))+list(pathlib.Path('tests').glob('*.py')); [ast.parse(p.read_text(encoding='utf-8'), filename=str(p)) for p in files]"
  if errorlevel 1 goto failed
  py -3 -m unittest discover -s tests -v
)
if errorlevel 1 goto failed
echo.
echo All simulation tests passed.
pause
exit /b 0
:failed
echo Tests failed. Review the error output above.
pause
exit /b 1
