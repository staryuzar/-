"""Self-diagnostic helpers for Aurora's Arabic Operations Center.

Only safe operational metadata is persisted here. Never pass chat text, page text,
API keys, tool arguments, screenshots, or user message contents to these helpers.
"""
from __future__ import annotations

import importlib.metadata
import importlib.util
import json
import os
import platform
import re
import shutil
import sqlite3
import time
import urllib.error
import urllib.request
from datetime import datetime
from contextlib import closing
from pathlib import Path
from typing import Any, Iterable

EVENT_TABLE = "operation_events"
TASK_TABLE = "operation_task_runs"


def utc_now_local() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def initialize_operations_log(db_path: str | Path) -> None:
    """Create the event log in Aurora's existing unified SQLite DB, never a side DB."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path, timeout=5)) as con:
        con.execute(
            f"""CREATE TABLE IF NOT EXISTS {EVENT_TABLE} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                level TEXT NOT NULL,
                area TEXT NOT NULL,
                event TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT ''
            )"""
        )
        con.execute(f"CREATE INDEX IF NOT EXISTS idx_{EVENT_TABLE}_created_at ON {EVENT_TABLE}(created_at DESC)")
        con.execute(
            f"""CREATE TABLE IF NOT EXISTS {TASK_TABLE} (
                task_id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL DEFAULT '',
                state TEXT NOT NULL,
                label TEXT NOT NULL,
                started_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                process_id INTEGER NOT NULL,
                round_number INTEGER NOT NULL DEFAULT 0,
                current_tool TEXT NOT NULL DEFAULT '',
                tool_count INTEGER NOT NULL DEFAULT 0
            )"""
        )
        con.execute(f"CREATE INDEX IF NOT EXISTS idx_{TASK_TABLE}_updated_at ON {TASK_TABLE}(updated_at DESC)")
        con.commit()


_TOKEN_PATTERNS = (
    re.compile(r"(?i)\b(api[_-]?key|access[_-]?token|secret|authorization|token)\s*[:=]\s*([^\s,;]+)"),
    re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"(?i)\b(?:sk-[A-Za-z0-9_-]{16,}|AIza[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|or-v1-[A-Za-z0-9_-]{20,}|xox[baprs]-[A-Za-z0-9-]{10,})\b"),
)
_WINDOWS_PATH_RE = re.compile(r'(?i)\b[A-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*')
_POSIX_PRIVATE_PATH_RE = re.compile(r"(?<![A-Za-z0-9])/(?:home|Users|mnt/data|private/var|root|tmp)/[^\s,;\"']+")


def _safe_event_text(value: Any, limit: int = 240) -> str:
    """Constrain metadata and redact credential patterns and absolute machine paths."""
    text = " ".join(str(value or "").replace("\x00", " ").split())
    for env_name in ("GEMINI_API_KEY", "OPENROUTER_API_KEY"):
        secret = os.getenv(env_name, "").strip()
        if secret:
            text = text.replace(secret, "[مخفي]")
    for pattern in _TOKEN_PATTERNS:
        if pattern.pattern.startswith(r"(?i)\b(api"):
            text = pattern.sub(lambda match: f"{match.group(1)}=[مخفي]", text)
        else:
            text = pattern.sub("[اعتماد/رمز مخفي]", text)
    text = _WINDOWS_PATH_RE.sub("[مسار محلي محجوب]", text)
    text = _POSIX_PRIVATE_PATH_RE.sub("[مسار محلي محجوب]", text)
    return text[:limit]


def record_operation_event(
    db_path: str | Path,
    *,
    level: str,
    area: str,
    event: str,
    detail: str = "",
) -> bool:
    """Record low-sensitivity operational facts. Returns False instead of breaking app flow."""
    try:
        initialize_operations_log(db_path)
        with closing(sqlite3.connect(db_path, timeout=3)) as con:
            con.execute(
                f"INSERT INTO {EVENT_TABLE}(created_at,level,area,event,detail) VALUES(?,?,?,?,?)",
                (utc_now_local(), _safe_event_text(level, 16), _safe_event_text(area, 48),
                 _safe_event_text(event, 180), _safe_event_text(detail, 240)),
            )
            con.execute(
                f"DELETE FROM {EVENT_TABLE} WHERE id NOT IN (SELECT id FROM {EVENT_TABLE} ORDER BY id DESC LIMIT 500)"
            )
            con.commit()
        return True
    except Exception:
        return False


def recent_operation_events(db_path: str | Path, limit: int = 30) -> list[dict[str, str]]:
    try:
        with closing(sqlite3.connect(f"file:{Path(db_path).resolve().as_posix()}?mode=ro", uri=True, timeout=2)) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute(
                f"SELECT created_at,level,area,event,detail FROM {EVENT_TABLE} ORDER BY id DESC LIMIT ?",
                (min(max(int(limit), 1), 100),),
            ).fetchall()
            return [dict(row) for row in rows]
    except Exception:
        return []


def record_runtime_task_state(db_path: str | Path, task: dict[str, Any]) -> bool:
    """Persist a small, shared task heartbeat in Aurora's unified DB for other sessions."""
    try:
        task_id = _safe_event_text(task.get("task_id", ""), 64)
        if not task_id:
            return False
        initialize_operations_log(db_path)
        with closing(sqlite3.connect(db_path, timeout=2)) as con:
            con.execute(
                f"""INSERT INTO {TASK_TABLE}
                (task_id,conversation_id,state,label,started_at,updated_at,process_id,round_number,current_tool,tool_count)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(task_id) DO UPDATE SET
                state=excluded.state,label=excluded.label,updated_at=excluded.updated_at,
                process_id=excluded.process_id,round_number=excluded.round_number,
                current_tool=excluded.current_tool,tool_count=excluded.tool_count""",
                (task_id, _safe_event_text(task.get("conversation_id", ""), 80),
                 _safe_event_text(task.get("state", "unknown"), 32), _safe_event_text(task.get("label", ""), 220),
                 _safe_event_text(task.get("started_at", utc_now_local()), 40),
                 _safe_event_text(task.get("updated_at", utc_now_local()), 40), int(task.get("process_id", os.getpid())),
                 max(0, min(int(task.get("round", 0) or 0), 1000000)),
                 _safe_event_text(task.get("current_tool", ""), 80),
                 max(0, min(int(task.get("tool_count", 0) or 0), 1000000))),
            )
            con.execute(f"DELETE FROM {TASK_TABLE} WHERE task_id NOT IN (SELECT task_id FROM {TASK_TABLE} ORDER BY updated_at DESC LIMIT 100)")
            con.commit()
        return True
    except Exception:
        return False


def recent_runtime_tasks(db_path: str | Path, limit: int = 20) -> list[dict[str, Any]]:
    """Return recent persisted task states and flag a dead runner process as interrupted."""
    try:
        with closing(sqlite3.connect(f"file:{Path(db_path).resolve().as_posix()}?mode=ro", uri=True, timeout=2)) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute(
                f"SELECT task_id,conversation_id,state,label,started_at,updated_at,process_id,round_number,current_tool,tool_count FROM {TASK_TABLE} ORDER BY updated_at DESC LIMIT ?",
                (min(max(int(limit), 1), 50),),
            ).fetchall()
        result = [dict(row) for row in rows]
        for row in result:
            if row.get("state") == "running":
                pid = int(row.get("process_id", 0) or 0)
                try:
                    if pid <= 0:
                        alive = False
                    elif pid == os.getpid():
                        alive = True
                    else:
                        os.kill(pid, 0)
                        alive = True
                except PermissionError:
                    # The process may be alive but owned by another user; lack of
                    # permission to signal it is not evidence that it has exited.
                    alive = True
                except (ProcessLookupError, OSError):
                    alive = False
                if not alive:
                    row["state"] = "interrupted"
                    row["label"] = "يبدو أن عملية البرنامج التي كانت تنفذ المهمة توقفت. راجع آخر نتائج الأدوات قبل الاستئناف."
        return result
    except Exception:
        return []


def _check(
    check_id: str,
    component: str,
    status: str,
    detail: str,
    fix: str = "",
    *,
    category: str = "النظام",
    evidence: str = "",
) -> dict[str, str]:
    return {
        "id": check_id,
        "component": component,
        "status": status,  # ok | warning | error | unknown | idle
        "detail": _safe_event_text(detail, 500),
        "fix": _safe_event_text(fix, 350),
        "category": category,
        "evidence": _safe_event_text(evidence, 240),
    }


def _is_writable_directory(path: Path) -> bool:
    return path.is_dir() and os.access(path, os.W_OK)


def _distribution_version(module_name: str, distribution_name: str | None = None) -> str:
    try:
        return importlib.metadata.version(distribution_name or module_name)
    except importlib.metadata.PackageNotFoundError:
        return "غير مثبت"
    except Exception:
        return "تعذر معرفة الإصدار"


def collect_health_checks(
    *,
    project_dir: str | Path,
    data_dir: str | Path,
    db_path: str | Path,
    workspace_dir: str | Path,
    attachments_dir: str | Path,
    provider: str,
    provider_label: str,
    model_name: str,
    provider_key_configured: bool,
    provider_probe: dict[str, Any] | None = None,
    active_browser: bool = False,
    active_browser_url: str = "",
    chrome_path: str = "",
    memory_count: int | None = None,
    procedure_count: int | None = None,
    tool_names: Iterable[str] = (),
    builtin_knowledge_status: dict[str, Any] | None = None,
    database_bootstrap_status: dict[str, Any] | None = None,
    task_status: dict[str, Any] | None = None,
    network_probe: dict[str, Any] | None = None,
    deep_database_check: bool = False,
) -> list[dict[str, str]]:
    """Collect point-in-time checks. Network/API checks are only reflected if the user ran them."""
    project = Path(project_dir)
    data = Path(data_dir)
    db = Path(db_path)
    workspace = Path(workspace_dir)
    attachments = Path(attachments_dir)
    checks: list[dict[str, str]] = []

    import sys
    python_ok = sys.version_info >= (3, 10)
    checks.append(_check(
        "python_runtime", "مفسّر Python", "ok" if python_ok else "error",
        f"Python {platform.python_version()} · {platform.system()} {platform.release()}",
        "ثبّت Python 3.10 أو أحدث، ثم أعد تشغيل START_WINDOWS.bat." if not python_ok else "",
        category="التشغيل", evidence=sys.executable,
    ))

    try:
        data.mkdir(parents=True, exist_ok=True)
        writable = _is_writable_directory(data)
        checks.append(_check(
            "data_path", "مجلد البيانات", "ok" if writable else "error",
            f"المسار: {data}",
            "تحقق من وجود المجلد وصلاحية الكتابة والمساحة المتاحة." if not writable else "",
            category="التخزين", evidence=str(data),
        ))
        usage = shutil.disk_usage(data)
        free_gib = usage.free / (1024 ** 3)
        disk_status = "error" if usage.free < 256 * 1024**2 else "warning" if usage.free < 1024**3 else "ok"
        checks.append(_check(
            "data_disk_space", "المساحة المتاحة", disk_status,
            f"المتاح على قرص البيانات: {free_gib:.2f} GiB من {usage.total / (1024**3):.2f} GiB.",
            "حرّر مساحة على القرص أو انقل AURORA_DATA_DIR إلى قرص به مساحة أكبر." if disk_status != "ok" else "",
            category="التخزين", evidence=str(data.anchor or data),
        ))
    except Exception as exc:
        checks.append(_check("data_path", "مجلد البيانات", "error", f"تعذر فحص مجلد البيانات: {type(exc).__name__}.", "تحقق من مسار AURORA_DATA_DIR وصلاحيات القرص.", category="التخزين"))

    try:
        workspace.mkdir(parents=True, exist_ok=True)
        attachments.mkdir(parents=True, exist_ok=True)
        wk_ok = _is_writable_directory(workspace)
        at_ok = _is_writable_directory(attachments)
        checks.append(_check("workspace", "مساحة عمل المساعد", "ok" if wk_ok else "error",
                             f"المسار: {workspace}", "تحقق من صلاحية الكتابة في Workspace." if not wk_ok else "",
                             category="الملفات", evidence=str(workspace)))
        checks.append(_check("attachments", "مجلد الصور والمرفقات", "ok" if at_ok else "error",
                             f"المسار: {attachments}", "تحقق من صلاحية الكتابة في مجلد Attachments." if not at_ok else "",
                             category="الصور", evidence=str(attachments)))
    except Exception as exc:
        checks.append(_check("workspace", "مجلدات العمل", "error", f"تعذر التحقق: {type(exc).__name__}.", "تحقق من صلاحيات المجلدات.", category="الملفات"))

    if db.is_file():
        try:
            mode = "ro" if not deep_database_check else "ro"
            uri = f"file:{db.resolve().as_posix()}?mode={mode}"
            with closing(sqlite3.connect(uri, uri=True, timeout=5)) as con:
                con.row_factory = sqlite3.Row
                con.execute("PRAGMA busy_timeout=5000")
                pragma = "PRAGMA integrity_check" if deep_database_check else "PRAGMA quick_check"
                integrity = str(con.execute(pragma).fetchone()[0])
                tables = {str(row[0]) for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                expected = {"conversations", "memories", "procedures", "aurora_migration_ledger"}
                missing = sorted(expected - tables)
                counts = {}
                for table in ("conversations", "memories", "procedures", "aurora_migration_ledger", "operation_events", "operation_task_runs"):
                    if table in tables:
                        counts[table] = int(con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])
                good = integrity.lower() == "ok" and not missing
                detail = f"{pragma.removeprefix('PRAGMA ').upper()}={integrity}; حجم الملف {db.stat().st_size / 1024:.1f} KiB; " + ", ".join(f"{k}={v}" for k, v in counts.items())
                if missing:
                    detail += "; جداول ناقصة: " + ", ".join(missing)
                checks.append(_check("sqlite_database", "قاعدة SQLite الموحدة", "ok" if good else "error", detail,
                                     "أوقف المساعد وخذ نسخة احتياطية قبل أي إصلاح. راجع تقرير الترحيل إذا كانت جداول أساسية ناقصة." if not good else "",
                                     category="التخزين", evidence=str(db)))
        except Exception as exc:
            checks.append(_check("sqlite_database", "قاعدة SQLite الموحدة", "error", f"فشل قراءة القاعدة: {type(exc).__name__}: {str(exc)[:180]}",
                                 "تأكد أن الملف aurora.sqlite3 غير مقفول بعملية أخرى وأن القرص متاح.", category="التخزين", evidence=str(db)))
    else:
        checks.append(_check("sqlite_database", "قاعدة SQLite الموحدة", "error", f"القاعدة غير موجودة: {db}",
                             "شغّل START_WINDOWS.bat كي ينشئ قاعدة البيانات الموحدة أو راجع AURORA_DATA_DIR.", category="التخزين", evidence=str(db)))

    bootstrap = database_bootstrap_status if isinstance(database_bootstrap_status, dict) else {}
    bootstrap_integrity = str(bootstrap.get("integrity", "")).lower()
    active_count = bootstrap.get("active_database_count")
    bootstrap_warnings = bootstrap.get("warnings", []) if isinstance(bootstrap.get("warnings", []), list) else []
    bootstrap_status = "error" if bootstrap_integrity != "ok" or active_count != 1 else "warning" if bootstrap_warnings else "ok"
    migrated_count = len(bootstrap.get("migrated", [])) if isinstance(bootstrap.get("migrated", []), list) else 0
    archived_count = len(bootstrap.get("archived", [])) if isinstance(bootstrap.get("archived", []), list) else 0
    bootstrap_detail = f"integrity={bootstrap_integrity or 'غير متاح'}؛ قواعد نشطة={active_count if active_count is not None else 'غير معروف'}؛ عمليات دمج={migrated_count}؛ أرشفة قديمة={archived_count}."
    if bootstrap_warnings:
        bootstrap_detail += " تحذيرات: " + " | ".join(_safe_event_text(w, 120) for w in bootstrap_warnings[:2])
    checks.append(_check("database_bootstrap", "تهيئة وترحيل قاعدة البيانات", bootstrap_status, bootstrap_detail,
                         "راجع تحذيرات الترحيل قبل حذف أي قاعدة قديمة. إذا كانت integrity غير سليمة فأوقف الكتابة وخذ نسخة احتياطية." if bootstrap_status != "ok" else "",
                         category="التخزين", evidence=str(db)))

    # A second active database in the data root is a warning; archived legacy copies are expected.
    legacy_found = [name for name in ("chat_history.sqlite3", "long_term_memory.sqlite3") if (data / name).exists()]
    checks.append(_check("legacy_database_files", "ازدواجية قواعد SQLite", "warning" if legacy_found else "ok",
                         "توجد ملفات قديمة في مجلد البيانات: " + ", ".join(legacy_found) if legacy_found else "لا توجد قواعد SQLite قديمة نشطة في جذر مجلد البيانات.",
                         "لا تحذفها يدويًا. راجع أداة الترحيل وتأكد من وجود نسخة احتياطية سليمة." if legacy_found else "",
                         category="التخزين", evidence=str(data)))

    for module_name, label in (
        ("assistant_core", "محرك المحادثة والمنطق"),
        ("database_manager", "مدير قاعدة البيانات"),
        ("conversation_store", "حفظ المحادثات"),
        ("long_term_memory", "محرك الذاكرة طويلة المدى"),
        ("memory_context", "استرجاع سياق الذاكرة"),
        ("tool_executor", "تنفيذ الأدوات"),
        ("browser_control", "أدوات المتصفح"),
        ("windows_tools", "أدوات سطح المكتب"),
        ("gemini_native_client", "عميل Gemini الأصلي"),
    ):
        try:
            source_available = importlib.util.find_spec(module_name) is not None
        except (ImportError, ValueError):
            source_available = False
        checks.append(_check(f"source_{module_name}", label, "ok" if source_available else "error",
                             "وحدة Python موجودة على مسار الاستيراد." if source_available else f"تعذر العثور على الوحدة {module_name}.py.",
                             "أعد فك الحزمة كاملة إلى مجلد واحد ولا تنقل ملفات Python منفردة." if not source_available else "",
                             category="ترابط الأكواد", evidence=module_name))

    dependencies = [
        ("streamlit", "streamlit", "واجهة غرفة المحادثة", True),
        ("dotenv", "python-dotenv", "قراءة إعدادات .env", True),
        ("openai", "openai", "عميل OpenRouter", True),
        ("PIL", "Pillow", "معالجة الصور", True),
        ("selenium", "selenium", "أتمتة المتصفح", False),
        ("pywinauto", "pywinauto", "أتمتة نوافذ Windows", False),
        ("pyautogui", "pyautogui", "التقاط الشاشة والتحكم المرئي", False),
        ("pyperclip", "pyperclip", "الحافظة والنص العربي", False),
    ]
    for module_name, distribution, label, required in dependencies:
        try:
            available = importlib.util.find_spec(module_name) is not None
        except (ImportError, ValueError):
            available = False
        version = _distribution_version(module_name, distribution) if available else "غير مثبت"
        status = "ok" if available else ("error" if required else "warning")
        checks.append(_check(f"dependency_{module_name.lower()}", label, status,
                             f"{distribution}: {version}" if available else f"المكتبة {distribution} غير مثبتة.",
                             f"شغّل START_WINDOWS.bat لإكمال تثبيت الاعتماديات. المكتبة المطلوبة: {distribution}." if not available else "",
                             category="الاعتماديات", evidence=distribution))

    provider_status = "ok" if provider_key_configured else "error"
    checks.append(_check("provider_key", "إعداد مزود الذكاء الاصطناعي", provider_status,
                         f"المزود المختار: {provider_label} · النموذج: {model_name or 'غير محدد'} · المفتاح {'موجود (القيمة مخفية)' if provider_key_configured else 'غير مضبوط أو ما زال قيمة تجريبية'}.",
                         "أضف مفتاحًا فعليًا في .env، ثم أعد تشغيل التطبيق. لا تضع المفتاح في المحادثة." if not provider_key_configured else "",
                         category="الذكاء الاصطناعي", evidence=f"provider={provider}"))
    probe = provider_probe if isinstance(provider_probe, dict) else {}
    if not probe:
        probe_status, probe_detail, probe_fix = "unknown", "لم يُجرَ اختبار اتصال من داخل Aurora في هذه الجلسة.", "اضغط «اختبار اتصال النموذج» للتحقق من المصادقة والشبكة معًا."
    elif not probe.get("ok"):
        probe_status, probe_detail, probe_fix = "error", str(probe.get("detail", "فشل آخر اختبار اتصال.")), "راجع نوع الخطأ؛ تحقق من المفتاح والنموذج والحصة والاتصال."
    else:
        probe_status, probe_detail, probe_fix = "ok", str(probe.get("detail", "نجح الاتصال.")), ""
    checks.append(_check("provider_connection", "الاتصال الفعلي بالنموذج", probe_status, probe_detail, probe_fix,
                         category="الذكاء الاصطناعي", evidence=f"آخر فحص: {probe.get('time', 'لا يوجد')}"))

    # A browser not opened yet is idle, not broken. Only report live status when checked.
    if active_browser:
        checks.append(_check("browser_session", "جلسة Selenium الحالية", "ok", f"جلسة متصفح مفتوحة؛ العنوان: {active_browser_url or 'غير متاح'}.", category="المتصفح", evidence="جلسة حالية"))
    else:
        checks.append(_check("browser_session", "جلسة Selenium الحالية", "idle", "لا توجد جلسة Selenium مفتوحة حاليًا؛ هذا طبيعي حتى يطلب المستخدم مهمة متصفح.",
                             "لا إجراء مطلوب. افتح موقعًا عبر المساعد إذا كنت تريد اختبار التشغيل الحي.", category="المتصفح"))
    checks.append(_check("chrome_install", "تثبيت Chrome", "ok" if chrome_path else "warning",
                         f"Chrome: {chrome_path}" if chrome_path else "لم يُعثر على Chrome في المسارات الشائعة.",
                         "ثبّت Google Chrome أو تحقق من مساره إذا كنت تحتاج إلى Selenium." if not chrome_path else "",
                         category="المتصفح", evidence=chrome_path))
    debugger = os.getenv("AURORA_CHROME_DEBUGGER_ADDRESS", "").strip()
    checks.append(_check("personal_chrome", "اتصال Chrome الشخصي", "ok" if debugger else "idle",
                         f"عنوان التصحيح المحلي مضبوط: {debugger}" if debugger else "غير مفعّل؛ سيستخدم Selenium ملف Aurora المنفصل ما لم تستخدم أدوات Windows للنافذة الحالية.",
                         "إن أردت إرفاق Chrome الشخصي، اضبط AURORA_CHROME_DEBUGGER_ADDRESS بعد تشغيل Chrome مع منفذ تصحيح محلي آمن." if not debugger else "",
                         category="المتصفح"))

    windows = os.name == "nt"
    desktop_modules = all(importlib.util.find_spec(m) is not None for m in ("pywinauto", "pyautogui", "pyperclip"))
    if not windows:
        checks.append(_check("desktop_automation", "التحكم في برامج Windows", "warning", "هذا الفحص يجري على نظام غير Windows؛ لا يمكن اختبار واجهات Windows هنا.",
                             "شغّل غرفة العمليات من Windows للحصول على نتيجة حية.", category="سطح المكتب"))
    else:
        checks.append(_check("desktop_automation", "أدوات التحكم بسطح المكتب", "ok" if desktop_modules else "warning",
                             "مكتبات التحكم المطلوبة مثبتة؛ لم يُجرَ نقر على نافذة في هذا الفحص." if desktop_modules else "هناك مكتبة أو أكثر من pywinauto/pyautogui/pyperclip غير متاحة.",
                             "أعد تثبيت الاعتماديات ثم جرّب اختبار نافذة غير حساسة." if not desktop_modules else "اختبرها من خلال عرض النوافذ المفتوحة أو فحص نافذة تجريبية.",
                             category="سطح المكتب"))

    try:
        from PIL import Image
        import io
        probe_png = b"\x89PNG\r\n\x1a\n"  # Deliberately truncated: verifies that malformed images are rejected, not rendered.
        try:
            Image.open(io.BytesIO(probe_png)).verify()
            image_validation = "غير متوقع: قُبل ملف PNG ناقص"
            image_status = "error"
        except Exception:
            image_validation = "نجح اختبار رفض صورة ناقصة"
            image_status = "ok"
        checks.append(_check("image_pipeline", "مسار الصور والرؤية", image_status,
                             f"Pillow متاح؛ {image_validation}. فحص النموذج بالصورة يحتاج اختبار طلب حي منفصل.",
                             "أعد تثبيت Pillow إذا فشل التحقق المحلي." if image_status != "ok" else "",
                             category="الصور", evidence=_distribution_version("PIL", "Pillow")))
    except Exception as exc:
        checks.append(_check("image_pipeline", "مسار الصور والرؤية", "error", f"تعذر اختبار Pillow: {type(exc).__name__}.",
                             "شغّل START_WINDOWS.bat لإكمال تثبيت Pillow.", category="الصور"))

    # Exercise the action-governance gate with harmless in-memory probes. This catches
    # missing category mappings and fail-open regressions before the next live action.
    policy_probes = (
        ("browser_read_page", {}, "اقرأ الصفحة الحالية", "allow", "routine_auto"),
        ("browser_click_text", {"text": "Send"}, "اقرأ البريد فقط", "deny", "routine_auto"),
        ("browser_click_text", {"text": "Send"}, "أرسل لي تقرير الاختبار على واتساب", "allow", "routine_auto"),
        ("browser_click_text", {"text": "Send"}, "اقرأ البريد ولا ترسل شيئًا", "deny", "routine_auto"),
        ("browser_click_text", {"text": "Install"}, "ثبت هذا البرنامج", "allow", "routine_auto"),
        ("browser_click_text", {"text": "Sign in", "_policy_current_url": "https://accounts.google.com/signin"}, "اقرأ البريد غير المقروء", "allow", "routine_auto"),
        ("run_shell_command", {"command": "powershell.exe -EncodedCommand QUJDREVGRw=="}, "اختبر الحزمة", "review", "routine_auto"),
    )
    try:
        from security_utils import tool_action_decision
        policy_results = [tool_action_decision(name, args, request, mode=mode)[0] for name, args, request, _, mode in policy_probes]
        expected_policy_results = [expected for _, _, _, expected, _ in policy_probes]
        policy_ok = policy_results == expected_policy_results
        policy_detail = f"اجتاز {sum(a == b for a, b in zip(policy_results, expected_policy_results))}/{len(policy_probes)} اختبارات سياسة داخلية تشمل التنفيذ التلقائي الصريح والمنع، دون تنفيذ أي أداة فعلية."
        if not policy_ok:
            policy_detail += f" النتائج={policy_results}؛ المتوقع={expected_policy_results}."
        policy_fix = "راجع security_utils.py واختبارات test_security_utils.py قبل السماح بأي إجراءات متصفح أو نظام." if not policy_ok else ""
        checks.append(_check("action_policy", "حوكمة الأفعال والموافقات", "ok" if policy_ok else "error",
                             policy_detail, policy_fix, category="الأمن", evidence="اختبارات in-memory فقط"))
    except Exception as exc:
        checks.append(_check("action_policy", "حوكمة الأفعال والموافقات", "error",
                             f"تعذر تشغيل فحص سياسة الأفعال: {type(exc).__name__}.",
                             "تحقق من security_utils.py وأعد تشغيل الاختبارات.", category="الأمن"))

    names = list(tool_names)
    dupes = len(names) != len(set(names))
    checks.append(_check("tool_registry", "سجل أدوات المساعد", "error" if not names or dupes else "ok",
                         f"عدد تعريفات الأدوات: {len(names)}؛ أسماء مكررة: {'نعم' if dupes else 'لا'}.",
                         "راجع TOOL_DEFINITIONS لمنع أسماء فارغة أو مكررة." if not names or dupes else "",
                         category="محرك المساعد", evidence=f"tool_count={len(names)}"))

    knowledge = builtin_knowledge_status if isinstance(builtin_knowledge_status, dict) else {}
    added = knowledge.get("procedures_added", "غير معروف")
    memory_detail = f"الذكريات: {memory_count if memory_count is not None else 'غير متاح'}؛ وصفات الإجراءات: {procedure_count if procedure_count is not None else 'غير متاح'}؛ وصفات مُضافة عند التهيئة: {added}."
    memory_ready = memory_count is not None and procedure_count is not None
    checks.append(_check("memory", "الذاكرة والإجراءات", "ok" if memory_ready else "warning", memory_detail,
                         "تحقق من قاعدة aurora.sqlite3 وجداول memories وprocedures." if not memory_ready else "",
                         category="الذاكرة", evidence=str(db)))

    task = task_status if isinstance(task_status, dict) else {}
    task_state = str(task.get("state", "idle"))
    task_label = str(task.get("label", "لا توجد مهمة مسجلة في هذه الجلسة."))
    task_map = {"running": "ok", "completed": "ok", "failed": "error", "interrupted": "warning", "waiting_approval": "warning", "needs_continuation": "warning", "cooldown": "warning", "idle": "idle"}
    task_status_display = task_map.get(task_state, "unknown")
    task_detail = f"الحالة: {task_state} · {task_label}"
    task_fix = "راجع الخطأ الأخير وأعد المحاولة بعد تصحيح السبب." if task_state == "failed" else "افتح الموافقات المعلقة أو اطلب «تابع من آخر خطوة»." if task_state in {"waiting_approval", "needs_continuation"} else ""
    checks.append(_check("task_state", "حالة المهمة الأخيرة", task_status_display, task_detail, task_fix,
                         category="المهام", evidence=str(task.get("updated_at", "لا يوجد"))))

    net = network_probe if isinstance(network_probe, dict) else {}
    if not net:
        nstatus, ndetail, nfix = "unknown", "لم يُختبر الوصول إلى الإنترنت من داخل التطبيق بعد.", "اضغط «اختبار الإنترنت»؛ هذا لا يستخدم مفتاح API ولا يرسل بيانات المحادثة."
    else:
        good_n = int(net.get("ok_count", 0))
        total_n = int(net.get("total_count", 0))
        nstatus = "ok" if good_n == total_n and total_n else "warning" if good_n else "error"
        ndetail = f"نجح {good_n} من {total_n} فحوص اتصال عامة. آخر اختبار: {net.get('time', 'غير معروف')}."
        nfix = "تحقق من DNS والجدار الناري أو الوكيل (Proxy)؛ نجاح الوصول العام لا يثبت صلاحية مفتاح النموذج." if nstatus != "ok" else ""
    checks.append(_check("internet", "الاتصال العام بالإنترنت", nstatus, ndetail, nfix, category="الشبكة"))

    # Presence of Windows launcher and core local files helps detect incomplete extraction.
    required_files = ("START_WINDOWS.bat", "RUN_TESTS_WINDOWS.bat", "requirements.txt", "app.py", "operations_center.py", "database_manager.py", "assistant_core.py", "tool_executor.py", "image_support.py")
    missing_files = [name for name in required_files if not (project / name).is_file()]
    checks.append(_check("package_integrity", "ملفات التثبيت والتشغيل", "error" if missing_files else "ok",
                         "ملفات التشغيل الأساسية موجودة." if not missing_files else "ملفات أساسية مفقودة: " + ", ".join(missing_files),
                         "أعد فك ZIP كاملًا إلى مجلد جديد بدل نسخ بعض الملفات فقط." if missing_files else "",
                         category="الحزمة", evidence=str(project)))
    return checks


def run_public_network_probe(provider: str, timeout: float = 4.0) -> dict[str, Any]:
    """Perform a small, explicit public connectivity test without credentials or chat data."""
    targets = [
        ("Google connectivity", "https://www.google.com/generate_204"),
        (("OpenRouter reachability" if provider == "openrouter" else "Google AI endpoint reachability"),
         "https://openrouter.ai/" if provider == "openrouter" else "https://generativelanguage.googleapis.com/"),
    ]
    results = []
    for label, url in targets:
        started = time.monotonic()
        status_code = None
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Aurora-Control-Room-Diagnostics/1.0"}, method="GET")
            with urllib.request.urlopen(req, timeout=max(1.0, min(float(timeout), 8.0))) as response:
                status_code = int(response.status)
                ok = 200 <= status_code < 400
                detail = f"HTTP {status_code}"
        except urllib.error.HTTPError as exc:
            # A 4xx response from an API root proves DNS/TLS/HTTP reachability, but not API authorization.
            status_code = int(exc.code)
            ok = 400 <= status_code < 500
            detail = f"HTTP {status_code}؛ الخادم reachable لكن هذا ليس اختبار مصادقة API"
        except Exception as exc:
            ok = False
            detail = f"{type(exc).__name__}: {str(exc)[:140]}"
        results.append({"label": label, "url": url, "ok": bool(ok), "status_code": status_code,
                        "duration_ms": int((time.monotonic() - started) * 1000), "detail": detail})
    return {"time": utc_now_local(), "ok_count": sum(1 for r in results if r["ok"]),
            "total_count": len(results), "results": results}


def make_diagnostic_report(checks: list[dict[str, str]], *, version: str, project_dir: str | Path,
                           data_dir: str | Path, recent_events: list[dict[str, str]]) -> bytes:
    """JSON download with redacted operational checks only—no keys, chat, or tool arguments."""
    counts = {status: sum(1 for c in checks if c.get("status") == status) for status in ("ok", "warning", "error", "unknown", "idle")}
    safe_checks = []
    for row in checks:
        safe_checks.append({
            key: _safe_event_text(row.get(key, ""), 500 if key == "detail" else 350)
            for key in ("id", "component", "status", "detail", "fix", "category", "evidence")
        })
    safe_events = []
    for row in recent_events:
        if not isinstance(row, dict):
            continue
        safe_events.append({key: _safe_event_text(row.get(key, ""), limit) for key, limit in (
            ("created_at", 40), ("level", 16), ("area", 48), ("event", 180), ("detail", 240)
        )})
    report = {
        "product": "Aurora Control Room",
        "version": _safe_event_text(version, 40),
        "generated_at": utc_now_local(),
        "project_dir": "[مسار البرنامج المحلي محجوب]",
        "data_dir": "[مجلد البيانات المحلي محجوب]",
        "summary": counts,
        "checks": safe_checks,
        "recent_operations": safe_events,
        "privacy_note": "لا يتضمن التقرير المحادثات أو معاملات الأدوات أو محتوى الصور؛ تُحجب مسارات الجهاز المحلية ومفاتيح البيئة والأنماط الشائعة للرموز. راجع تفاصيل الفحوص قبل المشاركة.",
    }
    return json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8")
