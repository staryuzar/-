"""Direct Gemini REST diagnostic, independent of the OpenAI-compatible endpoint."""
from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


class GeminiDiagnosticError(RuntimeError):
    pass


def _safe_error_message(status: int, body: str, api_key: str) -> str:
    message = ""
    try:
        payload = json.loads(body or "{}")
        err = payload.get("error", {}) if isinstance(payload, dict) else {}
        if isinstance(err, dict):
            message = str(err.get("message") or err.get("status") or "")
        elif err:
            message = str(err)
    except (ValueError, TypeError):
        message = (body or "").strip()
    if api_key:
        message = message.replace(api_key, "[مفتاح مخفي]")
    message = " ".join(message.replace("\r", " ").replace("\n", " ").split())[:360]
    if status == 400:
        reason = "رفض Google صيغة الطلب أو أحد معاملاته (HTTP 400)."
    elif status in (401, 403):
        reason = "مفتاح API غير صالح أو لا يملك صلاحية الوصول (HTTP %d)." % status
    elif status == 404:
        reason = "لم يجد Google النموذج أو مسار API المطلوب (HTTP 404). تحقق من اسم النموذج والمسار." 
    elif status == 429:
        reason = "Google رفض الطلب بسبب حد السرعة أو الحصة (HTTP 429). انتظر إعادة الضبط؛ تغيير المفتاح لا يضمن حصة إضافية."
    elif status == 503:
        reason = "خدمة Gemini غير متاحة مؤقتًا (HTTP 503). هذا لا يثبت أن المفتاح خاطئ؛ أعد الاختبار لاحقًا مرة واحدة."
    elif status >= 500:
        reason = "حدث خطأ من خادم Google (HTTP %d)." % status
    else:
        reason = "رفض Google الطلب (HTTP %d)." % status
    return reason + (" تفاصيل Google: " + message if message else "")



def list_gemini_models(api_key: str, selected_model: str, timeout: int = 15) -> tuple[bool, str]:
    """List models visible to this key without generating content or spending output tokens."""
    api_key = str(api_key or "").strip()
    selected_model = str(selected_model or "").strip()
    if not api_key:
        return False, "لم يُضبط GEMINI_API_KEY في ملف .env."
    request = Request(
        "https://generativelanguage.googleapis.com/v1beta/models?pageSize=100",
        headers={"x-goog-api-key": api_key, "User-Agent": "Aurora-Control-Room-Diagnostic/2.3.5"},
        method="GET",
    )
    try:
        with urlopen(request, timeout=max(5, min(int(timeout), 25))) as response:
            raw = response.read(500_000).decode("utf-8", "replace")
            status = int(getattr(response, "status", 200))
        if status < 200 or status >= 300:
            return False, _safe_error_message(status, raw, api_key)
        payload = json.loads(raw or "{}")
        models = payload.get("models", []) if isinstance(payload, dict) else []
        eligible = []
        selected = None
        for item in models:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", ""))
            if name.startswith("models/"):
                name = name[len("models/"):]
            methods = item.get("supportedGenerationMethods", [])
            if not name or not isinstance(methods, list) or "generateContent" not in methods:
                continue
            eligible.append(name)
            if name == selected_model:
                selected = item
        eligible = sorted(set(eligible))
        if selected is not None:
            methods = ", ".join(selected.get("supportedGenerationMethods", []))
            return True, ("نجح فحص قائمة النماذج بمفتاحك دون إنشاء محتوى. النموذج المحدد موجود في القائمة ويدعم generateContent. "
                          + "طرق النموذج: " + methods + ". نماذج أخرى متاحة: "
                          + ", ".join(name for name in eligible if name != selected_model)[:700])
        preview = ", ".join(eligible[:24]) or "لم تُرجع Google نماذج تدعم generateContent لهذا المفتاح."
        return False, ("نجح الوصول إلى قائمة النماذج، لكن النموذج المحدد '" + selected_model
                       + "' غير موجود ضمن النماذج القابلة للتوليد التي أعادها هذا المفتاح. لا تغيّر الاسم عشوائيًا؛ النماذج المتاحة: " + preview)
    except HTTPError as exc:
        try:
            raw = exc.read(32_000).decode("utf-8", "replace")
        except Exception:
            raw = ""
        return False, _safe_error_message(int(exc.code), raw, api_key)
    except URLError as exc:
        reason = str(getattr(exc, "reason", exc)).replace(api_key, "[مفتاح مخفي]")[:220]
        return False, "تعذر الوصول إلى قائمة نماذج Google عبر الشبكة/DNS/TLS: " + reason
    except TimeoutError:
        return False, "انتهت مهلة قراءة قائمة نماذج Google؛ لم يُرسل طلب توليد محتوى."
    except Exception as exc:
        message = str(exc).replace(api_key, "[مفتاح مخفي]")[:220]
        return False, "فشل فحص قائمة النماذج: %s: %s" % (type(exc).__name__, message)

def test_gemini_native(api_key: str, model: str, timeout: int = 20) -> tuple[bool, str]:
    """Send one tiny non-sensitive request to Gemini's native REST endpoint.

    This deliberately avoids the OpenAI-compatibility endpoint so the result can
    distinguish a key/model/quota problem from a compatibility-layer problem.
    The key is passed in a header, never in the URL or returned diagnostics.
    """
    api_key = str(api_key or "").strip()
    model = str(model or "").strip()
    if not api_key:
        return False, "لم يُضبط GEMINI_API_KEY في ملف .env."
    if not model or len(model) > 160 or any(ch in model for ch in "?#/\\\r\n"):
        return False, "اسم النموذج فارغ أو غير صالح."
    url = "https://generativelanguage.googleapis.com/v1beta/models/" + quote(model, safe="-._") + ":generateContent"
    body = json.dumps({
        "contents": [{"parts": [{"text": "أجب بكلمة واحدة فقط: OK"}]}],
        "generationConfig": {"maxOutputTokens": 16},
    }).encode("utf-8")
    request = Request(url, data=body, headers={
        "Content-Type": "application/json",
        "x-goog-api-key": api_key,
        "User-Agent": "Aurora-Control-Room-Diagnostic/2.3.5",
    }, method="POST")
    try:
        with urlopen(request, timeout=max(5, min(int(timeout), 30))) as response:
            raw = response.read(250_000).decode("utf-8", "replace")
            status = int(getattr(response, "status", 200))
        if status < 200 or status >= 300:
            return False, _safe_error_message(status, raw, api_key)
        try:
            payload = json.loads(raw)
        except ValueError:
            return False, "وصل الرد من Google لكنه ليس JSON صالحًا؛ تعذر تأكيد اتصال النموذج."
        candidates = payload.get("candidates") or []
        snippets = []
        for candidate in candidates[:1]:
            content = candidate.get("content", {}) if isinstance(candidate, dict) else {}
            for part in content.get("parts", []) if isinstance(content, dict) else []:
                if isinstance(part, dict) and isinstance(part.get("text"), str):
                    snippets.append(part["text"])
        if not snippets:
            return False, "استجاب Google دون نص مولّد؛ لم أعتبر ذلك نجاحًا كاملًا. افحص حالة النموذج أو سبب الإنهاء في الرد."
        reply = " ".join(" ".join(snippets).split())[:120]
        return True, "نجح الاتصال المباشر بـ Gemini عبر REST (HTTP 200). رد الاختبار: " + reply
    except HTTPError as exc:
        try:
            raw = exc.read(32_000).decode("utf-8", "replace")
        except Exception:
            raw = ""
        return False, _safe_error_message(int(exc.code), raw, api_key)
    except URLError as exc:
        reason = str(getattr(exc, "reason", exc)).replace(api_key, "[مفتاح مخفي]")[:220]
        return False, "تعذر الوصول إلى واجهة Google عبر الشبكة/DNS/TLS: " + reason
    except TimeoutError:
        return False, "انتهت مهلة الاتصال المباشر بـ Google؛ لم تُعد المحاولة تلقائيًا."
    except Exception as exc:
        message = str(exc).replace(api_key, "[مفتاح مخفي]")[:220]
        return False, "فشل التشخيص المباشر: %s: %s" % (type(exc).__name__, message)
