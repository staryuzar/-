"""Small, testable helpers for OpenRouter HTTP 429 cooldown handling."""
from __future__ import annotations

import json
import math
import time
from datetime import datetime
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any


def _headers_from_exception(exc: Any) -> dict[str, str]:
    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None)
    if not headers:
        return {}
    try:
        return {str(k).lower(): str(v) for k, v in headers.items()}
    except Exception:
        return {}


def cooldown_until_from_exception(exc: Any, now: float | None = None, fallback_seconds: int = 60) -> float:
    """Return an epoch timestamp from reset/retry headers; use a short fallback otherwise."""
    current = time.time() if now is None else float(now)
    headers = _headers_from_exception(exc)
    reset = headers.get("x-ratelimit-reset") or headers.get("x-ratelimit-reset-requests")
    if reset:
        try:
            value = float(reset)
            # OpenRouter commonly returns milliseconds; tolerate seconds too.
            if value > 10_000_000_000:
                value /= 1000.0
            if value > current:
                return value
        except (TypeError, ValueError, OverflowError):
            pass
    retry_after = headers.get("retry-after")
    if retry_after:
        try:
            seconds = float(retry_after)
            if seconds >= 0:
                return current + seconds
        except (TypeError, ValueError, OverflowError):
            try:
                retry_date = parsedate_to_datetime(retry_after).timestamp()
                if retry_date > current:
                    return retry_date
            except (TypeError, ValueError, OverflowError):
                pass
    return current + max(1, int(fallback_seconds))


def rate_limit_message(exc: Any, now: float | None = None) -> str:
    """Create a short Arabic user-facing message without echoing raw response bodies."""
    current = time.time() if now is None else float(now)
    headers = _headers_from_exception(exc)
    reset = headers.get("x-ratelimit-reset") or headers.get("x-ratelimit-reset-requests")
    reset_epoch = None
    if reset:
        try:
            reset_epoch = float(reset)
            if reset_epoch > 10_000_000_000:
                reset_epoch /= 1000.0
        except (TypeError, ValueError, OverflowError):
            reset_epoch = None
    metadata = getattr(exc, "body", None)
    metadata_text = str(metadata or "").lower()
    response = getattr(exc, "response", None)
    if response is not None:
        try:
            metadata_text += " " + str(response.text or "").lower()
        except Exception:
            pass
    daily_free = "free-models-per-day" in metadata_text or "openrouter_free_tier_daily" in metadata_text
    if daily_free:
        if reset_epoch and reset_epoch > current:
            reset_local = datetime.fromtimestamp(reset_epoch).strftime("%Y-%m-%d %H:%M")
            return f"استُنفدت الحصة اليومية للنماذج المجانية في OpenRouter. أوقفت إعادة المحاولة التلقائية. وقت إعادة الضبط المتوقع حسب ساعة جهازك: {reset_local}. لا تضغط اختبار الاتصال قبل ذلك؛ يمكنك تغيير النموذج إذا كان لديك مسار استخدام متاح."
        return "استُنفدت الحصة اليومية للنماذج المجانية في OpenRouter. أوقفت إعادة المحاولة التلقائية؛ انتظر إعادة ضبط الحصة أو استخدم نموذجًا/مزودًا له حصة متاحة."
    until = cooldown_until_from_exception(exc, now=current)
    seconds = max(1, math.ceil(until - current))
    return f"رفض OpenRouter الطلب بسبب حد الاستخدام (HTTP 429). أوقفت إعادة المحاولة التلقائية؛ انتظر نحو {seconds} ثانية قبل إعادة الاختبار."


def load_cooldown(path: str | Path, now: float | None = None) -> dict[str, Any] | None:
    """Load non-secret cooldown metadata; discard expired or malformed state."""
    current = time.time() if now is None else float(now)
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        until = float(data.get("until", 0))
        if until > current:
            return {"until": until, "message": str(data.get("message", "حد استخدام مؤقت؛ انتظر قبل إعادة المحاولة."))[:1000]}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None
    return None


def save_cooldown(path: str | Path, until: float, message: str) -> None:
    """Persist only the cooldown timestamp/message, never the API key or request content."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({"until": float(until), "message": str(message)[:1000]}, ensure_ascii=False), encoding="utf-8")
