"""Native Gemini REST chat adapter with OpenAI-compatible internal message objects.

Uses Google's documented generateContent endpoint directly, including native
function calling. No API key is placed in a URL or written to logs.
"""
from __future__ import annotations

import base64
import json
import uuid
from types import SimpleNamespace
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from typing import Any


class GeminiNativeError(RuntimeError):
    def __init__(self, status_code: int | None, message: str, status: str = ""):
        self.status_code = status_code
        self.provider_status = status
        self.message = message
        super().__init__(message)


def _parse_json(value: Any, fallback: Any):
    if not isinstance(value, str):
        return value if value is not None else fallback
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return fallback


def _safe_google_error(status_code: int, body: str, api_key: str) -> str:
    try:
        data = json.loads(body or "{}")
        error = data.get("error", {}) if isinstance(data, dict) else {}
        message = str(error.get("message") or error.get("status") or "") if isinstance(error, dict) else str(error)
        provider_status = str(error.get("status") or "") if isinstance(error, dict) else ""
    except (ValueError, TypeError):
        message, provider_status = (body or "").strip(), ""
    if api_key:
        message = message.replace(api_key, "[مفتاح مخفي]")
    message = " ".join(message.replace("\r", " ").replace("\n", " ").split())[:520]
    if status_code == 400:
        category = "رفضت Google صيغة الطلب أو معاملات إحدى الأدوات (HTTP 400)."
    elif status_code in (401, 403):
        category = "رفضت Google المفتاح أو صلاحية المشروع لهذا الطلب (HTTP %d)." % status_code
    elif status_code == 404:
        category = "لم تجد Google النموذج أو المسار المطلوب (HTTP 404)."
    elif status_code == 429:
        category = "وصل الطلب إلى حد الاستخدام أو الحصة المتاحة (HTTP 429). لا تكرر المحاولة تلقائيًا."
    elif status_code == 503:
        category = "خدمة Gemini غير متاحة مؤقتًا (HTTP 503)."
    elif status_code >= 500:
        category = "حدث خطأ في خادم Google (HTTP %d)." % status_code
    else:
        category = "رفضت Google الطلب (HTTP %d)." % status_code
    if provider_status:
        category += " رمز Google: " + provider_status[:100] + "."
    if message:
        category += " التفاصيل: " + message
    return category


class NativeFunctionCall:
    def __init__(self, call_id: str, name: str, arguments: dict, thought_signature: str | None = None):
        self.id = call_id or str(uuid.uuid4())
        self.type = "function"
        self.thought_signature = thought_signature
        self.function = SimpleNamespace(name=name, arguments=json.dumps(arguments, ensure_ascii=False))

    def model_dump(self, exclude_none: bool = True) -> dict:
        payload = {"id": self.id, "type": "function", "function": {"name": self.function.name, "arguments": self.function.arguments}}
        if self.thought_signature:
            payload["thoughtSignature"] = self.thought_signature
        return payload



def _clean_gemini_schema(value: Any) -> Any:
    """Remove JSON Schema keys not accepted by Gemini's function declaration subset."""
    if isinstance(value, dict):
        return {key: _clean_gemini_schema(item) for key, item in value.items() if key not in {"additionalProperties", "$schema", "$id", "definitions", "$defs"}}
    if isinstance(value, list):
        return [_clean_gemini_schema(item) for item in value]
    return value

def _tool_calls_to_gemini(tools: list[dict] | None) -> list[dict]:
    declarations = []
    for item in tools or []:
        if not isinstance(item, dict):
            continue
        function = item.get("function", item)
        if not isinstance(function, dict):
            continue
        name = str(function.get("name") or "").strip()
        if not name:
            continue
        declaration = {"name": name, "description": str(function.get("description") or "")[:1000]}
        parameters = function.get("parameters")
        if isinstance(parameters, dict):
            declaration["parameters"] = _clean_gemini_schema(parameters)
        declarations.append(declaration)
    return declarations


def _messages_to_gemini(messages: list[dict], attachments_dir=None) -> list[dict]:
    result: list[dict] = []
    call_names: dict[str, str] = {}
    total_request_image_bytes = 0

    def append_content(role: str, parts: list[dict]):
        parts = [p for p in parts if isinstance(p, dict) and p]
        if not parts:
            return
        # Gemini expects alternating user/model turns. Merge adjacent same-role parts.
        if result and result[-1].get("role") == role:
            result[-1].setdefault("parts", []).extend(parts)
        else:
            result.append({"role": role, "parts": parts})

    for message in messages or []:
        if not isinstance(message, dict):
            continue
        role = message.get("role")
        if role == "system":
            continue
        if role == "user":
            parts: list[dict] = []
            content = message.get("content")
            if isinstance(content, str) and content.strip():
                parts.append({"text": content})
            attachments = message.get("attachments") or []
            if attachments:
                if attachments_dir is None:
                    raise ValueError("وصلت صورة للمحادثة دون تحديد مجلد المرفقات المحلي.")
                from image_support import load_attachment, ImageAttachmentError, MAX_IMAGES_PER_MESSAGE, MAX_TOTAL_IMAGE_BYTES
                if len(attachments) > MAX_IMAGES_PER_MESSAGE:
                    raise ImageAttachmentError("تحتوي رسالة محفوظة على صور أكثر من الحد المسموح.")
                for attachment in attachments:
                    loaded = load_attachment(attachment, attachments_dir)
                    total_request_image_bytes += loaded["size_bytes"]
                    if total_request_image_bytes > MAX_TOTAL_IMAGE_BYTES:
                        raise ImageAttachmentError("مجموع الصور المرسلة في الطلب الحالي يتجاوز 8 ميبيبايت؛ ابدأ محادثة جديدة أو أعد إرفاق الصورة المطلوبة فقط.")
                    parts.append({"inlineData": {
                        "mimeType": loaded["mime_type"],
                        "data": base64.b64encode(loaded["data"]).decode("ascii"),
                    }})
            append_content("user", parts)
        elif role == "assistant":
            parts: list[dict] = []
            content = message.get("content")
            if isinstance(content, str) and content.strip():
                parts.append({"text": content})
            for call in message.get("tool_calls", []) or []:
                if not isinstance(call, dict):
                    continue
                call_id = str(call.get("id") or uuid.uuid4())
                function = call.get("function", {})
                if not isinstance(function, dict):
                    continue
                name = str(function.get("name") or "").strip()
                if not name:
                    continue
                args = _parse_json(function.get("arguments", "{}"), {})
                if not isinstance(args, dict):
                    args = {}
                call_names[call_id] = name
                function_part = {"functionCall": {"id": call_id, "name": name, "args": args}}
                # Gemini 3 may return a thought signature that must be sent back unchanged.
                if isinstance(call.get("thoughtSignature"), str) and call["thoughtSignature"]:
                    function_part["thoughtSignature"] = call["thoughtSignature"]
                parts.append(function_part)
            append_content("model", parts)
        elif role == "tool":
            call_id = str(message.get("tool_call_id") or "")
            name = call_names.get(call_id, "unknown_tool")
            output = _parse_json(message.get("content", "{}"), {})
            if not isinstance(output, dict):
                output = {"result": output}
            function_response = {"name": name, "response": output}
            if call_id:
                function_response["id"] = call_id
            append_content("user", [{"functionResponse": function_response}])
    return result


def native_gemini_chat_completion(
    api_key: str,
    model: str,
    system_prompt: str,
    messages: list[dict],
    tools: list[dict] | None = None,
    timeout: int | None = None,
    max_output_tokens: int = 8192,
    attachments_dir=None,
):
    api_key = str(api_key or "").strip()
    model = str(model or "").strip()
    if not api_key:
        raise GeminiNativeError(None, "لم يُضبط GEMINI_API_KEY في ملف .env.")
    if not model or len(model) > 160 or any(ch in model for ch in "?#/\\\r\n"):
        raise GeminiNativeError(None, "اسم نموذج Gemini فارغ أو غير صالح.")

    contents = _messages_to_gemini(messages, attachments_dir=attachments_dir)
    if not contents:
        raise GeminiNativeError(None, "لا توجد رسائل صالحة لإرسالها إلى Gemini.")
    body: dict[str, Any] = {
        "systemInstruction": {"parts": [{"text": str(system_prompt or "")}]},
        "contents": contents,
        "generationConfig": {"maxOutputTokens": max(256, min(int(max_output_tokens), 16384))},
    }
    declarations = _tool_calls_to_gemini(tools)
    if declarations:
        body["tools"] = [{"functionDeclarations": declarations}]
        body["toolConfig"] = {"functionCallingConfig": {"mode": "AUTO"}}

    url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"
    request = Request(url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"), headers={
        "Content-Type": "application/json",
        "x-goog-api-key": api_key,
        "User-Agent": "Aurora-Control-Room/2.4.0",
    }, method="POST")
    try:
        with urlopen(request, timeout=timeout) as response:
            raw = response.read(2_000_000).decode("utf-8", "replace")
            status = int(getattr(response, "status", 200))
    except HTTPError as exc:
        try:
            raw = exc.read(64_000).decode("utf-8", "replace")
        except Exception:
            raw = ""
        raise GeminiNativeError(int(exc.code), _safe_google_error(int(exc.code), raw, api_key)) from None
    except URLError as exc:
        reason = str(getattr(exc, "reason", exc)).replace(api_key, "[مفتاح مخفي]")[:260]
        raise GeminiNativeError(None, "تعذر الوصول إلى Google عبر الشبكة أو DNS أو TLS: " + reason) from None
    except TimeoutError:
        raise GeminiNativeError(None, "انتهت مهلة الاتصال بـ Gemini؛ لم تُعد المحاولة تلقائيًا.") from None
    except Exception as exc:
        message = str(exc).replace(api_key, "[مفتاح مخفي]")[:260]
        raise GeminiNativeError(None, type(exc).__name__ + ": " + message) from None

    if status < 200 or status >= 300:
        raise GeminiNativeError(status, _safe_google_error(status, raw, api_key))
    try:
        payload = json.loads(raw or "{}")
    except ValueError:
        raise GeminiNativeError(status, "أعاد Gemini استجابة ليست JSON صالحًا.") from None

    candidates = payload.get("candidates") or []
    if not candidates:
        feedback = payload.get("promptFeedback") or {}
        reason = str(feedback.get("blockReason") or "") if isinstance(feedback, dict) else ""
        detail = " سبب الرفض: " + reason if reason else ""
        raise GeminiNativeError(status, "استجاب Gemini دون مرشح نصي أو استدعاء أداة." + detail)
    candidate = candidates[0] if isinstance(candidates[0], dict) else {}
    content = candidate.get("content") or {}
    parts = content.get("parts") or []
    text_parts: list[str] = []
    tool_calls: list[NativeFunctionCall] = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        if isinstance(part.get("text"), str):
            text_parts.append(part["text"])
        function_call = part.get("functionCall")
        if isinstance(function_call, dict):
            name = str(function_call.get("name") or "").strip()
            args = function_call.get("args", {})
            if name:
                if not isinstance(args, dict):
                    args = {}
                tool_calls.append(NativeFunctionCall(str(function_call.get("id") or uuid.uuid4()), name, args, part.get("thoughtSignature")))
    assistant_message = SimpleNamespace(content="\n".join(text_parts).strip() or None, tool_calls=tool_calls or None)
    choice = SimpleNamespace(message=assistant_message, finish_reason=candidate.get("finishReason"))
    return SimpleNamespace(choices=[choice], status_code=status)
