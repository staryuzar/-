"""SQLite persistence for chat-room conversations, isolated for deterministic tests."""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from assistant_core import redact_messages_for_storage, timestamp_now


class ConversationStore:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        con = sqlite3.connect(self.db_path, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def initialize(self):
        with self.connect() as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute(
                """CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL DEFAULT 'محادثة جديدة',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    messages_json TEXT NOT NULL DEFAULT '[]',
                    log_json TEXT NOT NULL DEFAULT '[]',
                    pending_json TEXT NOT NULL DEFAULT '[]'
                )"""
            )
            columns = {r["name"] for r in con.execute("PRAGMA table_info(conversations)").fetchall()}
            migrations = {
                "created_at": "TEXT NOT NULL DEFAULT ''",
                "updated_at": "TEXT NOT NULL DEFAULT ''",
                "messages_json": "TEXT NOT NULL DEFAULT '[]'",
                "log_json": "TEXT NOT NULL DEFAULT '[]'",
                "pending_json": "TEXT NOT NULL DEFAULT '[]'",
            }
            for col, definition in migrations.items():
                if col not in columns:
                    con.execute(f"ALTER TABLE conversations ADD COLUMN {col} {definition}")
            columns = {r["name"] for r in con.execute("PRAGMA table_info(conversations)").fetchall()}
            if "tool_log_json" in columns:
                con.execute(
                    """UPDATE conversations SET log_json = tool_log_json
                       WHERE (log_json IS NULL OR log_json = '[]') AND tool_log_json IS NOT NULL"""
                )
            now = timestamp_now()
            con.execute("UPDATE conversations SET created_at=? WHERE created_at IS NULL OR created_at=''", (now,))
            con.execute("UPDATE conversations SET updated_at=created_at WHERE updated_at IS NULL OR updated_at='' ")

    def create(self, title: str = "محادثة جديدة") -> str:
        conversation_id = str(uuid.uuid4())
        now = timestamp_now()
        with self.connect() as con:
            con.execute(
                "INSERT INTO conversations (id,title,created_at,updated_at,messages_json,log_json,pending_json) VALUES (?,?,?,?, '[]','[]','[]')",
                (conversation_id, str(title or "محادثة جديدة")[:120], now, now),
            )
        return conversation_id

    def list(self, limit: int = 500):
        safe_limit = min(max(int(limit), 1), 500)
        with self.connect() as con:
            return con.execute(
                "SELECT id,title,updated_at,messages_json,log_json,pending_json FROM conversations ORDER BY updated_at DESC LIMIT ?",
                (safe_limit,),
            ).fetchall()

    def get_row(self, conversation_id: str):
        with self.connect() as con:
            return con.execute("SELECT * FROM conversations WHERE id=?", (conversation_id,)).fetchone()

    def save(self, conv: dict):
        with self.connect() as con:
            cursor = con.execute(
                """UPDATE conversations SET title=?, updated_at=?, messages_json=?, log_json=?, pending_json=? WHERE id=?""",
                (
                    str(conv.get("title") or "محادثة جديدة")[:120], timestamp_now(),
                    json.dumps(redact_messages_for_storage(conv.get("messages", [])), ensure_ascii=False),
                    json.dumps(conv.get("log", []), ensure_ascii=False),
                    json.dumps(conv.get("pending", []), ensure_ascii=False),
                    conv["id"],
                ),
            )
            if cursor.rowcount == 0:
                raise KeyError("المحادثة غير موجودة أو حُذفت.")

    def delete(self, conversation_id: str):
        with self.connect() as con:
            con.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))

    def count(self) -> int:
        with self.connect() as con:
            return int(con.execute("SELECT COUNT(*) AS n FROM conversations").fetchone()["n"])
