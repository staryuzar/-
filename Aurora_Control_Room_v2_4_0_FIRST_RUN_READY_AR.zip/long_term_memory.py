"""Persistent local memory for useful facts and task continuity across conversations."""
from __future__ import annotations

import json
import re
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _clean(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) > limit:
        raise ValueError(f"النص أطول من الحد المسموح ({limit} حرفًا).")
    return text


class LongTermMemory:
    """SQLite-backed local memory. Content stays on this PC until explicitly sent to the model."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                record_key TEXT UNIQUE,
                category TEXT NOT NULL DEFAULT 'note',
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                tags TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_memories_updated ON memories(updated_at DESC)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category)")
            con.execute("""CREATE TABLE IF NOT EXISTS procedures (
                procedure_key TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                intent TEXT NOT NULL,
                triggers TEXT NOT NULL DEFAULT '',
                steps_json TEXT NOT NULL,
                verification TEXT NOT NULL DEFAULT '',
                fallback TEXT NOT NULL DEFAULT '',
                app_name TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'candidate',
                success_count INTEGER NOT NULL DEFAULT 0,
                failure_count INTEGER NOT NULL DEFAULT 0,
                last_outcome TEXT NOT NULL DEFAULT '',
                last_notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_procedures_updated ON procedures(updated_at DESC)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_procedures_app ON procedures(app_name)")

    @contextmanager
    def _connect(self):
        con = sqlite3.connect(self.db_path, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def save(self, *, title: str, content: str, category: str = "note", tags: str = "", source: str = "", record_key: str = "") -> dict:
        title = _clean(title, 300)
        content = _clean(content, 20000)
        category = _clean(category or "note", 60)
        tags = _clean(tags, 500)
        source = _clean(source, 1000)
        record_key = _clean(record_key, 500)
        if not title or not content:
            raise ValueError("يجب توفير عنوان ومحتوى للذاكرة.")
        # Avoid accidentally persisting obvious credential assignments. This is a guardrail,
        # not a general-purpose secret detector.
        if re.search(r"(?i)(password|passwd|api[_ -]?key|access[_ -]?token)\s*[:=]\s*\S+", content):
            raise ValueError("لم أحفظ النص لأنه يبدو أنه يحتوي على بيانات اعتماد أو مفتاح وصول.")
        now = _now()
        memory_id = str(uuid.uuid4())
        with self._connect() as con:
            if record_key:
                existing = con.execute("SELECT id,created_at FROM memories WHERE record_key=?", (record_key,)).fetchone()
                if existing:
                    memory_id = existing["id"]
                    con.execute("UPDATE memories SET category=?,title=?,content=?,tags=?,source=?,updated_at=? WHERE id=?",
                                (category, title, content, tags, source, now, memory_id))
                else:
                    con.execute("INSERT INTO memories VALUES (?,?,?,?,?,?,?,?,?)",
                                (memory_id, record_key, category, title, content, tags, source, now, now))
            else:
                con.execute("INSERT INTO memories VALUES (?,?,?,?,?,?,?,?,?)",
                            (memory_id, None, category, title, content, tags, source, now, now))
        return {"id": memory_id, "title": title, "category": category, "characters": len(content), "updated_at": now}

    def search(self, query: str, limit: int = 8) -> list[dict]:
        query = _clean(query, 500)
        limit = max(1, min(int(limit), 15))
        recent_query = not query or query.casefold() in {"recent", "latest", "الأخيرة", "الأحدث", "الحديثة", "كل الذاكرة"}
        with self._connect() as con:
            if recent_query:
                rows = con.execute("SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
                chosen = rows
            else:
                terms = [t for t in re.findall(r"[\w@.+-]+", query.casefold()) if len(t) > 1][:12]
                if not terms:
                    rows = con.execute("SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
                    chosen = rows
                else:
                    clauses = []
                    params = []
                    for term in terms:
                        clauses.append("(LOWER(title) LIKE ? OR LOWER(content) LIKE ? OR LOWER(tags) LIKE ? OR LOWER(source) LIKE ? OR LOWER(category) LIKE ?)")
                        pattern = f"%{term}%"
                        params.extend([pattern] * 5)
                    rows = con.execute("SELECT * FROM memories WHERE " + " OR ".join(clauses), params).fetchall()
                    scored = []
                    for row in rows:
                        title_text = row["title"].casefold()
                        haystack = " ".join((row["title"], row["content"], row["tags"], row["source"], row["category"])).casefold()
                        score = sum(haystack.count(term) * (3 if term in title_text else 1) for term in terms)
                        if score:
                            scored.append((score, row["updated_at"], row))
                    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
                    chosen = [x[2] for x in scored[:limit]]
        return [{"id": r["id"], "category": r["category"], "title": r["title"],
                 "content": r["content"][:6000], "tags": r["tags"], "source": r["source"],
                 "updated_at": r["updated_at"]} for r in chosen]


    def save_procedure(
        self, *, procedure_key: str, name: str, intent: str, steps: list,
        triggers: str = "", verification: str = "", fallback: str = "", app_name: str = "",
    ) -> dict:
        """Store a declarative procedure. Steps are data, never evaluated as code."""
        procedure_key = _clean(procedure_key, 200)
        name = _clean(name, 200)
        intent = _clean(intent, 1000)
        triggers = _clean(triggers, 1000)
        verification = _clean(verification, 2000)
        fallback = _clean(fallback, 2000)
        app_name = _clean(app_name, 200)
        if not procedure_key or not name or not intent:
            raise ValueError("يجب توفير مفتاح الإجراء واسمه والهدف منه.")
        if not isinstance(steps, list) or not 1 <= len(steps) <= 25:
            raise ValueError("يجب أن تكون الخطوات قائمة من 1 إلى 25 خطوة.")
        clean_steps = []
        for step in steps:
            if isinstance(step, dict):
                clean_step = {str(k)[:60]: _clean(v, 1000) for k, v in step.items() if isinstance(v, (str, int, float, bool))}
                if not clean_step:
                    raise ValueError("كل خطوة يجب أن تحتوي على وصف نصي أو قيمة بسيطة.")
                clean_steps.append(clean_step)
            elif isinstance(step, str) and step.strip():
                clean_steps.append(_clean(step, 1000))
            else:
                raise ValueError("صيغة خطوة غير صالحة.")
        steps_json = json.dumps(clean_steps, ensure_ascii=False, separators=(",", ":"))
        combined = " ".join((name, intent, triggers, verification, fallback, app_name, steps_json))
        if re.search(r"(?i)(password|passwd|api[_ -]?key|access[_ -]?token)\s*[:=]\s*\S+", combined):
            raise ValueError("لم أحفظ الإجراء لأنه يبدو أنه يحتوي على بيانات اعتماد أو مفتاح وصول.")
        if len(steps_json) > 12000:
            raise ValueError("حجم خطوات الإجراء يتجاوز الحد المسموح.")
        now = _now()
        with self._connect() as con:
            old = con.execute("SELECT steps_json,name,intent,triggers,verification,fallback,app_name,status,success_count,failure_count,created_at FROM procedures WHERE procedure_key=?", (procedure_key,)).fetchone()
            if old:
                changed = any(old[k] != v for k, v in {
                    "steps_json": steps_json, "name": name, "intent": intent, "triggers": triggers,
                    "verification": verification, "fallback": fallback, "app_name": app_name,
                }.items())
                status = "candidate" if changed else old["status"]
                con.execute("""UPDATE procedures SET name=?,intent=?,triggers=?,steps_json=?,verification=?,fallback=?,app_name=?,status=?,updated_at=? WHERE procedure_key=?""",
                    (name, intent, triggers, steps_json, verification, fallback, app_name, status, now, procedure_key))
            else:
                con.execute("""INSERT INTO procedures (procedure_key,name,intent,triggers,steps_json,verification,fallback,app_name,status,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?, 'candidate',?,?)""",
                    (procedure_key, name, intent, triggers, steps_json, verification, fallback, app_name, now, now))
        return {"procedure_key": procedure_key, "name": name, "status": "candidate" if not old else status, "steps": len(clean_steps)}

    def update_procedure(self, *, procedure_key: str, name: str | None = None, intent: str | None = None,
                        steps: list | None = None, triggers: str | None = None, verification: str | None = None,
                        fallback: str | None = None, app_name: str | None = None) -> dict:
        """Partially edit an existing procedure while preserving every omitted field.

        Any actual edit resets trust to candidate; execution history remains intact.
        """
        procedure_key = _clean(procedure_key, 200)
        with self._connect() as con:
            row = con.execute("SELECT * FROM procedures WHERE procedure_key=?", (procedure_key,)).fetchone()
        if not row:
            raise ValueError("الإجراء غير موجود؛ استخدم procedure_save لإنشاء إجراء جديد.")
        current_steps = json.loads(row["steps_json"])
        values = {
            "procedure_key": procedure_key,
            "name": row["name"] if name is None else name,
            "intent": row["intent"] if intent is None else intent,
            "steps": current_steps if steps is None else steps,
            "triggers": row["triggers"] if triggers is None else triggers,
            "verification": row["verification"] if verification is None else verification,
            "fallback": row["fallback"] if fallback is None else fallback,
            "app_name": row["app_name"] if app_name is None else app_name,
        }
        result = self.save_procedure(**values)
        result["updated_fields"] = [k for k, v in {"name": name, "intent": intent, "steps": steps, "triggers": triggers,
            "verification": verification, "fallback": fallback, "app_name": app_name}.items() if v is not None]
        result["message"] = "تم تعديل الحقول المحددة فقط، مع الاحتفاظ ببقية الإجراء وسجل نتائجه؛ ويحتاج التعديل إلى تحقق جديد."
        return result

    def search_procedures(self, query: str, limit: int = 5) -> list[dict]:
        query = _clean(query, 500)
        limit = max(1, min(int(limit), 10))
        terms = [t for t in re.findall(r"[\w@.+-]+", query.casefold()) if len(t) > 1][:10]
        with self._connect() as con:
            if not terms or query.casefold() in {"recent", "latest", "الأخيرة", "الأحدث", "كل الإجراءات"}:
                rows = con.execute("SELECT * FROM procedures ORDER BY (status='verified') DESC, updated_at DESC LIMIT ?", (limit,)).fetchall()
                scored = [(1, row) for row in rows]
            else:
                clauses, params = [], []
                for term in terms:
                    clauses.append("(LOWER(name) LIKE ? OR LOWER(intent) LIKE ? OR LOWER(triggers) LIKE ? OR LOWER(app_name) LIKE ? OR LOWER(steps_json) LIKE ?)")
                    params.extend([f"%{term}%"] * 5)
                rows = con.execute("SELECT * FROM procedures WHERE " + " OR ".join(clauses) + " ORDER BY updated_at DESC LIMIT 1000", params).fetchall()
                scored = []
                for row in rows:
                    haystack = " ".join((row["name"], row["intent"], row["triggers"], row["app_name"], row["steps_json"])).casefold()
                    score = sum(haystack.count(term) * (3 if term in row["name"].casefold() else 1) for term in terms)
                    if score:
                        scored.append((score + (2 if row["status"] == "verified" else 0), row))
                scored.sort(key=lambda item: (item[0], item[1]["updated_at"]), reverse=True)
                scored = scored[:limit]
        results = []
        for score, row in scored:
            results.append({"procedure_key": row["procedure_key"], "name": row["name"], "intent": row["intent"],
                "triggers": row["triggers"], "steps": json.loads(row["steps_json"]), "verification": row["verification"],
                "fallback": row["fallback"], "app_name": row["app_name"], "status": row["status"],
                "success_count": row["success_count"], "failure_count": row["failure_count"], "score": score,
                "updated_at": row["updated_at"]})
        return results

    def record_procedure_result(self, *, procedure_key: str, outcome: str, verified: bool = False, notes: str = "") -> dict:
        procedure_key = _clean(procedure_key, 200)
        outcome = _clean(outcome, 30).casefold()
        notes = _clean(notes, 2000)
        if outcome not in {"success", "failure", "partial"}:
            raise ValueError("النتيجة يجب أن تكون success أو failure أو partial.")
        now = _now()
        with self._connect() as con:
            row = con.execute("SELECT procedure_key,status,success_count,failure_count FROM procedures WHERE procedure_key=?", (procedure_key,)).fetchone()
            if not row:
                raise ValueError("الإجراء غير موجود في الذاكرة.")
            successes = row["success_count"] + (1 if outcome == "success" and verified else 0)
            failures = row["failure_count"] + (1 if outcome == "failure" else 0)
            status = "verified" if outcome == "success" and verified else ("candidate" if outcome in {"failure", "partial"} else row["status"])
            con.execute("UPDATE procedures SET status=?,success_count=?,failure_count=?,last_outcome=?,last_notes=?,updated_at=? WHERE procedure_key=?",
                (status, successes, failures, outcome + ("_verified" if outcome == "success" and verified else ""), notes, now, procedure_key))
        return {"procedure_key": procedure_key, "status": status, "success_count": successes, "failure_count": failures, "last_outcome": outcome}

    def procedure_exists(self, procedure_key: str) -> bool:
        """Return whether a stable procedure key already exists."""
        procedure_key = _clean(procedure_key, 200)
        with self._connect() as con:
            return con.execute("SELECT 1 FROM procedures WHERE procedure_key=?", (procedure_key,)).fetchone() is not None

    def procedure_count(self) -> int:
        with self._connect() as con:
            return int(con.execute("SELECT COUNT(*) FROM procedures").fetchone()[0])

    def count(self) -> int:
        with self._connect() as con:
            return int(con.execute("SELECT COUNT(*) FROM memories").fetchone()[0])
