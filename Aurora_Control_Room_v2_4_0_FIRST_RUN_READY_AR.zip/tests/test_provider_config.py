import unittest

from provider_config import has_provider_key, is_real_api_key, selected_provider


class ProviderConfigTests(unittest.TestCase):
    def test_rejects_arabic_example_key(self):
        self.assertFalse(is_real_api_key("ضع_مفتاح_Google_هنا"))

    def test_rejects_common_english_placeholders(self):
        for value in ("YOUR_API_KEY", "replace-me", "changeme", "<your-key-here>", ""):
            with self.subTest(value=value):
                self.assertFalse(is_real_api_key(value))

    def test_accepts_non_placeholder_value_without_displaying_it(self):
        self.assertTrue(is_real_api_key("GeminiConfiguredMockKeyForUnitTests12345"))

    def test_explicit_provider_choice_is_preserved(self):
        self.assertEqual(selected_provider({"AI_PROVIDER": "gemini", "GEMINI_API_KEY": ""}), "gemini")
        self.assertEqual(selected_provider({"AI_PROVIDER": "openrouter", "GEMINI_API_KEY": "real-looking-key"}), "openrouter")

    def test_automatic_selection_ignores_placeholder_gemini_key(self):
        self.assertEqual(selected_provider({"GEMINI_API_KEY": "ضع_مفتاح_Google_هنا"}), "openrouter")
        self.assertEqual(selected_provider({"GEMINI_API_KEY": "GeminiConfiguredMockKeyForUnitTests12345"}), "gemini")

    def test_key_readiness_is_provider_specific(self):
        env = {"GEMINI_API_KEY": "gemini-example-key", "OPENROUTER_API_KEY": ""}
        self.assertTrue(has_provider_key("gemini", env))
        self.assertFalse(has_provider_key("openrouter", env))
        self.assertFalse(has_provider_key("unknown", env))


if __name__ == "__main__":
    unittest.main()
