import tempfile
import unittest
from pathlib import Path

from builtin_knowledge import seed_builtin_knowledge
from long_term_memory import LongTermMemory

class BuiltinKnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.memory = LongTermMemory(Path(self.temp.name) / "memory.sqlite3")
    def tearDown(self):
        self.temp.cleanup()
    def test_seeds_useful_procedures_and_workflow_memories(self):
        result = seed_builtin_knowledge(self.memory)
        self.assertGreaterEqual(result["procedures_added"], 10)
        self.assertGreaterEqual(result["memories_added"], 6)
        self.assertGreaterEqual(self.memory.procedure_count(), 10)
        self.assertTrue(any(x["procedure_key"] == "mt5.strategy_tester_run" for x in self.memory.search_procedures("MT5 Strategy Tester اختبار المستشار", limit=10)))
        self.assertTrue(any(x["procedure_key"] == "mt5.metaeditor_compile_f7" for x in self.memory.search_procedures("F7 ترجمة خبير MQL5", limit=10)))
        self.assertTrue(all(x["status"] == "candidate" for x in self.memory.search_procedures("all procedures", limit=10)))
    def test_seeding_is_idempotent_and_does_not_overwrite_customized_procedure(self):
        first = seed_builtin_knowledge(self.memory)
        self.memory.save_procedure(procedure_key="mt5.strategy_tester_run", name="نسخة المستخدم", intent="إجراء مخصص", steps=["خطوة المستخدم"])
        second = seed_builtin_knowledge(self.memory)
        self.assertEqual(second["procedures_added"], 0)
        found = self.memory.search_procedures("نسخة المستخدم", limit=3)
        self.assertTrue(any(x["procedure_key"] == "mt5.strategy_tester_run" and x["name"] == "نسخة المستخدم" for x in found))
        self.assertEqual(second["memories_added"], 0)

if __name__ == "__main__":
    unittest.main(verbosity=2)
