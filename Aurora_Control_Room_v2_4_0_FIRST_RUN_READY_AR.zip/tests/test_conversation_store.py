import tempfile
import unittest
from pathlib import Path

from assistant_core import conversation_from_row
from conversation_store import ConversationStore


class ConversationStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = ConversationStore(Path(self.temp.name) / "chat.sqlite3")

    def tearDown(self):
        self.temp.cleanup()

    def test_create_save_reload_and_delete(self):
        cid = self.store.create("تجربة")
        conv = conversation_from_row(self.store.get_row(cid))
        conv["messages"].append({"role": "user", "content": "رسالة"})
        conv["log"].append({"tool": "browser_read_page"})
        self.store.save(conv)
        loaded = conversation_from_row(self.store.get_row(cid))
        self.assertEqual(loaded["title"], "تجربة")
        self.assertEqual(loaded["messages"][0]["content"], "رسالة")
        self.assertEqual(len(self.store.list()), 1)
        self.store.delete(cid)
        self.assertEqual(self.store.count(), 0)

    def test_save_unknown_conversation_fails_closed(self):
        with self.assertRaises(KeyError):
            self.store.save({"id": "missing", "title": "x", "messages": [], "log": [], "pending": []})

    def test_legacy_schema_migrates(self):
        old_db = Path(self.temp.name) / "legacy.sqlite3"
        import sqlite3
        con = sqlite3.connect(old_db)
        try:
            con.execute("CREATE TABLE conversations (id TEXT PRIMARY KEY, title TEXT NOT NULL, tool_log_json TEXT, created_at TEXT, updated_at TEXT)")
            con.execute("INSERT INTO conversations VALUES ('legacy','قديم','[{\"tool\":\"x\"}]','','')")
            con.commit()
        finally:
            con.close()
        store = ConversationStore(old_db)
        row = store.get_row("legacy")
        loaded = conversation_from_row(row)
        self.assertEqual(loaded["log"][0]["tool"], "x")


    def test_private_page_text_is_not_written_verbatim_to_sqlite(self):
        import json
        cid = self.store.create("private")
        conv = conversation_from_row(self.store.get_row(cid))
        conv["messages"] = [
            {"role": "assistant", "content": "", "tool_calls": [{"id": "read-1", "type": "function", "function": {"name": "browser_read_page", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "read-1", "content": json.dumps({"ok": True, "text": "a secret mail body"})},
        ]
        self.store.save(conv)
        loaded = conversation_from_row(self.store.get_row(cid))
        stored_text = json.dumps(loaded["messages"], ensure_ascii=False)
        self.assertNotIn("a secret mail body", stored_text)
        self.assertIn("مخفى من سجل المحادثة", stored_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
