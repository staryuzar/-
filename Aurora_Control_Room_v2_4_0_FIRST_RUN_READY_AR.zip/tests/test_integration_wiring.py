"""Release-gating tests for complete component wiring, not only individual functions."""
from __future__ import annotations

import ast
import re
import tempfile
import unittest
from pathlib import Path

from security_utils import tool_action_decision

ROOT = Path(__file__).resolve().parents[1]


def _local_import_graph(root: Path) -> tuple[set[str], dict[str, set[str]]]:
    modules = {path.stem: path for path in root.glob("*.py")}
    graph: dict[str, set[str]] = {name: set() for name in modules}
    for name, path in modules.items():
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    local_name = alias.name.split(".", 1)[0]
                    if local_name in modules:
                        graph[name].add(local_name)
            elif isinstance(node, ast.ImportFrom) and node.module:
                local_name = node.module.split(".", 1)[0]
                if local_name in modules:
                    graph[name].add(local_name)
    return set(modules), graph


def _schema_tool_names(root: Path) -> set[str]:
    tree = ast.parse((root / "app.py").read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "_tool":
            if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                names.add(node.args[0].value)
    return names


def _executor_handler_names(root: Path) -> set[str]:
    tree = ast.parse((root / "tool_executor.py").read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare) or len(node.ops) != 1 or not isinstance(node.ops[0], ast.Eq):
            continue
        if isinstance(node.left, ast.Name) and node.left.id == "name":
            for comparator in node.comparators:
                if isinstance(comparator, ast.Constant) and isinstance(comparator.value, str):
                    names.add(comparator.value)
    return names


class ComponentWiringTests(unittest.TestCase):
    def test_every_model_tool_has_exactly_a_matching_executor_branch(self):
        declared = _schema_tool_names(ROOT)
        handled = _executor_handler_names(ROOT)
        self.assertGreaterEqual(len(declared), 25)
        self.assertEqual(declared, handled, f"unhandled={sorted(declared-handled)}; not_declared={sorted(handled-declared)}")

    def test_every_project_module_is_reachable_from_a_real_entrypoint(self):
        modules, graph = _local_import_graph(ROOT)
        entrypoints = {"app", "setup_data", "diagnose", "move_data_to_e"}
        reachable: set[str] = set()
        stack = list(entrypoints)
        while stack:
            item = stack.pop()
            if item not in modules or item in reachable:
                continue
            reachable.add(item)
            stack.extend(graph[item] - reachable)
        self.assertEqual(modules, reachable, f"unreachable Python modules: {sorted(modules-reachable)}")

    def test_launcher_marker_matches_release_and_dependencies_are_in_project_venv(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        app = (ROOT / "app.py").read_text(encoding="utf-8")
        launcher = (ROOT / "START_WINDOWS.bat").read_text(encoding="utf-8")
        self.assertIn("2.4.0", version)
        self.assertIn('APP_VERSION = "2.4.0"', app)
        self.assertIn(".aurora-deps-v240.ok", launcher)
        self.assertNotIn(".aurora-deps-v239.ok", launcher)
        self.assertIn('".venv\\Scripts\\python.exe" -m pip install -r requirements.txt', launcher)
        self.assertIn('".venv\\Scripts\\python.exe" -m streamlit run app.py', launcher)
        self.assertTrue((ROOT / ".env.example").is_file())

    def test_windows_batch_launchers_point_to_real_project_components(self):
        required_launchers = {
            "START_WINDOWS.bat": ("setup_data.py", "requirements.txt", "app.py", ".env.example"),
            "RUN_TESTS_WINDOWS.bat": ("tests",),
            "DIAGNOSE_WINDOWS.bat": ("diagnose.py",),
            "MOVE_DATA_TO_E.bat": ("move_data_to_e.py",),
        }
        for launcher_name, targets in required_launchers.items():
            launcher_path = ROOT / launcher_name
            self.assertTrue(launcher_path.is_file(), f"missing launcher: {launcher_name}")
            content = launcher_path.read_text(encoding="utf-8-sig")
            for target in targets:
                with self.subTest(launcher=launcher_name, target=target):
                    self.assertTrue((ROOT / target).exists(), f"missing target file/directory: {target}")
                    self.assertIn(target, content, f"launcher {launcher_name} does not reference {target}")

    def test_every_engineering_report_shown_in_ui_exists_in_the_release(self):
        tree = ast.parse((ROOT / "app.py").read_text(encoding="utf-8"))
        report_paths: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "department_reports" for t in node.targets):
                if isinstance(node.value, ast.Dict):
                    for value in node.value.values:
                        if isinstance(value, ast.Constant) and isinstance(value.value, str):
                            report_paths.add(value.value)
        self.assertGreaterEqual(len(report_paths), 6)
        missing = sorted(name for name in report_paths if not (ROOT / name).is_file())
        self.assertEqual(missing, [], f"reports linked from UI but missing from package: {missing}")
        self.assertFalse(any("V239" in name or "v239" in name for name in report_paths), report_paths)

    def test_version_is_consistent_across_all_user_facing_runtime_files(self):
        expected = "2.4.0"
        self.assertIn(expected, (ROOT / "VERSION.txt").read_text(encoding="utf-8"))
        self.assertIn(expected, (ROOT / "VERSION_AR.txt").read_text(encoding="utf-8"))
        self.assertIn(expected, (ROOT / "diagnose.py").read_text(encoding="utf-8"))
        self.assertIn(f"Aurora-Control-Room/{expected}", (ROOT / "gemini_native_client.py").read_text(encoding="utf-8"))
        self.assertIn(f"Aurora Control Room v{expected}", (ROOT / "START_WINDOWS.bat").read_text(encoding="utf-8"))

    def test_pending_actions_keep_their_original_user_intent_for_rechecks(self):
        app = (ROOT / "app.py").read_text(encoding="utf-8")
        self.assertIn('"user_request": user_text', app)
        self.assertIn('originating_request = str(item.get("user_request", "") or "").strip()', app)
        self.assertIn('if not originating_request:', app)
        self.assertIn('user_request=originating_request', app)
        self.assertIn('policy_args["_policy_current_url"] = current_url_for_policy', app)
        self.assertIn('tool_action_decision(\n                    tool_name, policy_args', app)

    def test_first_run_setup_initializes_database_and_starter_knowledge_before_api_key(self):
        setup = (ROOT / "setup_data.py").read_text(encoding="utf-8")
        launcher = (ROOT / "START_WINDOWS.bat").read_text(encoding="utf-8")
        readme = (ROOT / "README_AR.md").read_text(encoding="utf-8")
        self.assertIn("bootstrap_data_directory(selected)", setup)
        self.assertIn("initialize_unified_database(selected)", setup)
        self.assertIn("initialize_operations_log(db_path)", setup)
        self.assertIn("seed_builtin_knowledge(LongTermMemory(db_path))", setup)
        self.assertIn('".venv\\Scripts\\python.exe" setup_data.py', launcher)
        self.assertLess(launcher.index('".venv\\Scripts\\python.exe" setup_data.py'), launcher.index('if "%NEW_ENV%"=="1"'))
        self.assertIn("لا يلزم أن يكون `E:\\AuroraData\\LocalAssistant` موجودًا مسبقًا", readme)
        self.assertIn("MOVE_DATA_TO_E.bat` ليس مطلوبًا في التثبيت الجديد", readme)

    def test_major_subsystems_are_wired_into_the_runtime(self):
        app = (ROOT / "app.py").read_text(encoding="utf-8")
        executor = (ROOT / "tool_executor.py").read_text(encoding="utf-8")
        gemini = (ROOT / "gemini_native_client.py").read_text(encoding="utf-8")
        openrouter_images = (ROOT / "image_support.py").read_text(encoding="utf-8")
        db = (ROOT / "database_manager.py").read_text(encoding="utf-8")
        self.assertIn("build_local_memory_context(executor.memory, user_text)", app)
        self.assertIn("seed_builtin_knowledge(executor.memory)", app)
        self.assertIn("messages_with_openai_images(", app)
        self.assertIn("attachments_dir=ATTACHMENTS_DIR", app)
        self.assertIn("contents", gemini.lower())
        self.assertIn("inlineData", gemini)
        self.assertIn("image_url", openrouter_images)
        self.assertIn("ConversationStore(target)", db)
        self.assertIn("LongTermMemory(target)", db)
        self.assertIn('self.memory = LongTermMemory(memory_path', executor)
        self.assertIn('record_operation_event(DB_PATH', app)
        self.assertIn('_render_operations_center()', app)


class LowFrictionPolicyTests(unittest.TestCase):
    def test_explicit_report_send_does_not_request_a_second_approval(self):
        requests = [
            "أرسل لي تقرير الاختبار على واتساب",
            "أرسل نتائج مختبر الاستراتيجية إلى تليجرام",
            "رد على رسالة أحمد بهذه الإجابة",
            "Send me the test report on WhatsApp",
            "Reply to Ahmad with this answer",
        ]
        for request in requests:
            with self.subTest(request=request):
                decision, _ = tool_action_decision("browser_click_text", {"text": "Send"}, request, mode="routine_auto")
                self.assertEqual(decision, "allow")

    def test_install_action_is_automatic_only_when_the_user_requested_it(self):
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Install"}, "ثبت هذا البرنامج", mode="routine_auto")[0], "allow")
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Install"}, "ثبت هذا البرنامج", mode="balanced")[0], "review")
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Install"}, "راجع الصفحة فقط", mode="routine_auto")[0], "review")
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Install"}, "لا تثبت هذا البرنامج", mode="routine_auto")[0], "deny")

    def test_project_launcher_runs_without_prompt_after_explicit_setup_request(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for name in ("requirements.txt", "app.py", "START_WINDOWS.bat"):
                (root / name).write_text("test", encoding="utf-8")
            decision, reason = tool_action_decision(
                "run_shell_command", {"command": "START_WINDOWS.bat", "cwd": str(root)},
                "شغّل Aurora", mode="routine_auto"
            )
            self.assertEqual(decision, "allow", reason)

    def test_only_project_venv_requirements_install_is_auto_allowed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "requirements.txt").write_text("streamlit", encoding="utf-8")
            (root / "app.py").write_text("", encoding="utf-8")
            python = root / ".venv" / "Scripts" / "python.exe"
            python.parent.mkdir(parents=True)
            python.write_text("fake executable for policy test", encoding="utf-8")
            args = {
                "command": [r".venv\Scripts\python.exe", "-m", "pip", "install", "-r", "requirements.txt"],
                "cwd": str(root),
            }
            self.assertEqual(tool_action_decision("run_local_command", args, "ثبت متطلبات المشروع", mode="routine_auto")[0], "allow")
            args_bad = dict(args, command=[r".venv\Scripts\python.exe", "-m", "pip", "install", "some-random-package"])
            self.assertEqual(tool_action_decision("run_local_command", args_bad, "ثبت متطلبات المشروع", mode="routine_auto")[0], "review")

    def test_high_impact_system_and_subscription_actions_keep_review(self):
        for mode in ("routine_auto", "balanced", "cautious"):
            with self.subTest(mode=mode):
                self.assertEqual(tool_action_decision("run_shell_command", {"command": "powershell.exe -EncodedCommand QUJDREVGRw=="}, "اختبر الحزمة", mode=mode)[0], "review")
                self.assertEqual(tool_action_decision("browser_click_text", {"text": "Start free trial"}, "ابدأ التجربة المجانية", mode=mode)[0], "review")
        self.assertEqual(tool_action_decision("delete_workspace_file", {"path": "notes.txt"}, "احذف notes.txt", mode="routine_auto")[0], "allow")
        self.assertEqual(tool_action_decision("delete_workspace_file", {"path": "notes.txt"}, "احذف notes.txt", mode="balanced")[0], "review")

    def test_generic_yes_confirm_or_submit_cannot_bypass_financial_checkpoint(self):
        for label in ("Yes", "Confirm", "Submit", "Authorize"):
            with self.subTest(label=label):
                decision, _ = tool_action_decision("browser_click_text", {"text": label}, "اشتر المنتج الذي اخترته", mode="routine_auto")
                self.assertEqual(decision, "review")
        # An explicit message send must stay automatic even if the body mentions financial topics.
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Send"}, "أرسل لي تقرير التحويل المالي عبر واتساب", mode="routine_auto")[0], "allow")

    def test_financial_commitments_keep_one_checkpoint_but_routine_actions_do_not(self):
        for label, request in (
            ("Buy now", "اشتر المنتج الذي اخترته"),
            ("Pay now", "ادفع قيمة الطلب"),
            ("Transfer", "حوّل المبلغ إلى الحساب الذي حددته"),
        ):
            with self.subTest(label=label):
                self.assertEqual(tool_action_decision("browser_click_text", {"text": label}, request, mode="routine_auto")[0], "review")
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Send"}, "أرسل لي التقرير عبر واتساب", mode="routine_auto")[0], "allow")
        self.assertEqual(tool_action_decision("browser_click_text", {"text": "Download"}, "نزّل التقرير", mode="routine_auto")[0], "allow")

    def test_incidental_delete_word_in_filename_does_not_block_test_command(self):
        decision, reason = tool_action_decision(
            "run_shell_command",
            {"command": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"], "path": "delete_notes.txt"},
            "اختبر الحزمة", mode="routine_auto"
        )
        self.assertEqual(decision, "allow", reason)
        decision, _ = tool_action_decision(
            "browser_click_text", {"text": "Delete account"}, "راجع الصفحة فقط", mode="routine_auto"
        )
        self.assertEqual(decision, "review")
        self.assertEqual(tool_action_decision("delete_workspace_file", {"path": "output.txt"}, "احذف الملف output.txt", mode="routine_auto")[0], "allow")
        self.assertEqual(tool_action_decision("delete_workspace_file", {"path": "aurora.sqlite3"}, "احذف الملف aurora.sqlite3", mode="routine_auto")[0], "review")

    def test_explicit_no_send_overrides_send_intent_and_page_control(self):
        for request in ("أرسل التقرير لكن لا ترسله فعليًا", "اقرأ البريد ولا ترسل شيئًا"):
            with self.subTest(request=request):
                self.assertEqual(tool_action_decision("browser_click_text", {"text": "Send"}, request, mode="routine_auto")[0], "deny")


if __name__ == "__main__":
    unittest.main(verbosity=2)
