import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from rate_limit import cooldown_until_from_exception, load_cooldown, rate_limit_message, save_cooldown


class RateLimitTests(unittest.TestCase):
    def make_exc(self, headers=None, body=None, text=""):
        response = SimpleNamespace(headers=headers or {}, text=text)
        return SimpleNamespace(response=response, body=body)

    def test_openrouter_millisecond_reset_header_is_converted(self):
        exc = self.make_exc({"X-RateLimit-Reset": "1792368000000"})
        self.assertEqual(cooldown_until_from_exception(exc, now=1792367000), 1792368000)

    def test_retry_after_seconds_is_respected(self):
        exc = self.make_exc({"Retry-After": "45"})
        self.assertEqual(cooldown_until_from_exception(exc, now=1000), 1045)

    def test_missing_headers_uses_bounded_fallback(self):
        exc = self.make_exc()
        self.assertEqual(cooldown_until_from_exception(exc, now=1000, fallback_seconds=60), 1060)

    def test_daily_free_limit_message_is_actionable_and_does_not_echo_raw_body(self):
        exc = self.make_exc(
            {"X-RateLimit-Reset": "1792368000000"},
            body={"error": {"message": "Rate limit exceeded: free-models-per-day SECRET_TOKEN", "metadata": {"limit_source": "openrouter_free_tier_daily"}}},
        )
        msg = rate_limit_message(exc, now=1792367000)
        self.assertIn("الحصة اليومية", msg)
        self.assertIn("وقت إعادة الضبط المتوقع", msg)
        self.assertNotIn("SECRET_TOKEN", msg)
        self.assertIn("أوقفت إعادة المحاولة", msg)

    def test_cooldown_persists_and_expires(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "cooldown.json"
            save_cooldown(path, 2000, "انتظر")
            self.assertEqual(load_cooldown(path, now=1500), {"until": 2000.0, "message": "انتظر"})
            self.assertIsNone(load_cooldown(path, now=2000))

    def test_malformed_cooldown_is_ignored(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "cooldown.json"
            path.write_text("{bad", encoding="utf-8")
            self.assertIsNone(load_cooldown(path, now=1000))


if __name__ == "__main__":
    unittest.main(verbosity=2)
