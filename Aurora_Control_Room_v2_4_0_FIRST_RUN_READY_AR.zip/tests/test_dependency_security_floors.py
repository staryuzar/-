"""Guard known security-sensitive minimum dependency versions."""
from pathlib import Path
import re
import unittest


class DependencySecurityFloorTests(unittest.TestCase):
    def test_known_vulnerable_dependency_floors_are_not_regressed(self):
        requirements = (Path(__file__).resolve().parents[1] / "requirements.txt").read_text(encoding="utf-8")
        streamlit = re.search(r"(?m)^streamlit\s*>=\s*([0-9.]+)\s*,\s*<\s*2", requirements)
        dotenv = re.search(r"(?m)^python-dotenv\s*>=\s*([0-9.]+)\s*,\s*<\s*2", requirements)
        self.assertIsNotNone(streamlit, "Streamlit needs an explicit security-aware version floor")
        self.assertIsNotNone(dotenv, "python-dotenv needs an explicit security-aware version floor")
        self.assertGreaterEqual(tuple(map(int, streamlit.group(1).split("."))), (1, 54, 0))
        self.assertGreaterEqual(tuple(map(int, dotenv.group(1).split("."))), (1, 2, 2))


    def test_startup_does_not_upgrade_or_reinstall_dependencies_on_every_launch(self):
        root = Path(__file__).resolve().parents[1]
        startup = (root / "START_WINDOWS.bat").read_text(encoding="utf-8")
        marker_gate = 'if exist ".venv\\.aurora-deps-v240.ok" goto run_assistant'
        self.assertIn(marker_gate, startup)
        self.assertLess(startup.index(marker_gate), startup.index("-m pip install --upgrade pip"))
        self.assertIn('> ".venv\\.aurora-deps-v240.ok" echo dependencies-installed-for-v2.4.0', startup)
        self.assertIn(":run_assistant", startup)
        self.assertIn("delete .venv\\.aurora-deps-v240.ok", startup)

    def test_windows_startup_keeps_pip_cache_and_temp_files_on_bundle_drive(self):
        root = Path(__file__).resolve().parents[1]
        startup = (root / "START_WINDOWS.bat").read_text(encoding="utf-8")
        self.assertIn('set "PIP_CACHE_DIR=%~dp0.pip-cache"', startup)
        self.assertIn('set "TEMP=%~dp0.tmp"', startup)
        self.assertIn('set "TMP=%~dp0.tmp"', startup)
        self.assertIn('set "SE_CACHE_PATH=%~dp0.selenium-cache"', startup)
        self.assertIn('if not exist ".selenium-cache" mkdir ".selenium-cache"', startup)


if __name__ == "__main__":
    unittest.main()
