"""Unit tests for the Operations Center diagnostics and privacy boundaries."""
import json
import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from operations_center import (
    collect_health_checks,
    initialize_operations_log,
    make_diagnostic_report,
    recent_operation_events,
    recent_runtime_tasks,
    record_operation_event,
    record_runtime_task_state,
    run_public_network_probe,
)


class OperationsCenterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.data = self.root / "data"
        self.project = self.root / "project"
        self.workspace = self.data / "Workspace"
        self.attachments = self.data / "Attachments"
        self.data.mkdir()
        self.project.mkdir()
        self.workspace.mkdir()
        self.attachments.mkdir()
        for name in ("START_WINDOWS.bat", "RUN_TESTS_WINDOWS.bat", "requirements.txt", "app.py",
                     "operations_center.py", "database_manager.py", "assistant_core.py", "tool_executor.py", "image_support.py"):
            (self.project / name).write_text("test", encoding="utf-8")
        self.db = self.data / "aurora.sqlite3"
        with closing(sqlite3.connect(self.db)) as con:
            con.executescript("""
                CREATE TABLE conversations(id TEXT PRIMARY KEY, title TEXT);
                CREATE TABLE memories(id INTEGER PRIMARY KEY, title TEXT);
                CREATE TABLE procedures(id INTEGER PRIMARY KEY, procedure_key TEXT);
                CREATE TABLE aurora_migration_ledger(source_key TEXT PRIMARY KEY);
            """)
        initialize_operations_log(self.db)

    def tearDown(self):
        self.temp.cleanup()

    def _checks(self, **overrides):
        args = dict(
            project_dir=self.project,
            data_dir=self.data,
            db_path=self.db,
            workspace_dir=self.workspace,
            attachments_dir=self.attachments,
            provider="openrouter",
            provider_label="OpenRouter",
            model_name="openrouter/free",
            provider_key_configured=True,
            provider_probe={},
            active_browser=False,
            active_browser_url="",
            chrome_path="",
            memory_count=0,
            procedure_count=0,
            tool_names=["memory_search", "browser_open_url"],
            builtin_knowledge_status={"procedures_added": 10},
            database_bootstrap_status={"integrity": "ok", "active_database_count": 1, "migrated": [], "archived": [], "warnings": []},
            task_status={"state": "idle", "label": "لا توجد مهمة"},
            network_probe={},
        )
        args.update(overrides)
        return collect_health_checks(**args)

    def test_health_check_reports_unified_sqlite_and_required_tables(self):
        rows = {row["id"]: row for row in self._checks()}
        self.assertEqual(rows["sqlite_database"]["status"], "ok")
        self.assertIn("quick_check=ok", rows["sqlite_database"]["detail"].lower())
        self.assertEqual(rows["package_integrity"]["status"], "ok")
        self.assertEqual(rows["tool_registry"]["status"], "ok")

    def test_action_policy_health_check_exercises_allow_review_and_deny(self):
        rows = {row["id"]: row for row in self._checks()}
        self.assertEqual(rows["action_policy"]["status"], "ok")
        self.assertIn("7/7", rows["action_policy"]["detail"])

    def test_database_bootstrap_warning_is_visible(self):
        rows = {r["id"]: r for r in self._checks(database_bootstrap_status={
            "integrity": "ok", "active_database_count": 1, "migrated": [], "archived": [],
            "warnings": ["بقيت نسخة قديمة لأن عملية الأرشفة تعذرت"],
        })}
        self.assertEqual(rows["database_bootstrap"]["status"], "warning")
        self.assertIn("تحذيرات", rows["database_bootstrap"]["detail"])

    def test_missing_database_is_a_clear_error(self):
        rows = self._checks(db_path=self.data / "missing.sqlite3")
        item = next(r for r in rows if r["id"] == "sqlite_database")
        self.assertEqual(item["status"], "error")
        self.assertIn("غير موجودة", item["detail"])

    def test_duplicate_or_missing_tools_is_detected(self):
        rows = {r["id"]: r for r in self._checks(tool_names=["memory_search", "memory_search"])}
        self.assertEqual(rows["tool_registry"]["status"], "error")

    def test_unconfigured_provider_and_untested_network_are_not_shown_as_success(self):
        rows = {r["id"]: r for r in self._checks(provider_key_configured=False)}
        self.assertEqual(rows["provider_key"]["status"], "error")
        self.assertEqual(rows["provider_connection"]["status"], "unknown")
        self.assertEqual(rows["internet"]["status"], "unknown")

    def test_failed_provider_probe_and_waiting_approval_are_diagnosed(self):
        rows = {r["id"]: r for r in self._checks(
            provider_probe={"ok": False, "detail": "HTTP 401", "time": "test"},
            task_status={"state": "waiting_approval", "label": "بانتظار المستخدم"},
        )}
        self.assertEqual(rows["provider_connection"]["status"], "error")
        self.assertEqual(rows["task_state"]["status"], "warning")

    def test_legacy_active_database_files_are_flagged(self):
        (self.data / "chat_history.sqlite3").write_bytes(b"legacy")
        rows = {r["id"]: r for r in self._checks()}
        self.assertEqual(rows["legacy_database_files"]["status"], "warning")

    def test_event_log_stays_inside_the_single_database_and_redacts_configured_key(self):
        secret_name = "OPENROUTER_API_KEY"
        previous = os.environ.get(secret_name)
        os.environ[secret_name] = "or-secret-test-123"
        try:
            self.assertTrue(record_operation_event(self.db, level="error", area="provider", event="failed", detail="bad key or-secret-test-123"))
            events = recent_operation_events(self.db, limit=5)
            self.assertTrue(events)
            self.assertNotIn("or-secret-test-123", json.dumps(events))
            with closing(sqlite3.connect(self.db)) as con:
                tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertIn("operation_events", tables)
            self.assertIn("operation_task_runs", tables)
            self.assertEqual(len(list(self.data.glob("*.sqlite3"))), 1)
        finally:
            if previous is None:
                os.environ.pop(secret_name, None)
            else:
                os.environ[secret_name] = previous

    def test_diagnostic_report_redacts_keys_and_uses_whitelisted_event_fields(self):
        previous = os.environ.get("GEMINI_API_KEY")
        os.environ["GEMINI_API_KEY"] = "gem-secret-456"
        try:
            checks = [{"id": "provider", "component": "key", "status": "error", "detail": "gem-secret-456", "fix": "fix", "category": "AI", "evidence": "hidden"}]
            events = [{"created_at": "now", "level": "error", "area": "probe", "event": "bad", "detail": "gem-secret-456", "unexpected": "secret"}]
            report = make_diagnostic_report(checks, version="2.4.0", project_dir=self.project, data_dir=self.data, recent_events=events)
            decoded = report.decode("utf-8")
            self.assertNotIn("gem-secret-456", decoded)
            self.assertNotIn("unexpected", decoded)
            self.assertIn("privacy_note", decoded)
        finally:
            if previous is None:
                os.environ.pop("GEMINI_API_KEY", None)
            else:
                os.environ["GEMINI_API_KEY"] = previous

    def test_diagnostic_report_masks_machine_paths_and_common_token_patterns(self):
        machine_path = r"C:\Users\alice\Documents\Aurora\app.py"
        token = "sk-1234567890abcdefghijklmnopqrstuv"
        checks = [{"id": "python", "component": "Python", "status": "warning",
                   "detail": f"launcher at {machine_path}", "fix": f"check token={token}",
                   "category": "runtime", "evidence": machine_path}]
        decoded = make_diagnostic_report(checks, version="2.4.0", project_dir=machine_path,
                                         data_dir=r"C:\Users\alice\AppData\Local\Aurora",
                                         recent_events=[{"event": "probe", "detail": f"Bearer {token}"}]).decode("utf-8")
        self.assertNotIn("alice", decoded)
        self.assertNotIn(machine_path, decoded)
        self.assertNotIn(token, decoded)
        self.assertIn("مسار محلي محجوب", decoded)

    def test_task_state_is_persisted_for_other_sessions_in_the_same_database(self):
        state = {
            "task_id": "task-test-1", "conversation_id": "conv-test", "state": "running",
            "label": "تنفيذ الأداة browser_open_url", "started_at": "2026-10-19T04:00:00+03:00",
            "updated_at": "2026-10-19T04:00:02+03:00", "process_id": os.getpid(),
            "round": 2, "current_tool": "browser_open_url", "tool_count": 1,
        }
        self.assertTrue(record_runtime_task_state(self.db, state))
        tasks = recent_runtime_tasks(self.db, limit=5)
        self.assertTrue(tasks)
        self.assertEqual(tasks[0]["task_id"], "task-test-1")
        self.assertEqual(tasks[0]["state"], "running")
        self.assertEqual(tasks[0]["current_tool"], "browser_open_url")

    def test_task_with_dead_process_is_flagged_as_interrupted(self):
        state = {
            "task_id": "task-dead-1", "conversation_id": "conv-test", "state": "running",
            "label": "مهمة تجريبية", "started_at": "2026-10-19T04:00:00+03:00",
            "updated_at": "2026-10-19T04:00:02+03:00", "process_id": 2_000_000_000,
            "round": 1, "current_tool": "", "tool_count": 0,
        }
        self.assertTrue(record_runtime_task_state(self.db, state))
        tasks = recent_runtime_tasks(self.db, limit=5)
        row = next(task for task in tasks if task["task_id"] == "task-dead-1")
        self.assertEqual(row["state"], "interrupted")
        self.assertIn("توقفت", row["label"])

    def test_task_process_permission_error_is_not_misreported_as_dead(self):
        state = {
            "task_id": "task-permission-1", "conversation_id": "conv-test", "state": "running",
            "label": "مهمة ما زالت تعمل", "started_at": "2026-10-19T04:00:00+03:00",
            "updated_at": "2026-10-19T04:00:02+03:00", "process_id": os.getpid() + 50000,
            "round": 1, "current_tool": "browser_open_url", "tool_count": 1,
        }
        self.assertTrue(record_runtime_task_state(self.db, state))
        with patch("operations_center.os.kill", side_effect=PermissionError()):
            tasks = recent_runtime_tasks(self.db, limit=5)
        row = next(task for task in tasks if task["task_id"] == "task-permission-1")
        self.assertEqual(row["state"], "running")

    def test_network_probe_uses_two_explicit_public_endpoints_without_credentials(self):
        class FakeResponse:
            def __init__(self, status): self.status = status
            def __enter__(self): return self
            def __exit__(self, *args): return False
        with patch("operations_center.urllib.request.urlopen", side_effect=[FakeResponse(204), FakeResponse(200)]) as opener:
            result = run_public_network_probe("openrouter")
        self.assertEqual(result["ok_count"], 2)
        self.assertEqual(result["total_count"], 2)
        self.assertEqual(opener.call_count, 2)
        self.assertTrue(all("Authorization" not in str(c.args) for c in opener.call_args_list))

    def test_network_probe_failure_is_not_misreported_as_success(self):
        with patch("operations_center.urllib.request.urlopen", side_effect=TimeoutError("test")):
            result = run_public_network_probe("gemini")
        self.assertEqual(result["ok_count"], 0)
        self.assertEqual(result["total_count"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
