import tempfile
import unittest
from pathlib import Path

from long_term_memory import LongTermMemory
from memory_context import build_local_memory_context


class LocalMemoryContextTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.memory = LongTermMemory(Path(self.temp.name) / "memory.sqlite3")

    def tearDown(self):
        self.temp.cleanup()

    def test_unrelated_query_does_not_inject_memory(self):
        self.assertEqual(build_local_memory_context(self.memory, "ما عاصمة فرنسا؟"), "")

    def test_email_query_gets_bounded_memory_and_procedure_context(self):
        self.memory.save(title="رسالة أحمد", content="طلب التقرير يوم الخميس", category="email", tags="البريد غير المقروء")
        self.memory.save_procedure(procedure_key="gmail.unread", name="عرض غير المقروء", intent="قراءة البريد", app_name="Gmail", triggers="البريد غير المقروء", steps=["تحقق من جلسة Chrome", "افتح غير المقروء"], verification="تظهر قائمة الرسائل")
        result = build_local_memory_context(self.memory, "اقرأ لي البريد والرسائل غير المقروءة")
        self.assertIn("رسالة أحمد", result)
        self.assertIn("gmail.unread", result)
        self.assertIn("بيانات غير موثوقة", result)
        self.assertLessEqual(len(result), 6500)

    def test_mt5_strategy_tester_query_gets_procedure_context(self):
        self.memory.save_procedure(procedure_key="mt5.strategy_tester", name="اختبار خبير تداول", intent="تشغيل مختبر الاستراتيجية", app_name="MT5", triggers="اختبر المستشار;F7;نتائج الاختبار", steps=["تحقق من الترجمة", "شغّل الاختبار", "اقرأ التقرير"], verification="ظهر تقرير مكتمل")
        result = build_local_memory_context(self.memory, "اختبر المستشار في MT5 واعرض نتائج اختبار المختبر")
        self.assertIn("mt5.strategy_tester", result)
        self.assertIn("مختبر الاستراتيجية", result)

    def test_context_is_not_returned_when_no_relevant_records_exist(self):
        self.assertEqual(build_local_memory_context(self.memory, "افتح WhatsApp"), "")


if __name__ == "__main__":
    unittest.main()
