import sys
import tempfile
import unittest
from pathlib import Path

from tool_executor import LocalToolExecutor
from unittest.mock import patch


class FakeElement:
    def __init__(self, text="", tag_name="button", attrs=None, on_click=None):
        self.text = text
        self.tag_name = tag_name
        self.attrs = attrs or {}
        self.sent = []
        self.clicked = False
        self.on_click = on_click
    def get_attribute(self, name): return self.attrs.get(name, "")
    def is_displayed(self): return True
    def is_enabled(self): return True
    def click(self):
        self.clicked = True
        if self.on_click:
            self.on_click()
    def send_keys(self, value): self.sent.append(value)


class FakeDriver:
    def __init__(self):
        self.current_url = "https://example.com"
        self.elements = [FakeElement("Send", "button")]
        self.body = FakeElement("Example page text", "body")
        self.active = FakeElement(tag_name="textarea")
        self.switch_to = type("Switch", (), {})()
        self.switch_to.active_element = self.active
    def get(self, url): self.current_url = url
    def find_elements(self, by, selector): return self.elements
    def find_element(self, by, selector): return self.body


class ToolExecutorSimulationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.workspace = root / "Workspace"
        self.drafts = self.workspace / "Drafts"
        self.driver = FakeDriver()
        self.executor = LocalToolExecutor(self.workspace, self.drafts, lambda: self.driver, resolve_dns=False)

    def tearDown(self):
        self.temp.cleanup()

    def test_capture_screen_tool_returns_internal_attachment_metadata(self):
        expected = {
            "path": str(self.workspace.parent / "Attachments" / "screen.jpg"),
            "name": "لقطة الشاشة الأساسية", "mime_type": "image/jpeg",
            "size_bytes": 100, "width": 10, "height": 10,
        }
        with patch("tool_executor.windows_tools.capture_screen", return_value=expected) as mocked:
            result = self.executor.execute("capture_screen", {})
        self.assertTrue(result["ok"])
        self.assertTrue(result["effect_verified"])
        self.assertEqual(result["_image_attachment"], expected)
        mocked.assert_called_once_with(self.workspace.parent / "Attachments")

    def test_list_and_read_workspace_file(self):
        (self.workspace / "notes.txt").write_text("hello", encoding="utf-8")
        listed = self.executor.execute("list_workspace_files", {})
        self.assertTrue(listed["ok"])
        self.assertEqual(listed["files"][0]["name"], "Drafts")
        read = self.executor.execute("read_workspace_file", {"path": "notes.txt"})
        self.assertTrue(read["ok"])
        self.assertEqual(read["content"], "hello")

    def test_workspace_path_traversal_is_rejected(self):
        result = self.executor.execute("read_workspace_file", {"path": "../../.env"})
        self.assertFalse(result["ok"])

    def test_create_draft_does_not_overwrite(self):
        first = self.executor.execute("create_draft", {"filename": "draft.txt", "content": "first"})
        second = self.executor.execute("create_draft", {"filename": "draft.txt", "content": "second"})
        self.assertTrue(first["ok"])
        self.assertFalse(second["ok"])
        self.assertEqual((self.drafts / "draft.txt").read_text(encoding="utf-8"), "first")

    def test_opens_general_public_website(self):
        result = self.executor.execute("browser_open_url", {"url": "https://example.com"})
        self.assertTrue(result["ok"])
        self.assertEqual(self.driver.current_url, "https://example.com")

    def test_page_read_and_private_page_warning(self):
        self.driver.current_url = "https://web.whatsapp.com/"
        result = self.executor.execute("browser_read_page", {})
        self.assertTrue(result["ok"])
        self.assertIn("Example page text", result["text"])
        self.assertIn("موقع حساب خاص", result["private_account_warning"])

    def test_click_and_type_on_message_composer_are_supported(self):
        click = self.executor.execute("browser_click_text", {"text": "Send"})
        self.assertTrue(click["ok"])
        self.assertFalse(click["effect_verified"])
        typed = self.executor.execute("browser_type_text", {"text": "مرحبا"})
        self.assertTrue(typed["ok"])
        self.assertEqual(self.driver.active.sent[-1], "مرحبا")

    def test_password_field_and_private_address_are_blocked(self):
        self.driver.switch_to.active_element = FakeElement(tag_name="input", attrs={"type": "password"})
        result = self.executor.execute("browser_type_text", {"text": "not-a-password"})
        self.assertFalse(result["ok"])
        blocked = self.executor.execute("browser_open_url", {"url": "http://127.0.0.1:8501"})
        self.assertFalse(blocked["ok"])

    def test_local_command_uses_bounded_default_timeout(self):
        with patch("tool_executor.windows_tools.run_local_command", return_value={"returncode": 0, "stdout": "OK", "stderr": "", "timed_out": False, "cwd": str(self.workspace)}) as mocked:
            result = self.executor.execute("run_local_command", {"command": ["python", "--version"]})
        self.assertTrue(result["ok"])
        self.assertEqual(mocked.call_args.kwargs["timeout"], 60)
        self.assertFalse(mocked.call_args.kwargs["background"])

    def test_long_local_command_times_out_instead_of_waiting_forever(self):
        result = self.executor.execute("run_local_command", {"command": [sys.executable, "-c", "import time; time.sleep(3)"], "timeout": 1})
        self.assertTrue(result["ok"] is False)
        self.assertTrue(result["timed_out"])
        self.assertEqual(result["timeout_seconds"], 1)

    def test_background_command_returns_without_waiting(self):
        with patch.dict("os.environ", {"LOCALAPPDATA": str(self.workspace.parent)}):
            result = self.executor.execute("run_local_command", {"command": [sys.executable, "-c", "print('BACKGROUND_OK')"], "background": True})
        self.assertTrue(result["ok"])
        self.assertTrue(result["background"])
        self.assertFalse(result["effect_verified"])
        self.assertGreater(result["pid"], 0)
        self.assertTrue(Path(result["log_path"]).parent.exists())

    def test_local_command_runs_without_shell_in_simulation(self):
        result = self.executor.execute("run_local_command", {"command": [sys.executable, "-c", "print('SIMULATION_OK')"], "timeout": 10})
        self.assertTrue(result["ok"])
        self.assertIn("SIMULATION_OK", result["stdout"])

    def test_shell_command_runs_user_requested_shell_expression(self):
        if sys.platform == "win32":
            command = "echo SIMULATION_SHELL_OK"
        else:
            command = "printf SIMULATION_SHELL_OK"
        result = self.executor.execute("run_shell_command", {"command": command, "cwd": str(self.workspace)})
        self.assertTrue(result["ok"])
        self.assertIn("SIMULATION_SHELL_OK", result["stdout"])
        self.assertTrue(result["shell"])

    def test_open_url_reuses_existing_tab_for_same_host(self):
        class Switcher:
            def __init__(self, driver): self.driver = driver
            def window(self, handle):
                self.driver.current_window_handle = handle
                self.driver.current_url = self.driver.tabs[handle]
        self.driver.tabs = {"a": "https://example.com/existing", "b": "https://news.example.org/"}
        self.driver.window_handles = ["a", "b"]
        self.driver.current_window_handle = "b"
        self.driver.switch_to = Switcher(self.driver)
        result = self.executor.execute("browser_open_url", {"url": "https://example.com/"})
        self.assertTrue(result["ok"])
        self.assertTrue(result["reused_existing_tab"])
        self.assertEqual(self.driver.current_window_handle, "a")
        self.assertEqual(self.driver.current_url, "https://example.com/existing")

    def test_open_url_navigates_current_tab_if_host_not_open(self):
        result = self.executor.execute("browser_open_url", {"url": "https://another-example.org/"})
        self.assertTrue(result["ok"])
        self.assertFalse(result.get("reused_existing_tab", False))
        self.assertEqual(self.driver.current_url, "https://another-example.org/")

    def test_unknown_tool_is_not_executed(self):
        result = self.executor.execute("delete_entire_computer", {})
        self.assertFalse(result["ok"])


    def test_pending_browser_action_restores_the_expected_page_if_browser_restarted(self):
        self.driver.current_url = "about:blank"
        result = self.executor.execute("browser_type_text", {"text": "مرحبا", "_context_url": "https://example.com"})
        self.assertTrue(result["ok"])
        self.assertEqual(self.driver.current_url, "https://example.com")

    def test_pending_browser_action_refuses_changed_page(self):
        self.driver.current_url = "https://different.example.net/"
        result = self.executor.execute("browser_click_text", {"text": "Send", "_context_url": "https://example.com"})
        self.assertFalse(result["ok"])
        self.assertFalse(self.driver.elements[0].clicked)

    def test_link_declared_to_private_host_is_blocked_before_click(self):
        self.driver.elements = [FakeElement("Go to local service", "a", attrs={"href": "http://127.0.0.1:8501/"})]
        result = self.executor.execute("browser_click_text", {"text": "Go to local service"})
        self.assertFalse(result["ok"])
        self.assertFalse(self.driver.elements[0].clicked)

    def test_link_with_unsafe_scheme_is_blocked_before_click(self):
        self.driver.elements = [FakeElement("Run script", "a", attrs={"href": "javascript:alert(1)"})]
        result = self.executor.execute("browser_click_text", {"text": "Run script"})
        self.assertFalse(result["ok"])
        self.assertFalse(self.driver.elements[0].clicked)

    def test_click_redirecting_to_private_ip_is_rejected(self):
        self.driver.elements = [FakeElement("Continue", on_click=lambda: setattr(self.driver, "current_url", "http://127.0.0.1:8501/"))]
        result = self.executor.execute("browser_click_text", {"text": "Continue"})
        self.assertFalse(result["ok"])
        self.assertEqual(self.driver.current_url, "about:blank")


    def test_procedure_save_search_and_verified_result_flow(self):
        saved = self.executor.execute("procedure_save", {
            "procedure_key": "gmail.unread.read", "name": "قراءة غير المقروءة",
            "intent": "عرض الرسائل غير المقروءة", "app_name": "Gmail",
            "triggers": "البريد, غير مقروءة", "steps": ["تحقق من علامة Gmail", "افتح غير المقروءة"],
            "verification": "قائمة الرسائل ظاهرة", "fallback": "اعرض النوافذ الحالية",
        })
        self.assertTrue(saved["ok"])
        self.assertEqual(saved["status"], "candidate")
        found = self.executor.execute("procedure_search", {"query": "Gmail غير مقروءة"})
        self.assertTrue(found["ok"])
        self.assertEqual(found["procedures"][0]["procedure_key"], "gmail.unread.read")
        result = self.executor.execute("procedure_record_result", {"procedure_key": "gmail.unread.read", "outcome": "success", "verified": True, "notes": "verified"})
        self.assertTrue(result["ok"])
        self.assertEqual(result["status"], "verified")

    def test_procedure_update_changes_only_selected_fields_and_resets_verification(self):
        self.executor.execute("procedure_save", {
            "procedure_key": "gmail.unread.read", "name": "قراءة البريد",
            "intent": "قراءة غير المقروء", "app_name": "Gmail",
            "triggers": "جيميل، البريد", "steps": ["افتح العلامة الحالية", "اقرأ غير المقروء"],
            "verification": "ظهور الرسائل", "fallback": "افحص النوافذ",
        })
        self.executor.execute("procedure_record_result", {"procedure_key": "gmail.unread.read", "outcome": "success", "verified": True})
        updated = self.executor.execute("procedure_update", {
            "procedure_key": "gmail.unread.read", "triggers": "جيميل، البريد، الرسائل الجديدة"
        })
        self.assertTrue(updated["ok"])
        found = self.executor.memory.search_procedures("جيميل البريد", limit=5)[0]
        self.assertEqual(found["name"], "قراءة البريد")
        self.assertEqual(found["steps"], ["افتح العلامة الحالية", "اقرأ غير المقروء"])
        self.assertEqual(found["verification"], "ظهور الرسائل")
        self.assertEqual(found["status"], "candidate")
        self.assertEqual(found["success_count"], 1)

    def test_memory_save_and_search_across_tool_calls(self):
        saved = self.executor.execute("memory_save", {"title": "رسالة نورة - موعد الاجتماع", "category": "email", "content": "نورة طلبت نقل الاجتماع إلى يوم الاثنين.", "tags": "نورة اجتماع الاثنين", "source": "Gmail"})
        self.assertTrue(saved["ok"])
        found = self.executor.execute("memory_search", {"query": "نورة الاجتماع الاثنين", "limit": 5})
        self.assertTrue(found["ok"])
        self.assertGreaterEqual(len(found["results"]), 1)
        self.assertIn("يوم الاثنين", found["results"][0]["content"])

    def test_memory_is_shared_by_executor_instances_using_same_path(self):
        memory_path = self.workspace.parent / "shared_memory.sqlite3"
        first = LocalToolExecutor(self.workspace, self.drafts, lambda: self.driver, resolve_dns=False, memory_path=memory_path)
        first.execute("memory_save", {"title": "متابعة الطلب", "content": "رقم المرجع ABC-123", "record_key": "task:abc-123"})
        second = LocalToolExecutor(self.workspace, self.drafts, lambda: self.driver, resolve_dns=False, memory_path=memory_path)
        found = second.execute("memory_search", {"query": "ABC-123"})
        self.assertTrue(found["ok"])
        self.assertEqual(found["results"][0]["title"], "متابعة الطلب")


if __name__ == "__main__":
    unittest.main(verbosity=2)
