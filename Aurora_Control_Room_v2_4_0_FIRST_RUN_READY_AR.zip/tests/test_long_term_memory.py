import tempfile
import unittest
from pathlib import Path

from long_term_memory import LongTermMemory


class LongTermMemoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "memory.sqlite3"
        self.memory = LongTermMemory(self.path)

    def tearDown(self):
        self.temp.cleanup()

    def test_existing_v228_memory_database_adds_procedure_table_without_losing_records(self):
        import sqlite3
        legacy_path = self.path.parent / "legacy_v228.sqlite3"
        con = sqlite3.connect(legacy_path)
        try:
            con.execute("CREATE TABLE memories (id TEXT PRIMARY KEY, record_key TEXT UNIQUE, category TEXT NOT NULL DEFAULT 'note', title TEXT NOT NULL, content TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)")
            con.execute("INSERT INTO memories VALUES ('legacy-id','legacy-key','note','legacy title','legacy content','','','2026-01-01','2026-01-01')")
            con.commit()
        finally:
            con.close()
        upgraded = LongTermMemory(legacy_path)
        self.assertEqual(upgraded.count(), 1)
        self.assertEqual(upgraded.search("legacy title")[0]["id"], "legacy-id")
        self.assertEqual(upgraded.procedure_count(), 0)
        upgraded.save_procedure(procedure_key="test.open", name="Open", intent="open", steps=["open app"])
        self.assertEqual(upgraded.procedure_count(), 1)

    def test_saved_memory_survives_reopening_database(self):
        saved = self.memory.save(title="رسالة أحمد - تحديث المشروع", category="email",
                                 content="المرسل: أحمد. الموضوع: تحديث المشروع. طلب إرسال تقرير يوم الخميس.",
                                 tags="أحمد, تقرير, الخميس", source="Gmail", record_key="email:ahmed:project-update")
        reloaded = LongTermMemory(self.path)
        found = reloaded.search("أحمد تقرير الخميس", limit=5)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["id"], saved["id"])
        self.assertIn("يوم الخميس", found[0]["content"])

    def test_search_ranks_matching_title(self):
        self.memory.save(title="رسالة فاتورة الكهرباء", content="موعد السداد نهاية الشهر", category="email")
        self.memory.save(title="ملاحظات السفر", content="فاتورة الفندق", category="note")
        found = self.memory.search("فاتورة الكهرباء", limit=2)
        self.assertEqual(found[0]["title"], "رسالة فاتورة الكهرباء")

    def test_record_key_updates_existing_memory_without_duplicate(self):
        self.memory.save(title="رسالة", content="النسخة الأولى", record_key="gmail:123")
        self.memory.save(title="رسالة محدثة", content="النسخة الثانية", record_key="gmail:123")
        self.assertEqual(self.memory.count(), 1)
        self.assertEqual(self.memory.search("محدثة")[0]["content"], "النسخة الثانية")

    def test_rejects_obvious_credential_assignment(self):
        with self.assertRaisesRegex(ValueError, "بيانات اعتماد"):
            self.memory.save(title="سر", content="api_key=sk-example-secret")

    def test_content_size_is_bounded(self):
        with self.assertRaisesRegex(ValueError, "الحد المسموح"):
            self.memory.save(title="طويل", content="x" * 20001)

    def test_search_finds_old_memory_after_more_than_500_records(self):
        self.memory.save(title="رسالة قديمة مهمة", content="المرجع الفريد OLD-REFERENCE-77", record_key="old-record")
        for i in range(510):
            self.memory.save(title=f"ملاحظة حديثة {i}", content=f"تفصيل حديث {i}")
        found = self.memory.search("OLD-REFERENCE-77", limit=5)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["title"], "رسالة قديمة مهمة")

    def test_procedure_is_candidate_until_success_is_verified(self):
        saved = self.memory.save_procedure(
            procedure_key="gmail.unread.read", name="قراءة الرسائل غير المقروءة",
            intent="عرض الرسائل غير المقروءة وتلخيصها", app_name="Gmail",
            triggers="البريد, غير مقروءة, اقرأ الرسائل",
            steps=["تأكد من جلسة Chrome الحالية", {"action": "open", "target": "Unread"}],
            verification="تظهر قائمة الرسائل غير المقروءة ونص الرسائل المطلوبة",
            fallback="إذا تعذر العثور على العلامة، اعرض النوافذ المفتوحة ولا تفتح جلسة بديلة بصمت",
        )
        self.assertEqual(saved["status"], "candidate")
        found = self.memory.search_procedures("Gmail غير مقروءة", limit=3)
        self.assertEqual(found[0]["procedure_key"], "gmail.unread.read")
        self.assertEqual(found[0]["status"], "candidate")
        result = self.memory.record_procedure_result(procedure_key="gmail.unread.read", outcome="success", verified=False)
        self.assertEqual(result["status"], "candidate")
        result = self.memory.record_procedure_result(procedure_key="gmail.unread.read", outcome="success", verified=True, notes="تم التحقق من ظهور قائمة الرسائل")
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["success_count"], 1)

    def test_changed_procedure_loses_verified_status(self):
        self.memory.save_procedure(procedure_key="app.open", name="فتح تطبيق", intent="فتح تطبيق محلي", steps=["شغّل التطبيق"])
        self.memory.record_procedure_result(procedure_key="app.open", outcome="success", verified=True)
        changed = self.memory.save_procedure(procedure_key="app.open", name="فتح تطبيق", intent="فتح تطبيق محلي", steps=["تحقق من المسار", "شغّل التطبيق"])
        self.assertEqual(changed["status"], "candidate")

    def test_procedure_rejects_obvious_credential_assignment(self):
        with self.assertRaisesRegex(ValueError, "بيانات اعتماد"):
            self.memory.save_procedure(procedure_key="unsafe", name="Unsafe", intent="open", steps=["api_key=secret-value"])

    def test_changed_procedure_triggers_loses_verified_status(self):
        self.memory.save_procedure(procedure_key="gmail.open", name="فتح Gmail", intent="فتح البريد", triggers="بريد", steps=["افتح البريد"])
        self.memory.record_procedure_result(procedure_key="gmail.open", outcome="success", verified=True)
        updated = self.memory.save_procedure(procedure_key="gmail.open", name="فتح Gmail", intent="فتح البريد", triggers="البريد غير المقروء", steps=["افتح البريد"])
        self.assertEqual(updated["status"], "candidate")

    def test_procedure_rejects_empty_or_too_many_steps(self):
        with self.assertRaises(ValueError):
            self.memory.save_procedure(procedure_key="bad", name="Bad", intent="Bad", steps=[])
        with self.assertRaises(ValueError):
            self.memory.save_procedure(procedure_key="bad", name="Bad", intent="Bad", steps=["step"] * 26)

    def test_procedure_failure_increments_failure_count_and_demotes(self):
        self.memory.save_procedure(procedure_key="app.open", name="فتح تطبيق", intent="فتح تطبيق محلي", steps=["شغّل التطبيق"])
        self.memory.record_procedure_result(procedure_key="app.open", outcome="success", verified=True)
        result = self.memory.record_procedure_result(procedure_key="app.open", outcome="failure", notes="لم تظهر النافذة")
        self.assertEqual(result["status"], "candidate")
        self.assertEqual(result["failure_count"], 1)

    def test_missing_procedure_result_key_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "غير موجود"):
            self.memory.record_procedure_result(procedure_key="missing", outcome="failure")


if __name__ == "__main__":
    unittest.main(verbosity=2)
