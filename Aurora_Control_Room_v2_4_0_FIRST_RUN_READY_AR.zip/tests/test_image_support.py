import io
import tempfile
import unittest
from pathlib import Path

from PIL import Image

from image_support import (
    MAX_IMAGE_BYTES, ImageAttachmentError, load_attachment,
    messages_with_openai_images, store_uploaded_images,
)


class FakeUpload:
    def __init__(self, name, data):
        self.name = name
        self._data = data
    def getvalue(self):
        return self._data


def make_image(fmt="PNG", color=(20, 80, 140, 255), size=(24, 16)):
    image = Image.new("RGBA" if fmt == "PNG" else "RGB", size, color)
    buffer = io.BytesIO()
    image.save(buffer, format=fmt)
    return buffer.getvalue()


class ImageSupportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "Attachments"
        self.root.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def test_upload_is_normalized_stored_and_reloaded(self):
        metadata = store_uploaded_images([FakeUpload("screenshot.png", make_image())], self.root)
        self.assertEqual(len(metadata), 1)
        self.assertEqual(metadata[0]["mime_type"], "image/png")
        self.assertTrue(Path(metadata[0]["path"]).is_file())
        loaded = load_attachment(metadata[0], self.root)
        self.assertEqual(loaded["mime_type"], "image/png")
        self.assertGreater(loaded["size_bytes"], 0)
        self.assertEqual((loaded["width"], loaded["height"]), (24, 16))

    def test_webp_is_transcoded_to_safe_supported_jpeg(self):
        metadata = store_uploaded_images([FakeUpload("photo.webp", make_image("WEBP", (12, 50, 90)))], self.root)
        self.assertEqual(metadata[0]["mime_type"], "image/jpeg")
        loaded = load_attachment(metadata[0], self.root)
        self.assertEqual(loaded["mime_type"], "image/jpeg")
        self.assertTrue(metadata[0]["path"].endswith(".jpg"))

    def test_non_image_bytes_are_rejected_even_if_named_png(self):
        with self.assertRaises(ImageAttachmentError):
            store_uploaded_images([FakeUpload("safe.png", b"MZ this is not an image")], self.root)
        self.assertEqual(list(self.root.iterdir()), [])

    def test_unsupported_gif_is_rejected(self):
        with self.assertRaisesRegex(ImageAttachmentError, "PNG وJPEG وWebP"):
            store_uploaded_images([FakeUpload("anim.gif", make_image("GIF"))], self.root)

    def test_per_image_size_limit_is_enforced_before_decode(self):
        with self.assertRaisesRegex(ImageAttachmentError, "6 ميبيبايت"):
            store_uploaded_images([FakeUpload("big.png", b"0" * (MAX_IMAGE_BYTES + 1))], self.root)

    def test_more_than_four_images_are_rejected(self):
        with self.assertRaisesRegex(ImageAttachmentError, "أربع صور"):
            store_uploaded_images([FakeUpload(f"{i}.png", make_image()) for i in range(5)], self.root)

    def test_path_outside_attachment_directory_is_rejected(self):
        outside = Path(self.temp.name) / "outside.png"
        outside.write_bytes(make_image())
        with self.assertRaises(ImageAttachmentError):
            load_attachment({"path": str(outside), "mime_type": "image/png"}, self.root)

    def test_openai_compatible_provider_receives_data_url_not_local_path(self):
        metadata = store_uploaded_images([FakeUpload("chart.png", make_image())], self.root)
        converted = messages_with_openai_images([{
            "role": "user", "content": "حلل الرسم", "attachments": metadata,
        }], self.root)
        self.assertNotIn("attachments", converted[0])
        self.assertIsInstance(converted[0]["content"], list)
        self.assertEqual(converted[0]["content"][0], {"type": "text", "text": "حلل الرسم"})
        image_part = converted[0]["content"][1]
        self.assertEqual(image_part["type"], "image_url")
        self.assertTrue(image_part["image_url"]["url"].startswith("data:image/png;base64,"))
        self.assertNotIn(str(self.root), str(converted))

    def test_provider_request_total_image_budget_is_enforced(self):
        metadata_a = store_uploaded_images([FakeUpload("a.png", make_image())], self.root)
        metadata_b = store_uploaded_images([FakeUpload("b.png", make_image())], self.root)
        # Existing persisted metadata cannot make the same image count exceed the total limit in this fixture;
        # the global budget logic is exercised by repeating attachments many times with a patched loader.
        from unittest.mock import patch
        fake = {"data": b"x" * (4 * 1024 * 1024), "mime_type": "image/png", "name": "x.png", "size_bytes": 4 * 1024 * 1024, "width": 2, "height": 2}
        with patch("image_support.load_attachment", return_value=fake):
            with self.assertRaisesRegex(ImageAttachmentError, "8 ميبيبايت"):
                messages_with_openai_images([
                    {"role": "user", "content": "first", "attachments": metadata_a},
                    {"role": "user", "content": "second", "attachments": metadata_b},
                    {"role": "user", "content": "third", "attachments": metadata_a},
                ], self.root)


if __name__ == "__main__":
    unittest.main(verbosity=2)
