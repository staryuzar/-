import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from database_manager import initialize_unified_database


class UnifiedDatabaseBootstrapTests(unittest.TestCase):
    def _make_legacy_conversations(self, path: Path):
        con = sqlite3.connect(path)
        try:
            # Mimic an older version where the tool transcript used tool_log_json.
            con.execute("""CREATE TABLE conversations (
                id TEXT PRIMARY KEY, title TEXT, created_at TEXT, updated_at TEXT,
                messages_json TEXT, tool_log_json TEXT
            )""")
            con.execute(
                "INSERT INTO conversations VALUES (?,?,?,?,?,?)",
                ("conv-1", "قديم محفوظ", "2026-10-01", "2026-10-02", '[{"role":"user","content":"hello"}]', '[{"tool":"read"}]'),
            )
            con.commit()
        finally:
            con.close()

    def _make_legacy_memory(self, path: Path):
        con = sqlite3.connect(path)
        try:
            con.execute("""CREATE TABLE memories (
                id TEXT PRIMARY KEY, record_key TEXT UNIQUE, category TEXT NOT NULL,
                title TEXT NOT NULL, content TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            )""")
            con.execute(
                "INSERT INTO memories VALUES (?,?,?,?,?,?,?,?,?)",
                ("mem-1", "workflow.test", "workflow", "ذاكرة قديمة", "يجب ألا تضيع", "قديم", "test", "2026-10-01", "2026-10-02"),
            )
            con.execute("""CREATE TABLE procedures (
                procedure_key TEXT PRIMARY KEY, name TEXT NOT NULL, intent TEXT NOT NULL,
                triggers TEXT NOT NULL DEFAULT '', steps_json TEXT NOT NULL,
                verification TEXT NOT NULL DEFAULT '', fallback TEXT NOT NULL DEFAULT '',
                app_name TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'candidate',
                success_count INTEGER NOT NULL DEFAULT 0, failure_count INTEGER NOT NULL DEFAULT 0,
                last_outcome TEXT NOT NULL DEFAULT '', last_notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            )""")
            con.execute(
                "INSERT INTO procedures VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                ("procedure.test", "إجراء قديم", "intent", "trigger", '["step1"]', "done", "fallback", "App", "verified", 4, 1, "success", "note", "2026-09-01", "2026-10-01"),
            )
            con.commit()
        finally:
            con.close()

    def test_consolidates_legacy_files_into_one_active_database_and_archives_sources(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp) / "AuroraData"
            data_dir.mkdir()
            chat = data_dir / "chat_history.sqlite3"
            memory = data_dir / "long_term_memory.sqlite3"
            self._make_legacy_conversations(chat)
            self._make_legacy_memory(memory)

            report = initialize_unified_database(data_dir)
            unified = data_dir / "aurora.sqlite3"
            self.assertTrue(unified.is_file())
            self.assertEqual(report["integrity"], "ok")
            self.assertEqual(report["active_database_count"], 1)
            self.assertFalse(chat.exists())
            self.assertFalse(memory.exists())
            self.assertEqual(sorted(p.name for p in data_dir.glob("*.sqlite3")), ["aurora.sqlite3"])

            with closing(sqlite3.connect(unified)) as con:
                row = con.execute("SELECT id,title,log_json FROM conversations WHERE id='conv-1'").fetchone()
                self.assertEqual(row[0], "conv-1")
                self.assertEqual(row[1], "قديم محفوظ")
                self.assertEqual(json.loads(row[2]), [{"tool": "read"}])
                memory_row = con.execute("SELECT content FROM memories WHERE record_key='workflow.test'").fetchone()
                self.assertEqual(memory_row[0], "يجب ألا تضيع")
                proc = con.execute("SELECT status,success_count,steps_json FROM procedures WHERE procedure_key='procedure.test'").fetchone()
                self.assertEqual(proc[0], "verified")
                self.assertEqual(proc[1], 4)
                self.assertEqual(json.loads(proc[2]), ["step1"])
                self.assertEqual(con.execute("PRAGMA integrity_check").fetchone()[0], "ok")

            archives = list((data_dir / "Backups" / "LegacySQLite").glob("*/*.sqlite3"))
            self.assertEqual({p.name for p in archives}, {"chat_history.sqlite3", "long_term_memory.sqlite3"})
            for archived in archives:
                with closing(sqlite3.connect(archived)) as con:
                    self.assertEqual(con.execute("PRAGMA integrity_check").fetchone()[0], "ok")

            again = initialize_unified_database(data_dir)
            self.assertEqual(again["active_database_count"], 1)
            with closing(sqlite3.connect(unified)) as con:
                self.assertEqual(con.execute("SELECT COUNT(*) FROM conversations").fetchone()[0], 1)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 1)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM procedures").fetchone()[0], 1)

    def test_corrupt_legacy_database_stops_bootstrap_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp)
            source = data_dir / "long_term_memory.sqlite3"
            source.write_bytes(b"this is not sqlite")
            with self.assertRaises(Exception):
                initialize_unified_database(data_dir)
            self.assertTrue(source.is_file())
            self.assertFalse((data_dir / "aurora.sqlite3").exists())
            self.assertFalse((data_dir / "Backups" / "LegacySQLite").exists())

    def test_bootstrap_is_cached_within_process_after_first_success(self):
        import database_manager
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp)
            database_manager._BOOTSTRAP_RESULTS.pop(str(data_dir.resolve()), None)
            first = initialize_unified_database(data_dir)
            with patch.object(database_manager, "_integrity", wraps=database_manager._integrity) as check:
                second = initialize_unified_database(data_dir)
                check.assert_not_called()
            self.assertEqual(first["active_database_count"], 1)
            self.assertTrue(second.get("cached_for_this_process"))

    def test_sqlite_is_not_a_pip_dependency(self):
        root = Path(__file__).resolve().parents[1]
        requirements = root / "requirements.txt"
        lines = [line.strip().lower() for line in requirements.read_text(encoding="utf-8").splitlines()]
        self.assertFalse(any(line.split("#", 1)[0].strip().replace("-", "_").startswith("sqlite3") for line in lines))
        import sqlite3
        self.assertTrue(sqlite3.sqlite_version)
        startup = (root / "START_WINDOWS.bat").read_text(encoding="utf-8")
        self.assertIn("import sqlite3", startup)
        self.assertIn("SQLite is not a separate Aurora pip dependency", startup)

    def test_existing_unified_data_wins_over_duplicate_legacy_ids(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp)
            unified = data_dir / "aurora.sqlite3"
            from conversation_store import ConversationStore
            from long_term_memory import LongTermMemory
            store = ConversationStore(unified)
            memory = LongTermMemory(unified)
            cid = store.create("Keep target record")
            memory.save(title="Target memory", content="target content", record_key="same.key")

            legacy = data_dir / "long_term_memory.sqlite3"
            self._make_legacy_memory(legacy)
            # Change old row to conflict by record_key, but preserve the live target.
            with closing(sqlite3.connect(legacy)) as con:
                con.execute("UPDATE memories SET content='older conflicting content' WHERE record_key='workflow.test'")
                con.execute("UPDATE memories SET record_key='same.key',id='other-id',title='Older collision' WHERE id='mem-1'")
                con.commit()
            initialize_unified_database(data_dir)
            with closing(sqlite3.connect(unified)) as con:
                content = con.execute("SELECT content FROM memories WHERE record_key='same.key'").fetchone()[0]
                self.assertEqual(content, "target content")
                self.assertEqual(con.execute("SELECT COUNT(*) FROM conversations WHERE id=?", (cid,)).fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
