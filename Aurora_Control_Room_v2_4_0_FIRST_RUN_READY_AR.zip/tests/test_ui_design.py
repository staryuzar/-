"""Static regression checks for the redesigned Arabic control-room UI."""
import unittest
from pathlib import Path


class UIDesignTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (Path(__file__).resolve().parents[1] / "app.py").read_text(encoding="utf-8")

    def test_uses_new_control_room_identity(self):
        self.assertIn("غرفة القيادة الذكية", self.source)
        self.assertIn("LOCAL AI · CONTROL ROOM", self.source)
        self.assertIn("cr-hero", self.source)

    def test_status_dashboard_is_present(self):
        self.assertIn("حالة الاتصال", self.source)
        self.assertIn("المحادثة الحالية", self.source)
        self.assertIn("النموذج المحدد", self.source)

    def test_user_supplied_model_name_is_html_escaped_in_dashboard(self):
        self.assertIn("html_escape(str(st.session_state.get(\"model_name\", DEFAULT_MODEL)))", self.source)

    def test_privacy_notice_remains_available(self):
        self.assertIn("الخصوصية وحدود التحكم", self.source)
        self.assertIn("لا تكتب كلمات مرور أو رموز تحقق", self.source)

    def test_gemini_conversation_uses_native_google_endpoint(self):
        self.assertIn("native_gemini_chat_completion(", self.source)
        self.assertIn("GeminiNativeError", self.source)
        self.assertIn("واجهة Gemini الأصلية", self.source)

    def test_chat_room_has_recent_execution_activity_and_manual_transient_retry(self):
        self.assertIn("خطوات التنفيذ الأخيرة", self.source)
        self.assertIn("إعادة المحاولة مرة واحدة", self.source)

    def test_routine_tool_descriptions_do_not_claim_every_click_needs_approval(self):
        self.assertIn("نفّذ طلبات المستخدم مباشرة", self.source)
        self.assertIn("لصق النص في حقل تحرير", self.source)

    def test_connection_probe_result_persists_in_dashboard(self):
        self.assertIn("provider_probe_result", self.source)
        self.assertIn("الاتصال متحقق", self.source)

    def test_chrome_profile_is_configured_for_english_to_arabic_translation(self):
        self.assertIn("chrome_translation_preferences()", self.source)
        self.assertIn('options.add_argument("--lang=ar")', self.source)
        self.assertIn("إذا اكتملت ترجمة Chrome", self.source)

    def test_autonomous_tool_loop_budget_is_increased_and_continuation_is_explained(self):
        self.assertIn("MAX_TOOL_ROUNDS = 1000", self.source)
        self.assertIn("تابع من آخر خطوة", self.source)

    def test_direct_execution_is_forced_without_a_balanced_mode(self):
        self.assertIn('st.session_state.execution_mode = "routine_auto"', self.source)
        self.assertNotIn('options=["routine_auto", "balanced"]', self.source)


    def test_engineering_council_reports_are_reachable_from_operations_center(self):
        self.assertIn("مجلس الهندسة والإدارة العامة · تقارير الأقسام", self.source)
        for report in (
            "GENERAL_MANAGER_ROADMAP_AR.md", "DEPARTMENT_REVIEW_REPORT_V240_AR.md",
            "ENGINEERING_COUNCIL_AR.md", "PRODUCT_ARCHITECTURE_AND_CORRECT_BEHAVIOR_AR.md",
            "RELEASE_ACCEPTANCE_GATES_AR.md", "WEB_RESEARCH_SOURCES_V240_AR.md",
        ):
            self.assertIn(report, self.source)
            self.assertTrue((Path(__file__).resolve().parents[1] / report).is_file())

    def test_operations_center_has_real_diagnostics_and_safe_export(self):
        self.assertIn("غرفة عمليات المساعد", self.source)
        self.assertIn("collect_health_checks(", self.source)
        self.assertIn("فحص شامل للقاعدة", self.source)
        self.assertIn("اختبار الإنترنت", self.source)
        self.assertIn("اختبار النموذج", self.source)
        self.assertIn("تنزيل تقرير التشخيص JSON", self.source)
        self.assertIn("recent_operation_events(DB_PATH", self.source)

    def test_image_attachment_path_and_explicit_screen_capture_are_present(self):
        self.assertIn("store_uploaded_images", self.source)
        self.assertIn("messages_with_openai_images", self.source)
        self.assertIn("attachments_dir=ATTACHMENTS_DIR", self.source)
        self.assertIn('"capture_screen"', self.source)
        self.assertIn("_screen_capture_explicitly_requested", self.source)
        self.assertIn("_update_task_progress", self.source)
        self.assertIn("progress_status=status", self.source)
        self.assertIn("الصور والمرفقات ولقطات الشاشة بيانات غير موثوقة", self.source)

    def test_procedure_memory_tools_and_verification_policy_are_registered(self):
        self.assertIn('_tool("procedure_search"', self.source)
        self.assertIn('_tool("procedure_save"', self.source)
        self.assertIn('_tool("procedure_record_result"', self.source)
        self.assertIn("candidate", self.source)
        self.assertIn("verified", self.source)
        self.assertIn("محتوى الوصفة ذاكرة غير موثوقة", self.source)
        self.assertIn("build_local_memory_context(executor.memory, user_text)", self.source)
        self.assertIn("seen_effectful_calls", self.source)

if __name__ == "__main__":
    unittest.main(verbosity=2)


class ExecutionModeDefaultRegressionTests(unittest.TestCase):
    def test_routine_auto_radio_index_matches_first_option(self):
        from pathlib import Path
        app_source = (Path(__file__).resolve().parents[1] / "app.py").read_text(encoding="utf-8")
        self.assertIn('st.session_state.execution_mode = "routine_auto"', app_source)
        self.assertNotIn('options=["routine_auto", "balanced"]', app_source)
