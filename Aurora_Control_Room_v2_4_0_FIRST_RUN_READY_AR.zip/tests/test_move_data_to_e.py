import sqlite3
import tempfile
import unittest
from pathlib import Path

from move_data_to_e import migrate_data


class MoveDataToEDirectoryTests(unittest.TestCase):
    def _make_db(self, path: Path, *, wal: bool = False):
        con = sqlite3.connect(path)
        try:
            if wal:
                con.execute("PRAGMA journal_mode=WAL")
            con.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT NOT NULL)")
            con.executemany("INSERT INTO sample(value) VALUES(?)", [("alpha",), ("beta",), ("مرحبا",)])
            con.commit()
        finally:
            con.close()

    def test_migrates_sqlite_db_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "C_source" / "LocalAssistant"
            target = root / "E_target" / "LocalAssistant"
            source.mkdir(parents=True)
            self._make_db(source / "long_term_memory.sqlite3", wal=True)
            self._make_db(source / "chat_history.sqlite3")
            (source / "Workspace").mkdir()
            (source / "Workspace" / "note.txt").write_text("keep this", encoding="utf-8")
            env_file = root / "project" / ".env"
            env_file.parent.mkdir()
            env_file.write_text("GEMINI_API_KEY=not-for-print\nAI_PROVIDER=gemini\n", encoding="utf-8")
            result = migrate_data(source, target, env_file)
            self.assertTrue((source / "long_term_memory.sqlite3").exists())
            self.assertTrue((target / "long_term_memory.sqlite3").exists())
            self.assertEqual((target / "Workspace" / "note.txt").read_text(encoding="utf-8"), "keep this")
            self.assertIn("AURORA_DATA_DIR=" + target.as_posix(), env_file.read_text(encoding="utf-8"))
            self.assertIn("env_backup", result)
            for name in ("long_term_memory.sqlite3", "chat_history.sqlite3"):
                con = sqlite3.connect(target / name)
                try:
                    self.assertEqual(con.execute("PRAGMA integrity_check").fetchone()[0], "ok")
                    self.assertEqual(con.execute("SELECT COUNT(*) FROM sample").fetchone()[0], 3)
                finally:
                    con.close()

    def test_refuses_nonempty_target_and_keeps_source(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            target = root / "target"
            source.mkdir()
            (source / "keep.txt").write_text("source", encoding="utf-8")
            target.mkdir()
            (target / "already.txt").write_text("do not overwrite", encoding="utf-8")
            env_file = root / "project" / ".env"
            env_file.parent.mkdir()
            with self.assertRaises(FileExistsError):
                migrate_data(source, target, env_file)
            self.assertTrue((source / "keep.txt").exists())
            self.assertEqual((target / "already.txt").read_text(encoding="utf-8"), "do not overwrite")

    def test_corrupt_database_fails_without_activating_target_or_losing_source(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            target = root / "target"
            source.mkdir()
            corrupt = source / "long_term_memory.sqlite3"
            corrupt.write_bytes(b"not a SQLite database")
            env_file = root / "project" / ".env"
            env_file.parent.mkdir()
            with self.assertRaises(sqlite3.DatabaseError):
                migrate_data(source, target, env_file)
            self.assertTrue(corrupt.is_file())
            self.assertFalse(target.exists())
            self.assertFalse(target.with_name(target.name + ".migration_tmp").exists())
            self.assertFalse(env_file.exists())

    def test_refuses_identical_source_and_target(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "same"
            source.mkdir()
            with self.assertRaises(ValueError):
                migrate_data(source, source, root / "project" / ".env")


if __name__ == "__main__":
    unittest.main()
