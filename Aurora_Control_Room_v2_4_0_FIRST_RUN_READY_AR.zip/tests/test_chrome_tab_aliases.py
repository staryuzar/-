import unittest
from windows_tools import canonical_chrome_tab_search, chrome_tab_matches_query


class ChromeTabAliasTests(unittest.TestCase):
    def test_arabic_aliases_use_english_chrome_search_terms(self):
        cases = {
            "افتح جيميل الموجود": "Gmail",
            "واتساب": "WhatsApp",
            "افتح واتس اب الموجود": "WhatsApp",
            "تليجرام": "Telegram",
            "تيليجرام": "Telegram",
            "يوتيوب": "YouTube",
            "أوتلوك": "Outlook",
        }
        for query, expected in cases.items():
            with self.subTest(query=query):
                self.assertEqual(canonical_chrome_tab_search(query), expected)

    def test_arabic_whatsapp_matches_official_host(self):
        self.assertTrue(chrome_tab_matches_query("افتح واتساب", "https://web.whatsapp.com/", "WhatsApp"))

    def test_arabic_telegram_matches_official_host(self):
        self.assertTrue(chrome_tab_matches_query("افتح تليجرام", "https://web.telegram.org/k/", "Telegram"))

    def test_gmail_matches_redirected_mail_host(self):
        self.assertTrue(chrome_tab_matches_query("جيميل", "https://mail.google.com/mail/u/0/", "Inbox - Google Chrome"))

    def test_alias_does_not_match_lookalike_domain(self):
        self.assertFalse(chrome_tab_matches_query("واتساب", "https://web.whatsapp.com.attacker.example/", "WhatsApp login"))

    def test_unrelated_query_does_not_match_service_domain(self):
        self.assertFalse(chrome_tab_matches_query("Telegram", "https://web.whatsapp.com/", "WhatsApp"))

    def test_english_query_still_matches_title(self):
        self.assertTrue(chrome_tab_matches_query("MQL5", "https://www.mql5.com/en/docs", "MQL5 Reference"))


if __name__ == "__main__":
    unittest.main()
