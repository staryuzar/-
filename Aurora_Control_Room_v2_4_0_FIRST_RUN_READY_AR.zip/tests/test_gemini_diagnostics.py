import io
import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

from gemini_diagnostics import list_gemini_models, test_gemini_native as _test_gemini_native


class FakeResponse:
    status = 200
    def __init__(self, payload):
        self.payload = json.dumps(payload).encode()
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self, n=-1): return self.payload[:n]


class GeminiDiagnosticTests(unittest.TestCase):
    def test_native_success_uses_key_header_not_url_and_reads_reply(self):
        with patch("gemini_diagnostics.urlopen", return_value=FakeResponse({
            "candidates": [{"content": {"parts": [{"text": "OK"}]}}]
        })) as mocked:
            ok, message = _test_gemini_native("SECRET-KEY", "gemini-3.8-flash")
        self.assertTrue(ok)
        self.assertIn("HTTP 200", message)
        self.assertIn("OK", message)
        request = mocked.call_args.args[0]
        self.assertNotIn("SECRET-KEY", request.full_url)
        self.assertEqual(request.get_header("X-goog-api-key"), "SECRET-KEY")

    def test_http_errors_are_classified_and_secret_redacted(self):
        for status, expected in [(404, "HTTP 404"), (429, "HTTP 429"), (503, "HTTP 503")]:
            with self.subTest(status=status):
                error = HTTPError("https://generativelanguage.googleapis.com/", status, "error", {}, io.BytesIO(
                    json.dumps({"error": {"message": "failure SECRET-KEY"}}).encode()
                ))
                with patch("gemini_diagnostics.urlopen", side_effect=error):
                    ok, message = _test_gemini_native("SECRET-KEY", "gemini-3.8-flash")
                self.assertFalse(ok)
                self.assertIn(expected, message)
                self.assertNotIn("SECRET-KEY", message)

    def test_missing_key_and_invalid_model_fail_without_network(self):
        with patch("gemini_diagnostics.urlopen") as mocked:
            self.assertFalse(_test_gemini_native("", "gemini-3.8-flash")[0])
            self.assertFalse(_test_gemini_native("key", "../bad")[0])
        mocked.assert_not_called()

    def test_model_list_confirms_selected_model_without_generation(self):
        with patch("gemini_diagnostics.urlopen", return_value=FakeResponse({
            "models": [
                {"name": "models/gemini-3.8-flash", "supportedGenerationMethods": ["generateContent", "countTokens"]},
                {"name": "models/text-embedding-004", "supportedGenerationMethods": ["embedContent"]},
            ]
        })) as mocked:
            ok, message = list_gemini_models("SECRET-KEY", "gemini-3.8-flash")
        self.assertTrue(ok)
        self.assertIn("يدعم generateContent", message)
        self.assertNotIn("SECRET-KEY", message)
        request = mocked.call_args.args[0]
        self.assertNotIn("SECRET-KEY", request.full_url)
        self.assertEqual(request.get_header("X-goog-api-key"), "SECRET-KEY")

    def test_model_list_reports_selected_model_missing(self):
        with patch("gemini_diagnostics.urlopen", return_value=FakeResponse({
            "models": [{"name": "models/gemini-3.6-flash", "supportedGenerationMethods": ["generateContent"]}]
        })):
            ok, message = list_gemini_models("key", "gemini-3.8-flash")
        self.assertFalse(ok)
        self.assertIn("غير موجود", message)
        self.assertIn("gemini-3.6-flash", message)

    def test_model_list_http_error_redacts_key(self):
        error = HTTPError("https://generativelanguage.googleapis.com/", 403, "error", {}, io.BytesIO(
            json.dumps({"error": {"message": "denied SECRET-KEY"}}).encode()
        ))
        with patch("gemini_diagnostics.urlopen", side_effect=error):
            ok, message = list_gemini_models("SECRET-KEY", "gemini-3.8-flash")
        self.assertFalse(ok)
        self.assertIn("HTTP 403", message)
        self.assertNotIn("SECRET-KEY", message)

    def test_empty_success_body_is_not_claimed_as_full_success(self):
        with patch("gemini_diagnostics.urlopen", return_value=FakeResponse({"candidates": []})):
            ok, message = _test_gemini_native("key", "gemini-3.8-flash")
        self.assertFalse(ok)
        self.assertIn("دون نص مولّد", message)


if __name__ == "__main__":
    unittest.main(verbosity=2)
