import tempfile
import unittest
from pathlib import Path

from app_paths import get_app_data_dir


class AppDataPathTests(unittest.TestCase):
    def test_defaults_to_legacy_localappdata_location(self):
        path = get_app_data_dir({"LOCALAPPDATA": r"C:\Users\Tester\AppData\Local"})
        self.assertEqual(path, Path(r"C:\Users\Tester\AppData\Local") / "LocalAssistant")

    def test_custom_data_dir_overrides_localappdata(self):
        env = {"LOCALAPPDATA": r"C:\Users\Tester\AppData\Local", "AURORA_DATA_DIR": "E:/AuroraData/LocalAssistant"}
        self.assertEqual(get_app_data_dir(env), Path("E:/AuroraData/LocalAssistant"))

    def test_empty_custom_path_falls_back_to_localappdata(self):
        env = {"LOCALAPPDATA": r"C:\Temp", "AURORA_DATA_DIR": "   "}
        self.assertEqual(get_app_data_dir(env, platform_windows=True, e_drive_available=False), Path(r"C:\Temp") / "LocalAssistant")

    def test_windows_prefers_e_when_available(self):
        env = {"LOCALAPPDATA": r"C:\Users\Tester\AppData\Local"}
        self.assertEqual(get_app_data_dir(env, platform_windows=True, e_drive_available=True), Path("E:/AuroraData/LocalAssistant"))

    def test_explicit_data_path_beats_e_default(self):
        env = {"AURORA_DATA_DIR": "D:/MyAuroraData", "LOCALAPPDATA": r"C:\Temp"}
        self.assertEqual(get_app_data_dir(env, platform_windows=True, e_drive_available=True), Path("D:/MyAuroraData"))


if __name__ == "__main__":
    unittest.main()
