import io
import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

from gemini_native_client import (
    GeminiNativeError,
    _messages_to_gemini,
    _tool_calls_to_gemini,
    native_gemini_chat_completion,
)


class FakeResponse:
    status = 200
    def __init__(self, payload):
        self.payload = json.dumps(payload).encode("utf-8")
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self, n=-1): return self.payload[:n]


class GeminiNativeClientTests(unittest.TestCase):
    def test_maps_openai_tool_schema_to_google_function_declaration(self):
        result = _tool_calls_to_gemini([{"type": "function", "function": {
            "name": "browser_open_url", "description": "open", "parameters": {
                "type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]
            }
        }}])
        self.assertEqual(result[0]["name"], "browser_open_url")
        self.assertEqual(result[0]["parameters"]["required"], ["url"])
        self.assertNotIn("additionalProperties", result[0]["parameters"])

    def test_maps_tool_response_with_matching_function_call_id(self):
        contents = _messages_to_gemini([
            {"role": "user", "content": "open example"},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "call-1", "function": {"name": "browser_open_url", "arguments": '{"url":"https://example.com"}'}}]},
            {"role": "tool", "tool_call_id": "call-1", "content": '{"ok":true,"message":"opened"}'},
        ])
        self.assertEqual(contents[1]["role"], "model")
        self.assertEqual(contents[1]["parts"][0]["functionCall"]["id"], "call-1")
        response = contents[2]["parts"][0]["functionResponse"]
        self.assertEqual(response["id"], "call-1")
        self.assertEqual(response["name"], "browser_open_url")
        self.assertTrue(response["response"]["ok"])

    def test_maps_image_attachment_to_generate_content_inline_data(self):
        import tempfile
        from pathlib import Path
        from PIL import Image
        from image_support import store_uploaded_images
        class Upload:
            name = "chart.png"
            def getvalue(self):
                import io
                buffer = io.BytesIO()
                Image.new("RGB", (8, 8), (1, 2, 3)).save(buffer, format="PNG")
                return buffer.getvalue()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "Attachments"
            metadata = store_uploaded_images([Upload()], root)
            contents = _messages_to_gemini([{
                "role": "user", "content": "حلل الصورة", "attachments": metadata,
            }], attachments_dir=root)
        parts = contents[0]["parts"]
        self.assertEqual(parts[0]["text"], "حلل الصورة")
        self.assertEqual(parts[1]["inlineData"]["mimeType"], "image/png")
        self.assertTrue(parts[1]["inlineData"]["data"])

    def test_native_request_uses_api_key_header_and_returns_function_call(self):
        payload = {"candidates": [{"content": {"parts": [{"functionCall": {
            "id": "fc-1", "name": "browser_open_url", "args": {"url": "https://example.com"}
        }, "thoughtSignature": "sig-123"}]}}]}
        with patch("gemini_native_client.urlopen", return_value=FakeResponse(payload)) as mocked:
            response = native_gemini_chat_completion(
                "SECRET", "gemini-3.8-flash", "system", [{"role": "user", "content": "open example"}],
                tools=[{"type": "function", "function": {"name": "browser_open_url", "parameters": {"type": "object"}}}],
            )
        call = response.choices[0].message.tool_calls[0]
        self.assertEqual(call.id, "fc-1")
        self.assertEqual(call.function.name, "browser_open_url")
        self.assertEqual(call.thought_signature, "sig-123")
        # Round-trip the returned call into a subsequent request without losing Gemini 3 signature.
        roundtrip = _messages_to_gemini([{"role": "assistant", "content": "", "tool_calls": [call.model_dump()]}])
        self.assertEqual(roundtrip[0]["parts"][0]["thoughtSignature"], "sig-123")
        request = mocked.call_args.args[0]
        self.assertNotIn("SECRET", request.full_url)
        self.assertEqual(request.get_header("X-goog-api-key"), "SECRET")
        body = json.loads(request.data.decode())
        self.assertIn("functionDeclarations", body["tools"][0])

    def test_native_generate_content_request_includes_image_bytes_not_local_path(self):
        import tempfile
        from pathlib import Path
        from PIL import Image
        from image_support import store_uploaded_images

        class Upload:
            name = "screen.png"
            def getvalue(self):
                buffer = io.BytesIO()
                Image.new("RGB", (9, 7), (11, 22, 33)).save(buffer, format="PNG")
                return buffer.getvalue()

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "Attachments"
            metadata = store_uploaded_images([Upload()], root)
            with patch("gemini_native_client.urlopen", return_value=FakeResponse({
                "candidates": [{"content": {"parts": [{"text": "أرى صورة"}]}}]
            })) as mocked:
                native_gemini_chat_completion(
                    "TEST_KEY", "gemini-3.8-flash", "system",
                    [{"role": "user", "content": "صف الصورة", "attachments": metadata}],
                    attachments_dir=root,
                )
            request = mocked.call_args.args[0]
            body = json.loads(request.data.decode("utf-8"))
            parts = body["contents"][0]["parts"]
            self.assertEqual(parts[0]["text"], "صف الصورة")
            self.assertEqual(parts[1]["inlineData"]["mimeType"], "image/png")
            self.assertTrue(parts[1]["inlineData"]["data"])
            self.assertNotIn(str(root), request.data.decode("utf-8"))
            self.assertNotIn(str(root), request.full_url)

    def test_google_error_is_classified_and_key_is_redacted(self):
        error = HTTPError("https://generativelanguage.googleapis.com/", 429, "quota", {}, io.BytesIO(
            json.dumps({"error": {"status": "RESOURCE_EXHAUSTED", "message": "limit SECRET"}}).encode()
        ))
        with patch("gemini_native_client.urlopen", side_effect=error):
            with self.assertRaises(GeminiNativeError) as caught:
                native_gemini_chat_completion("SECRET", "gemini-3.8-flash", "system", [{"role": "user", "content": "hello"}])
        self.assertEqual(caught.exception.status_code, 429)
        self.assertIn("RESOURCE_EXHAUSTED", str(caught.exception))
        self.assertNotIn("SECRET", str(caught.exception))

    def test_empty_user_history_is_rejected_before_network(self):
        with patch("gemini_native_client.urlopen") as mocked:
            with self.assertRaises(GeminiNativeError):
                native_gemini_chat_completion("key", "gemini-3.8-flash", "system", [])
        mocked.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
