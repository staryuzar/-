import json
import unittest
from types import SimpleNamespace

from assistant_core import (
    action_summary,
    conversation_from_row,
    export_conversation_markdown,
    json_list,
    messages_for_model,
    redact_tool_log,
    tool_call_payload,
    resolve_approval_action,
    redact_messages_for_storage,
    rehydrate_pending_tool_calls,
    probe_model_connection,
    tool_call_fingerprint,
)


class ConversationHelperTests(unittest.TestCase):
    def test_invalid_json_recovers_to_empty_list(self):
        self.assertEqual(json_list("not json"), [])
        self.assertEqual(json_list("{}"), [])
        self.assertEqual(json_list('[{"role":"user"}]'), [{"role": "user"}])

    def test_conversation_row_loads_legacy_or_malformed_json(self):
        row = {"id": "1", "title": "تجربة", "messages_json": "bad", "log_json": "[]", "pending_json": "null"}
        conv = conversation_from_row(row)
        self.assertEqual(conv["id"], "1")
        self.assertEqual(conv["messages"], [])
        self.assertEqual(conv["pending"], [])

    def test_message_window_keeps_complete_latest_user_turn(self):
        messages = []
        for i in range(22):
            messages.extend([
                {"role": "user", "content": f"u{i}"},
                {"role": "assistant", "content": "", "tool_calls": [{"id": f"c{i}"}]},
                {"role": "tool", "tool_call_id": f"c{i}", "content": "{}"},
                {"role": "assistant", "content": f"done{i}"},
            ])
        recent = messages_for_model(messages, 20)
        self.assertLessEqual(len(recent), 23)
        self.assertEqual(recent[0]["role"], "user")
        # No tool response is kept without the assistant call in this generated history.
        calls = {call["id"] for m in recent for call in m.get("tool_calls", [])}
        tool_ids = {m["tool_call_id"] for m in recent if m["role"] == "tool"}
        self.assertEqual(calls, tool_ids)

    def test_long_single_task_history_is_bounded_with_checkpoint_and_paired_tools(self):
        messages = [{"role": "user", "content": "اختبر الخبير ثم استخرج التقرير"}]
        for i in range(60):
            call_id = f"long-{i}"
            messages.append({"role": "assistant", "content": "", "tool_calls": [{"id": call_id, "type": "function", "function": {"name": "run_test", "arguments": "{}"}}]})
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"ok": True, "effect_verified": True, "message": f"خطوة {i} نجحت"}, ensure_ascii=False)})
        result = messages_for_model(messages, 20)
        self.assertLessEqual(len(result), 20)
        self.assertEqual(result[0]["role"], "user")
        self.assertTrue(any("نقطة استئناف" in str(item.get("content", "")) for item in result))
        calls = {call["id"] for item in result for call in item.get("tool_calls", [])}
        tool_ids = {item["tool_call_id"] for item in result if item.get("role") == "tool"}
        self.assertEqual(calls, tool_ids)

    def test_oversized_parallel_tool_batch_keeps_only_paired_recent_calls(self):
        calls = [{"id": f"batch-{i}", "type": "function", "function": {"name": "read", "arguments": "{}"}} for i in range(40)]
        # Gemini 3 may attach its required thoughtSignature only to the first parallel call.
        calls[0]["thoughtSignature"] = "sig-first"
        messages = [{"role": "user", "content": "نفذ مجموعة"}, {"role": "assistant", "content": "", "tool_calls": calls}]
        messages.extend({"role": "tool", "tool_call_id": f"batch-{i}", "content": "{}"} for i in range(40))
        result = messages_for_model(messages, 12)
        self.assertLessEqual(len(result), 12)
        kept_call_ids = {call["id"] for item in result for call in item.get("tool_calls", [])}
        kept_tool_ids = {item["tool_call_id"] for item in result if item.get("role") == "tool"}
        self.assertEqual(kept_call_ids, kept_tool_ids)
        self.assertEqual(len(kept_call_ids), 9)
        self.assertIn("batch-0", kept_call_ids)
        kept_batch = next(item for item in result if item.get("role") == "assistant" and item.get("tool_calls"))
        first_signed = next(call for call in kept_batch["tool_calls"] if call["id"] == "batch-0")
        self.assertEqual(first_signed["thoughtSignature"], "sig-first")

    def test_tiny_history_cap_still_keeps_tool_call_result_pair(self):
        messages = [
            {"role": "user", "content": "نفذ"},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "small-1", "type": "function", "function": {"name": "read", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "small-1", "content": "{}"},
            {"role": "assistant", "content": "تم"},
        ]
        result = messages_for_model(messages * 3, 3)
        self.assertLessEqual(len(result), 4)
        call_ids = {call["id"] for item in result for call in item.get("tool_calls", [])}
        response_ids = {item["tool_call_id"] for item in result if item.get("role") == "tool"}
        self.assertEqual(call_ids, response_ids)

    def test_redacts_private_content_from_persistent_audit_log(self):
        args, output = redact_tool_log("browser_type_text", {"text": "رسالة خاصة"}, {"message": "typed", "text": "hidden page text"})
        self.assertIn("مخفى", args["text"])
        self.assertIn("مخفى", output["text"])
        self.assertNotIn("رسالة خاصة", json.dumps(args, ensure_ascii=False))

    def test_action_summary_warns_for_message_sending_and_commands(self):
        _, click_warning = action_summary("browser_click_text", {"text": "إرسال"})
        _, cmd_warning = action_summary("run_local_command", {"command": ["python", "-V"]})
        self.assertIn("إرسال رسالة", click_warning)
        _, read_warning = action_summary("browser_read_page", {})
        self.assertIn("Gemini أو OpenRouter", read_warning)
        self.assertNotIn("عبر OpenRouter", read_warning)
        self.assertIn("حساب Windows", cmd_warning)

    def test_export_contains_only_readable_conversation_roles(self):
        conv = {"title": "اختبار", "messages": [
            {"role": "user", "content": "مرحبًا"},
            {"role": "tool", "content": "secret raw tool data"},
            {"role": "assistant", "content": "أهلًا"},
        ]}
        exported = export_conversation_markdown(conv)
        self.assertIn("مرحبًا", exported)
        self.assertIn("أهلًا", exported)
        self.assertNotIn("secret raw tool data", exported)

    def test_tool_call_fingerprint_is_stable_and_detects_duplicates(self):
        first = tool_call_fingerprint("browser_click_text", {"text": "Open", "x": 1})
        same = tool_call_fingerprint("browser_click_text", {"x": 1, "text": "Open"})
        different = tool_call_fingerprint("browser_click_text", {"text": "Close", "x": 1})
        self.assertEqual(first, same)
        self.assertNotEqual(first, different)

    def test_tool_call_payload_handles_malformed_json(self):
        call = SimpleNamespace(id="call-1", function=SimpleNamespace(name="browser_click_text", arguments="{bad"))
        call_id, name, args = tool_call_payload(call)
        self.assertEqual(call_id, "call-1")
        self.assertEqual(name, "browser_click_text")
        self.assertIn("_invalid_arguments", args)

    def test_rejected_approval_never_executes_action(self):
        conv = {"messages": [], "pending": [{"id": "call-1", "name": "browser_click_text", "args": {"text": "Send"}}]}
        called = []
        output = resolve_approval_action(conv, "call-1", False, lambda n, a: called.append((n, a)))
        self.assertFalse(output["ok"])
        self.assertEqual(called, [])
        self.assertEqual(conv["pending"], [])
        self.assertEqual(conv["messages"][0]["tool_call_id"], "call-1")

    def test_approved_action_executes_once_and_pairs_tool_reply(self):
        conv = {"messages": [], "pending": [{"id": "call-2", "name": "browser_click_text", "args": {"text": "Send"}}]}
        called = []
        def fake_execute(name, args):
            called.append((name, args))
            return {"ok": True, "effect_verified": False, "message": "click dispatched"}
        output = resolve_approval_action(conv, "call-2", True, fake_execute)
        self.assertTrue(output["ok"])
        self.assertEqual(len(called), 1)
        self.assertEqual(conv["messages"][0]["tool_call_id"], "call-2")
        self.assertEqual(conv["pending"], [])


    def test_sensitive_tool_content_is_redacted_before_database_persistence(self):
        messages = [
            {"role": "assistant", "content": "", "tool_calls": [{"id": "call-read", "type": "function", "function": {"name": "browser_read_page", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "call-read", "content": json.dumps({"ok": True, "text": "private message: hello"})},
            {"role": "assistant", "content": "The message says hello."},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "call-type", "type": "function", "function": {"name": "browser_type_text", "arguments": json.dumps({"text": "private draft"})}}]},
        ]
        stored = redact_messages_for_storage(messages)
        self.assertNotIn("private message: hello", json.dumps(stored, ensure_ascii=False))
        self.assertNotIn("private draft", json.dumps(stored, ensure_ascii=False))
        self.assertIn("The message says hello.", json.dumps(stored, ensure_ascii=False))


    def test_memory_content_is_redacted_from_audit_log(self):
        args, output = redact_tool_log("memory_save", {"title": "رسالة خاصة", "content": "نص رسالة سري"}, {"ok": True, "content": "نص رسالة سري"})
        self.assertNotIn("نص رسالة سري", json.dumps([args, output], ensure_ascii=False))
        self.assertIn("مخفى", args["content"])

    def test_memory_search_results_are_redacted_before_conversation_storage(self):
        messages = [
            {"role": "assistant", "content": "", "tool_calls": [{"id": "mem-1", "type": "function", "function": {"name": "memory_search", "arguments": json.dumps({"query": "رسالة"})}}]},
            {"role": "tool", "tool_call_id": "mem-1", "content": json.dumps({"ok": True, "results": [{"title": "رسالة خاصة", "content": "تفاصيل بريد خاصة"}]}, ensure_ascii=False)},
        ]
        stored = redact_messages_for_storage(messages)
        self.assertNotIn("تفاصيل بريد خاصة", json.dumps(stored, ensure_ascii=False))

    def test_url_queries_and_fragments_are_redacted_from_audit_log(self):
        args, output = redact_tool_log("browser_open_url", {"url": "https://example.com/inbox?token=SECRET#message"}, {"url": "https://example.com/inbox?token=SECRET#message"})
        serialized = json.dumps([args, output], ensure_ascii=False)
        self.assertNotIn("SECRET", serialized)
        self.assertIn("query hidden", serialized)


    def test_pending_tool_calls_rehydrate_private_args_after_reload(self):
        conv = {
            "pending": [{"id": "call-typed", "name": "browser_type_text", "args": {"text": "message body", "_context_url": "https://example.com"}}],
            "messages": [{"role": "assistant", "tool_calls": [{"id": "call-typed", "type": "function", "function": {"name": "browser_type_text", "arguments": json.dumps({"text": "[hidden]"})}}]}],
        }
        rehydrate_pending_tool_calls(conv)
        args = json.loads(conv["messages"][0]["tool_calls"][0]["function"]["arguments"])
        self.assertEqual(args, {"text": "message body"})


class ActionSummaryPrivacyTests(unittest.TestCase):
    def test_action_summary_hides_url_query_and_fragment(self):
        _title, summary = action_summary(
            "browser_click_text",
            {"text": "إرسال", "_context_url": "https://mail.example.com/compose?token=SECRET#private"},
        )
        self.assertIn("mail.example.com/compose", summary)
        self.assertNotIn("SECRET", summary)
        self.assertNotIn("#private", summary)


    def test_procedure_contents_are_redacted_from_audit_log(self):
        safe_args, safe_output = redact_tool_log("procedure_save", {
            "procedure_key": "gmail.read", "steps": ["private step"], "intent": "private intent"
        }, {"ok": True, "effect_verified": True})
        self.assertNotIn("private step", str(safe_args))
        self.assertNotIn("private intent", str(safe_args))

    def test_procedure_search_results_are_redacted_from_conversation_storage(self):
        messages = [
            {"role": "assistant", "content": "", "tool_calls": [{"id": "proc1", "type": "function", "function": {"name": "procedure_search", "arguments": "{\"query\":\"gmail\"}"}}]},
            {"role": "tool", "tool_call_id": "proc1", "content": json.dumps({"ok": True, "procedures": [{"name": "private procedure", "steps": ["secret step"]}]})},
        ]
        safe = redact_messages_for_storage(messages)
        self.assertNotIn("secret step", str(safe))
        self.assertNotIn("private procedure", str(safe))

class ModelProbeTests(unittest.TestCase):
    def test_probe_model_connection_returns_short_nonempty_reply(self):
        calls = {}
        def create(**kwargs):
            calls.update(kwargs)
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content="متصل"))])
        client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
        self.assertEqual(probe_model_connection(client, "test/model"), "متصل")
        self.assertEqual(calls["model"], "test/model")
        self.assertEqual(calls["messages"][0]["content"], "أجب بكلمة واحدة فقط: متصل")

    def test_probe_model_connection_fails_on_empty_response(self):
        client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=lambda **kwargs: SimpleNamespace(choices=[]))))
        with self.assertRaisesRegex(RuntimeError, "لم يُرجع أي اختيار"):
            probe_model_connection(client, "test/model")


if __name__ == "__main__":
    unittest.main(verbosity=2)
