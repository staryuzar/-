import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from setup_data import DataPathConflictError, bootstrap_data_directory, prepare_data_location


class SetupDataLocationTests(unittest.TestCase):
    def _workspace(self, root: Path):
        project = root / "project"
        project.mkdir()
        (project / ".env.example").write_text("AI_PROVIDER=gemini\nGEMINI_API_KEY=\n", encoding="utf-8")
        return project

    def test_migrates_c_data_to_empty_e_and_persists_one_path(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = self._workspace(root)
            c_root = root / "C" / "Users" / "Tester" / "AppData" / "Local"
            source = c_root / "LocalAssistant"
            source.mkdir(parents=True)
            (source / "note.txt").write_text("keep", encoding="utf-8")
            target = root / "E" / "AuroraData" / "LocalAssistant"

            selected = prepare_data_location(
                project,
                environ={"LOCALAPPDATA": str(c_root)},
                platform_windows=True,
                e_drive_available=True,
                e_data_path=target,
                local_app_data=c_root,
            )
            self.assertEqual(selected, target)
            self.assertEqual((target / "note.txt").read_text(encoding="utf-8"), "keep")
            self.assertTrue((source / "note.txt").is_file(), "source should remain as rollback copy")
            env_text = (project / ".env").read_text(encoding="utf-8")
            self.assertIn("AURORA_DATA_DIR=" + target.as_posix(), env_text)

    def test_refuses_two_populated_locations_without_overwriting_either(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = self._workspace(root)
            c_root = root / "C" / "Local"
            source = c_root / "LocalAssistant"
            source.mkdir(parents=True)
            (source / "c.txt").write_text("C data", encoding="utf-8")
            target = root / "E" / "AuroraData" / "LocalAssistant"
            target.mkdir(parents=True)
            (target / "e.txt").write_text("E data", encoding="utf-8")
            with self.assertRaises(DataPathConflictError):
                prepare_data_location(
                    project,
                    environ={"LOCALAPPDATA": str(c_root)},
                    platform_windows=True,
                    e_drive_available=True,
                    e_data_path=target,
                    local_app_data=c_root,
                )
            self.assertEqual((source / "c.txt").read_text(encoding="utf-8"), "C data")
            self.assertEqual((target / "e.txt").read_text(encoding="utf-8"), "E data")


    def test_clean_first_run_creates_e_directory_single_database_and_starter_memory(self):
        """A never-installed user needs no separate migration script or pre-made data folder."""
        import sqlite3
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = self._workspace(root)
            c_root = root / "C" / "Users" / "Tester" / "AppData" / "Local"
            target = root / "E" / "AuroraData" / "LocalAssistant"
            selected = prepare_data_location(
                project,
                environ={"LOCALAPPDATA": str(c_root)},
                platform_windows=True,
                e_drive_available=True,
                e_data_path=target,
                local_app_data=c_root,
            )
            self.assertEqual(selected, target)
            self.assertTrue(target.is_dir())
            self.assertFalse(c_root.exists(), "fresh install must not need the old C data directory")
            env_text = (project / ".env").read_text(encoding="utf-8")
            self.assertIn("AURORA_DATA_DIR=" + target.as_posix(), env_text)

            result = bootstrap_data_directory(selected)
            db = target / "aurora.sqlite3"
            self.assertTrue(db.is_file())
            self.assertEqual(result["integrity"], "ok")
            self.assertGreater(result["counts"]["procedures"], 0)
            self.assertGreater(result["counts"]["memories"], 0)
            self.assertEqual(result["database_path"], str(db))
            for relative in ("Workspace/Drafts", "Attachments", "ChromeProfile"):
                self.assertTrue((target / relative).is_dir(), relative)
            with closing(sqlite3.connect(db)) as con:
                self.assertEqual(con.execute("PRAGMA integrity_check").fetchone()[0], "ok")
                tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                self.assertTrue({"conversations", "memories", "procedures", "operation_events", "operation_task_runs", "aurora_migration_ledger"}.issubset(tables))
            # The normal first-run path must create the SQLite store before the
            # installer asks the user to enter a model API key.
            self.assertIn("AURORA_DATA_DIR=" + target.as_posix(), env_text)
            self.assertTrue((target / "Workspace" / "Drafts").is_dir())
            self.assertTrue((target / "Attachments").is_dir())
            self.assertTrue((target / "ChromeProfile").is_dir())

    def test_first_run_bootstrap_is_idempotent(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = root / "E" / "AuroraData" / "LocalAssistant"
            first = bootstrap_data_directory(data)
            second = bootstrap_data_directory(data)
            self.assertGreater(first["counts"]["procedures"], 0)
            self.assertEqual(first["counts"]["procedures"], second["counts"]["procedures"])
            self.assertEqual(first["counts"]["memories"], second["counts"]["memories"])
            self.assertEqual(second["integrity"], "ok")

    def test_explicit_custom_location_is_honored(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = self._workspace(root)
            (project / ".env").write_text("AURORA_DATA_DIR=D:/AuroraChosen\n", encoding="utf-8")
            target = prepare_data_location(project, environ={}, platform_windows=True, e_drive_available=True)
            self.assertEqual(target, Path("D:/AuroraChosen"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
