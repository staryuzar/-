import unittest

from browser_control import (
    validate_debugger_address,
    find_text_target,
    get_visible_page_text,
    key_code,
    page_read_warning,
    validate_current_page,
    validate_text_entry,
    chrome_translation_preferences,
)


class FakeElement:
    def __init__(self, text="", tag_name="button", attrs=None, visible=True, enabled=True):
        self.text = text
        self.tag_name = tag_name
        self.attrs = attrs or {}
        self.visible = visible
        self.enabled = enabled
        self.clicked = False
        self.sent = []
    def get_attribute(self, name): return self.attrs.get(name, "")
    def is_displayed(self): return self.visible
    def is_enabled(self): return self.enabled
    def click(self): self.clicked = True
    def send_keys(self, value): self.sent.append(value)


class FakeDriver:
    def __init__(self, url="https://example.com", elements=None, body="page contents", active=None):
        self.current_url = url
        self.elements = elements or []
        self.body = FakeElement(body, "body")
        self.blank_called = False
        self.switch_to = type("Switch", (), {"active_element": active or FakeElement(tag_name="textarea")})()
    def get(self, url):
        self.current_url = url
        if url == "about:blank": self.blank_called = True
    def find_elements(self, by, selector): return self.elements
    def find_element(self, by, selector): return self.body


class DebuggerAddressTests(unittest.TestCase):
    def test_accepts_loopback_debugger_addresses(self):
        self.assertEqual(validate_debugger_address("127.0.0.1:9222"), "127.0.0.1:9222")
        self.assertEqual(validate_debugger_address("localhost:9222"), "localhost:9222")
        self.assertEqual(validate_debugger_address("[::1]:9222"), "[::1]:9222")

    def test_rejects_remote_or_malformed_debugger_addresses(self):
        for value in ("192.168.1.4:9222", "example.com:9222", "127.0.0.1:0", "127.0.0.1:99999", "http://127.0.0.1:9222"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_debugger_address(value)


class BrowserControlTests(unittest.TestCase):
    def test_chrome_translation_defaults_to_english_to_arabic(self):
        prefs = chrome_translation_preferences()
        self.assertIs(prefs["translate.enabled"], True)
        self.assertEqual(prefs["translate_allowlists"], {"en": "ar"})
        self.assertEqual(prefs["translate_whitelists"], {"en": "ar"})
        self.assertIn("ar", prefs["intl.accept_languages"])

    def test_validates_current_public_url(self):
        driver = FakeDriver()
        self.assertEqual(validate_current_page(driver, resolve_dns=False), "https://example.com")

    def test_invalid_redirect_is_blank_and_rejected(self):
        driver = FakeDriver("http://127.0.0.1:8501")
        with self.assertRaises(ValueError):
            validate_current_page(driver, resolve_dns=False)
        self.assertTrue(driver.blank_called)

    def test_sensitive_site_warning_does_not_block_reading(self):
        self.assertIn("حساب خاص", page_read_warning("https://web.whatsapp.com/"))
        self.assertEqual(page_read_warning("https://example.com/"), "")

    def test_click_target_prefers_exact_label(self):
        button_a = FakeElement("Send later")
        button_b = FakeElement("Send")
        driver = FakeDriver(elements=[button_a, button_b])
        element, label = find_text_target(driver, "Send")
        self.assertIs(element, button_b)
        self.assertEqual(label, "Send")

    def test_ambiguous_target_is_rejected(self):
        driver = FakeDriver(elements=[FakeElement("Send now"), FakeElement("Send later")])
        with self.assertRaises(ValueError):
            find_text_target(driver, "Send")

    def test_text_fields_allowed_and_passwords_blocked(self):
        self.assertEqual(validate_text_entry(FakeElement(tag_name="textarea")), "محرر نصي")
        self.assertEqual(validate_text_entry(FakeElement(tag_name="input", attrs={"type": "email"})), "حقل نصي")
        with self.assertRaises(ValueError):
            validate_text_entry(FakeElement(tag_name="input", attrs={"type": "password"}))

    def test_enter_key_has_known_code(self):
        self.assertEqual(key_code("ENTER"), "\ue007")
        with self.assertRaises(ValueError):
            key_code("F12")

    def test_page_text_is_capped(self):
        driver = FakeDriver(body="abcdefghij")
        self.assertEqual(get_visible_page_text(driver, limit=5), "abcde")


    def test_duplicate_exact_send_buttons_are_not_guessed(self):
        driver = FakeDriver(elements=[FakeElement("Send"), FakeElement("Send")])
        with self.assertRaises(ValueError):
            find_text_target(driver, "Send")


if __name__ == "__main__":
    unittest.main(verbosity=2)
